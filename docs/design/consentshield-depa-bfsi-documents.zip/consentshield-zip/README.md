# ConsentShield — Document Package
## April 2026

### 01_DEPA_documents/
The six documents that define how DEPA affects ConsentShield's architecture,
product design, and market positioning:

| File | Role | Level |
|---|---|---|
| consentshield-depa-architecture.md | Translates DEPA's 5 structural principles into concrete product decisions — consent artefact model, purpose registry, expiry pipeline, artefact-scoped deletion | Architecture |
| consentshield-depa-schema-modifications.md | Full SQL for all DEPA-native tables: purpose_definitions, consent_artefacts, artefact_revocations, purpose_connector_mappings, consent_expiry_queue | Implementation |
| consentshield-definitive-architecture.md | Authoritative technical reference — stateless oracle model, Zero-Storage mode, data flow specification | Architecture |
| abdm-scope-data-architecture.md | DEPA in the healthcare context — ABDM consent artefacts are DEPA artefacts; unified artefact model across DPDP and ABDM | Architecture |
| ConsentShield-Partnership-Overview-v2.md | Partnership-facing document explaining DEPA alignment as competitive differentiation | Positioning |
| ConsentShield-Partnership-Overview-v3.docx | Updated Partnership Overview with all-India partner requirements and BFSI segment | Positioning |

### 02_created_today_markdown/
New strategic documents produced today:

| File | Contents |
|---|---|
| consentshield-bfsi-segment-brief.md | BFSI Segment Brief v1 — NBFCs and broking platforms. Foundation document superseded by v2 docx. |
| consentshield-banking-critical-review.md | Critical examination of banking segment blockers — finds two of three substantially wrong, establishes the path to full private banks via Zero-Storage mode and SFB sequencing |
| consentshield-depa-banking-bridge.md | NEW — Why DEPA-native architecture is the ONLY viable model for banking. Covers the five third-party sharing consent scenarios, the GDPR retrofit impossibility, BFSI template configuration tables, and the DPB examiner's chain-of-custody question. |

---
*All documents: ConsentShield · Hyderabad, India · Confidential — April 2026*
