# ConsentShield — Critical Examination: Addressing Private Banks
## An Honest Review of What It Actually Takes

*April 2026 · Internal strategy document*

---

## The Starting Position

The BFSI segment brief dismissed private banks with three blockers:
1. RBI outsourcing guidelines make the current infrastructure non-compliant
2. 6–18 month procurement cycles are incompatible with a self-serve SaaS product
3. Banks already have compliance machinery that will handle DPDP

This document tests each blocker as a hypothesis. The conclusion is that two of the three are substantially wrong — and the one that is right is manageable with a deliberate entry strategy. Private banks are addressable. The path is harder than NBFCs, but the opportunity is proportionally larger.

---

## Blocker 1: "RBI Outsourcing Guidelines Block Our Infrastructure"

**Verdict: Substantially false. The stateless oracle architecture inverts this concern.**

### The Argument That Was Made

The original brief argued that ConsentShield's deployment on Supabase (AWS)/Cloudflare/Vercel would fail RBI's IT Governance Master Direction (2023), which imposes strict conditions on cloud infrastructure handling bank data.

### Why This Is Wrong

The argument conflates two entirely different things: **where data is processed** and **where data is stored**. RBI's outsourcing guidelines primarily govern where **banking data is held and who controls it**. They do not prohibit banks from using cloud-based processing APIs — they already do, extensively. HDFC Bank runs on AWS. ICICI Direct uses Azure. Axis uses GCP. All with RBI's knowledge and within the guidelines.

The question RBI cares about is: **does the bank control its own data?**

Under ConsentShield's Zero-Storage mode — which is the correct mode for any bank deployment — the answer is unambiguously yes:

```
What ConsentShield holds in Zero-Storage mode:
  ├─ Artefact validity index (artefact ID + validity state + TTL only — no personal data)
  ├─ Operational config (banner settings, purpose definitions, billing)
  └─ WAL buffer (hours-level, deleted on confirmed delivery to bank's own storage)

What the BANK holds (in their own infrastructure):
  ├─ All consent artefacts — complete, canonical
  ├─ Full audit log
  ├─ Rights request history
  ├─ Deletion receipts
  └─ Processing log
```

ConsentShield in Zero-Storage mode is a processing API, not a data store. The bank's own storage — which they provision, control, and hold the encryption keys for — is the system of record. This is architecturally identical to how a bank uses a payment gateway: Razorpay processes the transaction and hands the bank the record. Razorpay does not hold the bank's transaction history. No one argues that Razorpay violates RBI outsourcing guidelines.

The specific RBI framing that applies: ConsentShield is a **technology service provider for consent processing**, not a **data processor holding core banking data**. The distinction is meaningful and defensible.

### What This Actually Requires

Zero-Storage mode deployment changes the infrastructure question from "can our stack pass RBI scrutiny" to "can we point the delivery stream at the bank's own AWS/Azure/GCP bucket in their Indian region?" The answer is yes, and it requires approximately one sprint of configuration work — a per-customer storage endpoint that the bank provisions and ConsentShield writes to.

**This blocker is dissolved by the stateless oracle architecture. It should not appear in any future segment analysis.**

---

## Blocker 2: "Procurement Cycles Are Incompatible With Self-Serve SaaS"

**Verdict: Partially true — but the conclusion drawn (don't address banks) is wrong. The correct conclusion is: use a different sales motion.**

### The Argument That Was Made

Banks have 6–18 month procurement cycles involving VAPT, IT risk assessment, legal SLA review, and information security committee sign-off. This is incompatible with a self-serve product.

### What Is True About This

The procurement cycle claim is accurate for large private banks procuring a new enterprise software vendor. HDFC Bank's vendor empanelment process for a SaaS compliance tool would realistically take 9–12 months minimum. This is a real constraint.

### What Was Wrong About It

The brief used this fact to conclude that ConsentShield cannot address banks at all. That conclusion confuses **the sales motion** with **the market**. Banks cannot be addressed via self-serve. They can be addressed via enterprise sales, partner channels, and phased entry through more accessible sub-segments.

Three entry paths exist that don't require surviving the full bank vendor empanelment process:

**Path A: Core Banking Vendor Partnership**

Infosys Finacle, Oracle FLEXCUBE, Temenos, and Mambu collectively run the core banking infrastructure for the majority of Indian private banks. These vendors already have bank empanelment. They are active partners — not new vendors. A DPDP compliance module built as an add-on to Finacle or FLEXCUBE reaches bank customers through an existing trusted relationship without ConsentShield going through independent vendor approval.

The conversation with Infosys Finacle is not "buy our product" — it is "white-label our DPDP consent layer as a Finacle DPDP Compliance Module." Infosys sells it to their bank clients. ConsentShield earns a per-seat licence fee. This is a partnership, not a direct sale.

This path bypasses the procurement cycle entirely. ConsentShield is validated by the core banking vendor's existing approval, not by its own.

**Path B: Small Finance Banks and Payment Banks**

India has 12 small finance banks (AU, Equitas, Ujjivan, Jana, Utkarsh, Suryoday, ESAF, North East, Shivalik, Fincare, Capital, Unity) and 6 active payment banks (Jio, Airtel, Fino, India Post, NSDL, Paytm in suspended state).

Small Finance Banks have procurement cycles of 6–10 weeks for point solutions — not 6–18 months. They are RBI-regulated (same compliance obligations as private banks), tech-forward in their operations, and do not have the institutional inertia of HDFC or ICICI. AU Small Finance Bank and Equitas have product teams that evaluate and procure SaaS tools on a cycle comparable to a mid-size fintech.

One SFB customer is a credible reference for: (a) other SFBs, (b) payment banks, and (c) the digital arms of large private banks. The proof point travels.

**Path C: Digital Arms of Large Private Banks**

Kotak Mahindra Bank's 811 digital account, DBS Digibank India, IndusInd Bank's digital retail division — these are effectively separate product organisations within the bank structure. They have their own product teams, technology budgets, and procurement processes that are meaningfully faster than their parent bank's enterprise procurement. They are also under identical DPDP obligations.

The head of product at Kotak 811 makes technology decisions differently from the Group CTO. The former is an accessible buyer; the latter is not.

### The Revised Position on Procurement

Procurement cycles are a sales motion constraint, not a segment barrier. The correct response is: don't sell to HDFC Bank's central IT procurement. Sell to AU Small Finance Bank, DBS Digibank, and Kotak 811 — and build a core banking vendor partnership in parallel. By the time a large private bank's procurement cycle completes, ConsentShield has reference customers from the same regulatory universe.

---

## Blocker 3: "Banks Already Have Compliance Machinery"

**Verdict: Weakest blocker. Substantially wrong. Banks have RBI compliance infrastructure. They have almost nothing for DPDP.**

### The Argument That Was Made

Banks already run compliance functions covering RBI IT Directions, KYC Master Directions, the Payment Aggregator framework, and the Fair Practices Code. Their compliance teams will extend existing processes to DPDP.

### Why This Is Wrong

RBI compliance and DPDP compliance address different legal obligations with different operational requirements. Having one does not give you the other.

The specific DPDP obligations that **no bank in India has currently operationalised**:

**1. Granular consent per purpose — Marketing specifically**

Banks currently obtain marketing consent buried in account opening forms — a single checkbox covering SMS, email, WhatsApp, and third-party sharing simultaneously. This does not satisfy DPDP Section 6, which requires consent to be "free, specific, informed, unconditional and unambiguous" and obtained "for each processing activity separately."

Every private bank in India has a marketing consent problem. Their current consent mechanism is not DPDP-compliant. They know this. No one has built the tooling to fix it.

**2. Right to Erasure with Regulatory Exemption Mapping**

When a customer closes an account and submits a DPDP erasure request, what does a bank do? PMLA mandates retention of KYC records for 5 years post-relationship. RBI KYC Directions mandate 8 years. DPDP grants the right to erasure. These are in direct conflict.

No bank has a system that:
- Receives the erasure request
- Categorises each data element by its statutory retention obligation
- Erases what is not statutorily protected
- Generates a response to the data principal explaining what was erased, what was retained, and under which law

ConsentShield's Regulatory Exemption Engine does exactly this. No other product in market does. This is the single most valuable capability ConsentShield has for the banking segment — not the consent banner.

**3. A DPDP-Compliant Data Principal Rights Portal**

Banks have grievance redressal portals (mandated by RBI). These are complaint management systems. They are not DPDP rights portals. DPDP creates four new data principal rights: access, correction, erasure, and nomination. These require a dedicated operational workflow with SLA timers (30 days), audit logs, and DPB-facing evidence.

No private bank in India has a DPDP rights portal. What they have is a grievance email address.

**4. 72-Hour DPB Breach Notification**

Banks have RBI IT incident reporting obligations (4-hour and 24-hour windows depending on severity). DPDP adds a separate obligation: notify the Data Protection Board within 72 hours of a personal data breach. This is a different regulator, a different notification format, and a different trigger definition.

Banks do not have a breach workflow that simultaneously handles RBI IT reporting and DPB breach notification. Their existing incident management process does not generate the DPB-required notification package.

**5. Third-Party Data Sharing Consent — Fintech Partners and Credit Bureaus**

Banks share customer data with: credit bureaus (CIBIL, Experian), insurance partners (bancassurance), fintech co-lending partners, payment aggregators, and marketing analytics platforms. Each of these data flows requires a DPDP-compliant consent artefact specifying the purpose, the data shared, and the recipient.

Banks currently handle this with blanket consent in the account opening form. Under DPDP, this is insufficient. The consent for each third-party sharing purpose needs to be independently revocable — meaning if a customer withdraws consent for insurance marketing, that specific sharing flow must stop, without affecting the bureau reporting that is a legitimate use.

This is precisely what DEPA-native artefacts solve. A single account opening consent event cannot handle this. Artefact-scoped consent per purpose can.

### What Banks Actually Need From ConsentShield

| DPDP Obligation | Current Bank State | ConsentShield Solution | Comparable Existing Tooling |
|---|---|---|---|
| Purpose-specific marketing consent | Bundled T&C checkbox, not DPDP-compliant | Consent banner with per-purpose artefacts, renewal workflow for existing customers | None — India-specific gap |
| Right to erasure + statutory exemption mapping | No operational workflow | Regulatory Exemption Engine | None — India-specific gap |
| Data principal rights portal | Grievance email, not a rights workflow | DSR inbox with SLA timers and audit trail | None — India-specific gap |
| 72-hour DPB breach notification | RBI incident reporting only | Guided DPB notification workflow | None — India-specific gap |
| Third-party sharing consent artefacts | Blanket T&C consent | Artefact-scoped per-purpose consent with revocation | None — India-specific gap |
| Cross-border transfer documentation | Informal, no structured tracking | Cross-border transfer module with per-flow documentation | OneTrust (₹50L/year, GDPR-built) |

Every single India-specific gap in this table is an unmet need that **no competing product** addresses. Banks are not covered. Their compliance machinery does not handle DPDP.

---

## What The Real Barriers Actually Are

Having dismantled the three stated blockers, here is an honest assessment of what genuinely makes the banking segment difficult:

### Real Barrier 1: Enterprise Sales Motion (Genuine)

Banks do not buy SaaS tools through self-serve trials. The sales process requires human engagement — a solutions consultant who can run a DPDP gap assessment, demonstrate ConsentShield's capabilities in a bank-relevant scenario, and navigate the internal approval process. This is a capability that does not currently exist at ConsentShield and must either be hired, contracted, or accessed through a partner.

**What this requires:** One dedicated enterprise sales/solutions person with banking sector relationships. Not a feature — a hiring or partnership decision.

### Real Barrier 2: Security Certification (Real but Tractable)

Banks will request, before final procurement approval: a VAPT report (vulnerability assessment and penetration testing), evidence of data processing security controls, and ideally a SOC 2 Type II or ISO 27001 certification. These are table stakes for a banking vendor.

**What this requires:**
- VAPT: ₹8–15 lakh, 6–10 weeks. Can begin immediately.
- SOC 2 Type II: ₹20–40 lakh, 9–12 months. Should begin by Month 6 of operations.
- ISO 27001: ₹10–20 lakh, 3–6 months. Can run in parallel with SOC 2.

These are costs and timelines, not blockers. They are investments that benefit every enterprise segment, not just banking.

### Real Barrier 3: First Reference Customer (Real, Self-Resolving)

No large private bank will be the first. The catch-22 is that banks want to see a peer bank reference, but someone has to go first. The resolution is the sequencing: SFBs → payment banks → digital arms → full private banks. An SFB is a legitimate regulatory peer — same RBI licensing class, same DPDP obligations, credible reference.

### Real Barrier 4: Integration Depth for Core Banking Systems (Real, Manageable)

Deletion orchestration at a bank requires connectors into Finacle or FLEXCUBE — the core banking system where customer records live. This is more complex than a Mailchimp or HubSpot connector. It requires a bank-specific integration project, not a pre-built connector.

**What this requires:** Either a professional services capability for bank-specific integration, or a partnership with a system integrator who has existing core banking expertise (TCS, Wipro, Infosys, Mphasis all have banking practices and could act as implementation partners).

---

## Revised Addressability Assessment

| Segment | Timeline | Entry Strategy | Revenue Potential |
|---|---|---|---|
| **Small Finance Banks** | Month 12–18 | Direct enterprise sale. AU SFB, Equitas, Ujjivan as priority targets. Positioned as "DPDP compliance layer for RBI-regulated entities." | ₹15–30 lakh/year per bank. 12 SFBs = ₹1.8–3.6 crore TAM |
| **Payment Banks** | Month 12–18 | Direct. Jio Payments Bank, Airtel Payments Bank, Fino. Digital-native, fast procurement. | ₹10–20 lakh/year. 6 payment banks |
| **Digital arms of large private banks** | Month 15–24 | Direct to product team at Kotak 811, DBS Digibank. Not through bank's central IT. | ₹20–40 lakh/year per arm |
| **Full private banks via core banking partner** | Month 18–30 | Partnership with Infosys Finacle or Oracle FLEXCUBE as DPDP add-on module. | ₹5–15 lakh per bank per year at scale, but 100+ banks reachable |
| **Large private banks — direct** | Month 24–36 | Only after SFB reference customers and SOC 2 certification. Positioned for compliance officer + DPO buyer. | ₹40–80 lakh/year per bank |

---

## The Correct Entry Sequence for Banking

### Preconditions (before banking sales begin)

1. 3+ NBFC customers on paid plans — establishes credibility in RBI-regulated segment
2. VAPT report completed — minimum security credibility for any bank conversation
3. Zero-Storage mode fully tested and documented — resolves the infrastructure question before it's asked
4. Regulatory Exemption Engine fully built — this is the primary differentiator for banks, more important than the consent banner

### Stage 1: Small Finance Banks (Month 12–18)

Target: AU Small Finance Bank, Equitas Small Finance Bank, Ujjivan Small Finance Bank.

Entry point: the right to erasure problem. The sales conversation is not "you need a consent banner." It is: "Your first DPDP erasure requests will arrive before May 2027. When a customer asks you to delete their data, which of their records can you erase and which must you retain under PMLA and RBI KYC Directions? Do you have a system that makes that determination and generates a compliant response? We have built one."

The Regulatory Exemption Engine is the door. Everything else follows.

### Stage 2: Core Banking Vendor Partnership (Month 15–24)

Parallel to Stage 1. Engage Infosys Finacle's partner programme. Finacle already sells compliance add-ons to bank clients. A DPDP consent layer that integrates with Finacle's customer data model is a product Infosys has a financial incentive to offer — it extends Finacle's value proposition without Infosys building the product themselves.

The partnership structure: ConsentShield provides the DPDP compliance layer, Infosys sells it to Finacle clients as a module, revenue shared. ConsentShield gets 100+ bank relationships without conducting 100+ independent sales cycles.

### Stage 3: Digital Arms and Payment Banks (Month 15–24)

DBS Digibank India has publicly committed to aggressive DPDP compliance. Kotak 811 operates as a technology-first product team. Airtel Payments Bank is owned by Bharti — a group comfortable with enterprise SaaS procurement.

These are faster procurement cycles than full private banks and generate the reference customer evidence needed for Stage 4.

### Stage 4: Full Private Banks (Month 24–36)

With: NBFC references, SFB references, SOC 2 Type II completed, core banking partner relationship, and VAPT on file — the conversation with HDFC Bank, ICICI Bank, and Axis Bank is a materially different conversation than it would be today. ConsentShield is no longer a new vendor asking for trust. It is the vendor that their SFB peers and their own core banking system provider already work with.

---

## The Revised Positioning for Banking

The segment brief positioned ConsentShield primarily around consent banners and the SEBI-DPDP conflict. For banking specifically, the hierarchy should be inverted:

**1. Lead with the Regulatory Exemption Engine** — "When your customers submit erasure requests, we automatically determine what can be erased and what is retained under PMLA and RBI KYC Directions, and we generate the compliant response. No bank has a system that does this." This is a problem every bank knows they have and no vendor has solved.

**2. Follow with the rights portal** — "Your grievance portal is not a DPDP rights portal. We convert it into one: access, correction, erasure, and nomination requests, each with a 30-day SLA timer, audit trail, and DPB-facing evidence pack."

**3. Then the consent infrastructure** — "Your marketing consent — SMS, email, WhatsApp, insurance partners — is currently bundled in the account opening T&C. Under DPDP, each purpose needs a separately revocable consent. We re-consent your existing customer base and manage ongoing consent per purpose."

The consent banner is not the entry point for banking. The erasure problem is.

---

## Summary: What It Takes to Address Private Banks

| What Needs to Happen | Category | Who Does It | Timeline |
|---|---|---|---|
| Zero-Storage mode documented for bank-specific deployment | Product | Dev | Already exists — needs documentation |
| VAPT report | Security | External vendor | 8–10 weeks from commission |
| SOC 2 Type II process begun | Security | Partner + external auditor | 9–12 months — begin Month 6 |
| Regulatory Exemption Engine completed | Product | Dev | Already planned for BFSI template |
| Enterprise sales capability | GTM | Partner hire or dedicated BD | Month 8 onwards |
| Finacle/FLEXCUBE partnership approach | GTM | Partner + Dev | Month 12 |
| SFB reference customer | GTM | Enterprise sales | Month 12–18 |
| Bank-specific core banking connector | Product | Dev + SI partnership | Month 18 |

**None of these are product architecture barriers. The stateless oracle architecture already solves the data sovereignty question. What remains is: security certification, enterprise sales motion, and sequenced entry through smaller RBI-regulated entities first.**

---

## The Honest Bottom Line

Private banks were labelled inaccessible for the wrong reasons. The infrastructure concern dissolves completely under Zero-Storage mode — the bank holds all data; ConsentShield is a processing API, not a data store. The compliance machinery concern is flat wrong — banks have significant, specific DPDP gaps that their existing RBI compliance processes do not address, and ConsentShield's Regulatory Exemption Engine is the most valuable solution in the market for their most difficult problem.

What is genuinely hard about banking: it requires enterprise sales capability, a security certification programme, and a sequenced entry through Small Finance Banks and core banking partnerships before large private banks become accessible.

Those are hard things. They are also achievable things. The banking segment should be in the 18–30 month roadmap, not excluded from it.

---

*April 2026 · Internal strategy document · Not for external distribution*
*For inclusion in next Master Design Document review cycle*
