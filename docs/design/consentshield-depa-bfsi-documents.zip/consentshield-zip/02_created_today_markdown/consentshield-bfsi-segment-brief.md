# ConsentShield — BFSI Segment Brief
## NBFCs & Digital Broking/Wealth Platforms

*Confidential — April 2026 · Addendum to Master Design Document v1.1*

---

## Table of Contents

1. [Segment Overview & Rationale](#1-overview)
2. [Why Not Private Banks (Yet)](#2-not-banks)
3. [Sub-Segment A: Digital NBFCs](#3-nbfcs)
4. [Sub-Segment B: Broking & Wealth Platforms](#4-broking)
5. [Regulatory Landscape — DPDP + RBI Overlay](#5-regulatory)
6. [Data Categories & DPDP Obligations](#6-data-obligations)
7. [Buyer Profile & Sales Motion](#7-buyer)
8. [Product Template — BFSI Configuration](#8-template)
9. [Pricing for BFSI](#9-pricing)
10. [Distribution & Channel](#10-distribution)
11. [Competitive Position in BFSI](#11-competitive)
12. [Risks & Mitigations](#12-risks)
13. [Entry Sequencing & Definition of Done](#13-sequencing)

---

## 1. Segment Overview & Rationale {#1-overview}

The BFSI segment for ConsentShield is not the traditional banking sector. Large private banks (HDFC, ICICI, Axis) have internal compliance teams, RBI-mandated data governance frameworks already in place, and enterprise procurement cycles incompatible with a self-serve SaaS product. They are not ConsentShield's buyer.

The opportunity sits one layer below — in two sub-segments that share the compliance urgency of large banks but have none of their internal infrastructure:

| Sub-Segment | Population | Avg. User Base | DPDP Urgency |
|---|---|---|---|
| **Digital NBFCs** | ~9,000 RBI-registered; ~1,500 digital-first | 50,000–5M borrowers | Extreme — financial + personal data, no compliance team |
| **Broking & Wealth Platforms** | ~500 SEBI-registered platforms; ~50 with digital self-serve | 500,000–10M users | High — KYC + transaction + behavioural data at scale |

Both sub-segments have three things in common with ConsentShield's best existing customers:

1. **Tech-first founding teams** who understand self-serve SaaS and can deploy in 48 hours without a procurement cycle.
2. **No dedicated DPDP compliance function** — their compliance teams handle RBI/SEBI regulations and have not yet mapped those to DPDP.
3. **Quantifiable penalty exposure** — user counts are known and large, making the ₹250 crore per violation calculation viscerally real in a sales conversation.

The BFSI template is **Phase 2 work** — it should not be built until the first 10–15 paying customers on Starter/Growth plans exist and the healthcare ABDM pilot commitments are secured. The strategic rationale for sequencing it now is to design the product correctly so the Fintech data model does not need to be retrofitted later.

---

## 2. Why Not Private Banks (Yet) {#2-not-banks}

This section exists to prevent scope creep. Private banks will ask about ConsentShield. The answer is not yet, and the reasons must be understood clearly.

### Three Structural Blockers

**Blocker 1 — RBI outsourcing guidelines**
RBI's Master Direction on IT Governance (2023) requires banks to maintain data localisation and imposes strict conditions on cloud service providers used for core banking data. ConsentShield's current architecture (Supabase on AWS, Cloudflare edge, Vercel serverless) has not been validated against these requirements and would require a formal cloud assessment before a private bank's risk committee would approve it.

**Blocker 2 — Procurement incompatibility**
A private bank vendor approval process involves VAPT (Vulnerability Assessment and Penetration Testing), a formal IT risk assessment, legal review of the SLA, and approval from their information security committee. This takes 6–18 months and requires dedicated sales and solutions engineering resources that don't exist at this stage.

**Blocker 3 — They already have compliance machinery**
DPDP is genuinely new obligation for banks, but it is additive to frameworks they already run — RBI's IT Directions, the Customer Service Master Circular, KYC Master Directions, the Payment Aggregator framework. Their compliance teams will extend existing processes to cover DPDP, often with Big 4 advisory support. They are not buying a new SaaS tool for this.

### The Exception: The Private Bank's Fintech Subsidiaries

HDFC Securities, ICICI Direct, Axis Direct, Kotak Securities — these are broking subsidiaries of private banks with their own tech stacks, compliance structures, and procurement processes. They are meaningfully more approachable than their parent banks and should be treated as broking platform targets, not bank targets. They are in scope for Sub-Segment B.

---

## 3. Sub-Segment A: Digital NBFCs {#3-nbfcs}

### Market Size

India has approximately 9,000 RBI-registered NBFCs. Of these:
- ~1,500 are digitally-operated (online loan origination, app-first, API-driven underwriting)
- ~500 are the primary targets: digital lending NBFCs with 50,000+ active borrowers, a modern tech stack, and no dedicated privacy compliance team

Key players in the target cohort: KreditBee, MoneyView, EarlySalary, Stashfin, Fibe (formerly EarlySalary), CASHe, Kissht, Nira, PaySense (now part of PayU), and the long tail of digital gold loan and BNPL operators.

### Why DPDP Urgency Is Highest Here

Digital lending NBFCs collect more sensitive personal data per user than almost any other digital business in India:

- PAN, Aadhaar (masked), date of birth — identity data
- Bank account statements (6–12 months) — financial data
- Employment details, salary slips — income data
- Device data, location, contact list (app permissions) — behavioural data
- Bureau data (CIBIL, Experian, CRIF) — credit data
- Repayment history — financial data

Every one of these categories is regulated under DPDP. Several — particularly Aadhaar-adjacent data and financial data — carry the highest penalty multipliers under the Act.

The specific operational problem for digital NBFCs under DPDP:

| DPDP Obligation | Current State at Most Digital NBFCs | ConsentShield Solution |
|---|---|---|
| Explicit consent per purpose | Generic app T&Cs cover everything. No granular consent. | Consent banner + purpose-specific consent flows |
| Contact list access consent | Collected under generic permission without DPDP-compliant notice | Consent artefact for app-level permissions |
| Right to erasure | No deletion workflow. Data retained indefinitely post-loan closure. | Deletion orchestration workflow |
| Data minimisation on bureau pulls | Bureau data retained permanently in underwriting DB | Retention schedule per data category |
| Consent for marketing after loan closure | Marketing list derived from borrower base without separate consent | Post-transaction consent re-verification |
| 72-hour breach notification | No breach response playbook | Breach notification workflow |

### The Contact List Permission Issue (High Priority Trigger)

Many digital NBFCs historically used contact list access as an informal collections enforcement mechanism — accessing borrowers' contacts and calling references without explicit consent. RBI's Guidelines on Digital Lending (2022) and the Fair Practices Code already restrict this. DPDP makes the legal exposure explicit and penalty-bearing.

This is a specific, urgent, documentable compliance gap that ConsentShield can use as an entry point conversation: *"How are you handling DPDP consent for the app permissions you request at onboarding? Contact list, location, camera — each needs a purpose-specific consent notice under DPDP S.5 and S.6."*

This is not a generic DPDP pitch. It is a specific problem with a specific regulatory hook that most digital NBFCs know they have not solved.

### Target Buyer at an NBFC

| Role | Title | Why They Buy |
|---|---|---|
| Primary | CTO / VP Engineering | Consent SDK, API integration, technical implementation |
| Economic | Chief Compliance Officer / Head of Risk | Regulatory obligation, penalty exposure, RBI audit readiness |
| Secondary | DPO (where appointed) | Operational tooling to fulfil statutory role |

The CTO is the technical champion. The CCO controls the budget. Sales conversations must address both — lead with the technical simplicity of the SDK integration, close with the penalty exposure calculation.

---

## 4. Sub-Segment B: Broking & Wealth Platforms {#4-broking}

### Market Size

India's retail investor base crossed 180 million registered investors (NSE) in 2025. The platforms serving them:

- **Discount brokers**: Zerodha, Groww, Upstox, Angel One, 5paisa — combined user base of 80M+
- **Wealth/MF platforms**: INDmoney, Kuvera, Coin (Zerodha), PaytmMoney, ET Money — combined user base of 20M+
- **Traditional brokers with digital arms**: HDFC Securities, ICICI Direct, Motilal Oswal, Sharekhan
- **Neo-brokers and derivatives platforms**: Dhan, Fyers, Samco

The primary ConsentShield targets are Tier 2 and Tier 3 platforms: Upstox, Angel One, 5paisa, INDmoney, Kuvera, Dhan, Fyers — companies large enough to have real compliance exposure but without the in-house compliance infrastructure of Zerodha or Groww.

### Why DPDP Urgency Is Real Here

Broking platforms are among the heaviest data processors in India outside of telecom. The data collected per user:

- PAN, Aadhaar, bank account — KYC data
- Income, net worth, risk tolerance — suitability assessment data
- Transaction history, holdings, P&L — financial data
- IP addresses, device IDs, login patterns — usage data
- Nominee details — third-party personal data
- Trading behaviour, watchlists, strategy indicators — behavioural data

The specific DPDP obligations that broking platforms face and have not fully addressed:

| Obligation | Problem | ConsentShield Solution |
|---|---|---|
| Purpose limitation on KYC data | KYC data used for cross-selling, marketing analytics — different purpose from collection | Purpose-gating consent module |
| Nominee data as third-party data | Nominee's personal data collected without their consent | Third-party data consent framework |
| Right to erasure vs SEBI retention | SEBI mandates 5–7 year record retention; DPDP grants erasure rights — direct conflict | Regulatory exemption mapping in deletion workflow |
| Marketing consent post-account opening | Existing users opted in under old T&Cs, not DPDP-compliant | Consent refresh campaign workflow |
| Data sharing with AMCs/depositories | Data shared with CAMS, KFintech, CDSL, NSDL — consent and data processor agreements | Third-party processor inventory |

### The SEBI-DPDP Conflict — A Specific Entry Point

Broking platforms face a genuinely difficult conflict: SEBI mandates that they retain certain records (contract notes, transaction records) for 5–7 years. DPDP grants data principals the right to erasure. These obligations are directly in tension.

ConsentShield can be the first product to address this conflict with a structured regulatory exemption mapping — pre-built logic that identifies which data categories are exempted from erasure by statutory retention obligations (SEBI, RBI, IT Act), and which must be erased on request. No existing DPDP tool has built this. It is a genuine competitive moat in the BFSI vertical.

### Target Buyer at a Broking Platform

| Role | Title | Why They Buy |
|---|---|---|
| Primary | CTO / VP Product | SDK integration, consent flows in onboarding, API |
| Economic | Chief Compliance Officer / VP Legal | SEBI + DPDP dual obligation, audit readiness |
| Influencer | Head of Growth/Marketing | Consent for marketing lists, WhatsApp opt-ins, push campaigns |

---

## 5. Regulatory Landscape — DPDP + RBI Overlay {#5-regulatory}

The BFSI template is more complex than the SaaS or D2C templates because DPDP operates alongside — not instead of — existing RBI and SEBI regulatory frameworks. Every ConsentShield implementation for a BFSI customer must account for this stack.

### The Regulatory Stack

```
DPDP Act 2023 + Rules 2025
    │
    ├─ For NBFCs: RBI Master Directions
    │   ├─ KYC Master Directions (2016, updated 2023) — identity data retention
    │   ├─ Digital Lending Guidelines (2022) — app permissions, data collection limits
    │   ├─ Fair Practices Code — transparency in data use
    │   └─ IT Governance Master Direction (2023) — data localisation, cloud
    │
    └─ For Broking: SEBI Regulations
        ├─ SEBI (LODR) Regulations — record retention obligations
        ├─ Prevention of Money Laundering Act (PMLA) — KYC record retention 5 years
        ├─ SEBI Circular on Cybersecurity (2023) — data breach obligations
        └─ SEBI (Investment Advisers) Regulations — suitability data
```

### Key Intersections ConsentShield Must Handle

**Intersection 1 — Statutory retention vs. right to erasure**
RBI KYC Directions mandate minimum 8-year retention post-account closure. PMLA mandates 5 years. DPDP's right to erasure cannot override statutory retention obligations. ConsentShield's deletion workflow must identify which data falls under statutory retention exemption and communicate this clearly to the data principal when they exercise their erasure right.

**Intersection 2 — Consent vs. legitimate use**
RBI's Digital Lending Guidelines restrict app-level data collection (contact list, call logs, photos) to what is specifically required for credit assessment. DPDP requires consent for each category. The intersection creates a double obligation: restrict collection *and* get consent for what is collected. The BFSI template must pre-configure the consent purposes to align with RBI's permitted categories, not allow customers to configure consent for RBI-restricted data categories.

**Intersection 3 — Breach notification timelines**
DPDP requires breach notification to the Data Protection Board within 72 hours. SEBI's cybersecurity circular requires notification to SEBI within 6 hours of a cybersecurity incident. The breach workflow must flag the faster SEBI obligation when the affected data includes trading account or demat account data.

### What ConsentShield Does NOT Do in BFSI

ConsentShield is consent and rights management infrastructure. It is not:
- A KYC verification system
- An AML/CFT compliance tool
- A SEBI reporting or filing tool
- A substitute for RBI compliance advisory

All BFSI templates carry this explicit disclaimer. The DPO-as-a-Service partner carries legal liability for BFSI compliance advice. ConsentShield carries software liability.

---

## 6. Data Categories & DPDP Obligations {#6-data-obligations}

### BFSI-Specific Data Inventory (Pre-Seeded in Template)

| Data Category | DPDP Classification | Consent Required | Retention Trigger | Deletion Exemption |
|---|---|---|---|---|
| PAN | Personal data | Yes — KYC purpose | Closure + 8 years (RBI) | Yes — statutory |
| Aadhaar-derived | Sensitive personal data | Yes — identity verification only | Closure + 8 years | Yes — statutory |
| Bank statements | Financial personal data | Yes — credit assessment | Closure + 8 years (RBI) | Yes — statutory |
| Contact list (app) | Personal data of third parties | Yes — each contact is a data principal | Loan repayment | No exemption |
| Location data | Personal data | Yes — per-session | Session end | No exemption |
| Device fingerprint | Personal data | Yes — fraud prevention | 12 months | No exemption |
| Bureau data (CIBIL pull) | Financial personal data | Yes — credit inquiry consent | 24 months | Partial |
| Marketing preferences | Personal data | Yes — separate from KYC consent | Until withdrawal | No exemption |
| Trading history | Financial personal data | Yes — account operation | Closure + 5 years (PMLA) | Yes — statutory |
| Nominee details | Third-party personal data | Yes — separate consent for nominee | Account duration | Partial |
| Suitability assessment | Sensitive financial data | Yes — regulatory | Closure + 5 years (SEBI) | Yes — statutory |

### The Third-Party Data Problem

Broking platforms collecting nominee data, and NBFCs collecting guarantor/reference data, are processing personal data of individuals who are not the primary customer. These third parties have full DPDP rights as data principals — including the right to access, correct, and erase their data — but they have never interacted with the platform.

ConsentShield must provide a third-party data consent flow: a mechanism to notify nominees, guarantors, and references that their data has been collected and to provide them with a rights portal. No existing DPDP tool has built this for BFSI. It is a meaningful differentiation.

---

## 7. Buyer Profile & Sales Motion {#7-buyer}

### Ideal Customer Profile — BFSI

| Attribute | NBFC Target | Broking Target |
|---|---|---|
| RBI/SEBI registration | Active NBFC registration | SEBI-registered broker/IA |
| User base | 50,000–5M active borrowers | 200,000–5M registered investors |
| Tech stack | In-house app (iOS/Android) + loan origination system | In-house trading app + back-office system |
| Compliance team | 2–5 person team, no DPDP specialist | 3–8 person team, no DPDP specialist |
| Decision-making | CTO + CCO jointly | CTO + CCO jointly |
| Budget authority | ₹5–20 lakh/year compliance tools | ₹5–20 lakh/year compliance tools |
| Procurement | 4–8 weeks (fast relative to banking) | 4–8 weeks |

### Why Self-Serve Works Here

Digital NBFCs and tech-first broking platforms are built by the same engineering culture as SaaS companies. Their CTOs are comfortable with self-serve SaaS evaluation. The gap assessment tool, a working BFSI-specific demo environment, and a 14-day trial with the BFSI template pre-loaded are sufficient for technical evaluation.

The CCO/CCO sign-off requires a different conversation — a penalty exposure briefing and a regulatory overlap document showing how ConsentShield handles the DPDP+RBI/SEBI intersection. This is not a product demo — it is a 30-minute regulatory briefing.

### Sales Conversation Framework

**Opening hook (NBFC):**
*"Under DPDP, every app permission you request — contact list, location, camera — needs a purpose-specific consent notice. You're also required to give borrowers a right to erase that data after their loan is closed. What does that workflow look like in your system today?"*

**Opening hook (Broking):**
*"SEBI mandates 5-year record retention. DPDP grants your users a right to erasure. These directly conflict. What happens when a user submits a deletion request — how does your team determine what can be erased and what must be retained?"*

Both hooks identify a specific, unresolved operational problem that the prospect knows they have. The answer to both is almost always: *"We haven't figured that out yet."* That is the opening.

### Channel Fit

| Channel | NBFC | Broking |
|---|---|---|
| Direct (LinkedIn outreach) | Primary | Primary |
| CA/CS firms | Secondary — compliance team advisors | Secondary |
| RBI/SEBI compliance consultants | High value — they recommend tools | High value |
| Fintech communities (FinTech Festival India, NASSCOM FinTech) | Conference presence | Conference presence |
| FIDC (Finance Industry Development Council) | NBFC association — newsletter/partnership | N/A |
| AMFI / SEBI investor education forums | N/A | Association access |

---

## 8. Product Template — BFSI Configuration {#8-template}

### What the BFSI Template Pre-Configures

| Component | NBFC Pre-configuration | Broking Pre-configuration |
|---|---|---|
| **Data inventory** | PAN, Aadhaar-derived, bank statements, bureau data, contact list, location, device, employment, repayment history | PAN, Aadhaar-derived, bank account, trading history, nominee details, device, location, suitability data |
| **Consent purposes** | Identity verification, credit assessment, fraud prevention, collections communication, marketing (separate) | Identity verification, account operation, regulatory compliance, investment advisory, marketing (separate) |
| **Privacy notice** | RBI Digital Lending Guidelines-compliant language, DPDP-compliant disclosures | SEBI-compliant language, DPDP-compliant disclosures |
| **Retention defaults** | KYC: 8 years; Bureau: 24 months; Contact list: loan duration; Marketing: until withdrawal | KYC: 8 years; PMLA: 5 years; Trading records: 5 years; Marketing: until withdrawal |
| **Deletion exemptions** | RBI KYC, PMLA, IT Act — pre-mapped per data category | SEBI LODR, PMLA, IT Act — pre-mapped per data category |
| **Third-party data module** | Guarantor/reference consent flow | Nominee consent flow |
| **Breach workflow** | 72-hour DPB notification + RBI notification trigger | 72-hour DPB notification + 6-hour SEBI cybersecurity notification trigger |
| **Rights portal** | Standard DSR inbox + exemption-aware deletion workflow | Standard DSR inbox + exemption-aware deletion workflow |
| **Tracker allowlist** | Loan origination analytics (excluded from consent enforcement) | Trading analytics (excluded from consent enforcement) |

### New Feature Required: Regulatory Exemption Engine

This is the one product build that BFSI requires beyond the existing feature set. The deletion workflow today (Phase 1) processes erasure requests without checking against statutory retention obligations. For BFSI, this will result in ConsentShield instructing a deletion that violates RBI/SEBI rules — a serious problem.

The Regulatory Exemption Engine is a pre-built lookup table:

```
Input: data_category + data_principal_id + deletion_request_timestamp

Logic:
  1. Look up data category in retention_rules table
  2. Check if statutory_retention_exempt = true
  3. If yes: calculate exempt_until date
  4. If current_date < exempt_until: return CANNOT_DELETE with explanation
  5. If current_date >= exempt_until: return CAN_DELETE, proceed with deletion
  6. Generate response to data principal: explains which data was deleted and which is retained under statutory obligation, cites the specific regulation

Output: Deletion confirmation report with statutory exemption annotations
```

This is approximately 2 weeks of build, and it applies beyond BFSI — healthcare has similar retention obligations (ABDM records). Build it once, parameterise by vertical.

### SDK Integration Points for BFSI

BFSI customers have mobile apps (iOS/Android) as their primary customer touchpoint, not just web. The existing banner.js covers web. BFSI requires:

1. **Mobile consent SDK** — iOS and Android native wrappers around the consent API, so consent flows can be embedded in loan origination and account opening app flows. This is Phase 2 work already contemplated in the v2 blueprint.
2. **App permission consent handler** — specific flows for Android's runtime permission requests (contact list, location, camera) that generate DPDP-compliant consent artefacts at the moment of permission grant.
3. **API-first consent verification** — for NBFC underwriting APIs, a server-side check that verifies consent exists for a data category before the data is passed to the underwriting engine.

---

## 9. Pricing for BFSI {#9-pricing}

BFSI customers have larger user bases and higher penalty exposure than the average SaaS startup. Pricing must reflect this without creating a self-serve barrier.

### Recommended Pricing Tiers for BFSI

| Tier | Price | User Base | Key Inclusions |
|---|---|---|---|
| **BFSI Starter** | ₹8,000/month | Up to 1 lakh data principals | Core consent + rights portal + BFSI template + regulatory exemption engine |
| **BFSI Growth** | ₹18,000/month | Up to 10 lakh data principals | Starter + third-party data module + mobile SDK + multi-app support |
| **BFSI Enterprise** | ₹40,000+/month | 10 lakh+ data principals | Growth + custom retention rules + API SLA + DPO-as-a-Service + dedicated onboarding |

Anchoring comparison: A Big 4 firm's DPDP readiness assessment for an NBFC costs ₹8–20 lakh as a one-time engagement. ConsentShield at ₹18,000/month is ₹2.16 lakh/year — a fraction of the cost, running continuously, generating audit evidence every day.

### Penalty Exposure Calculator (Sales Tool)

For BFSI sales conversations, build a simple calculator into the gap assessment landing page variant:

```
Inputs: registered users (data principals), data categories collected
Output: estimated penalty exposure at ₹250 crore per violation × violation categories

Example: 
  - 5 lakh borrowers × contact list permission without DPDP consent = 1 violation category
  - 5 lakh borrowers × no right-to-erasure workflow = 1 violation category  
  - 5 lakh borrowers × no breach notification process = 1 violation category
  - Estimated cumulative exposure: ₹250 crore × 3 = ₹750 crore
  
This is not a legal opinion. It is a directional exposure estimate.
```

The calculator does not need to be accurate — it needs to make the exposure visceral. An NBFC with 5 lakh borrowers looking at ₹750 crore exposure justifies ₹18,000/month without further conversation.

---

## 10. Distribution & Channel {#10-distribution}

### Primary Channels

**FIDC (Finance Industry Development Council)**
The NBFC industry association. A speaking slot or newsletter placement at FIDC reaches compliance teams across the NBFC ecosystem. Target: one FIDC event sponsorship or speaker slot by Month 12.

**SEBI-registered compliance consultants**
Similar to the CA partner channel for SMBs, SEBI-registered compliance officers and AMFI-registered MFDs who advise on regulatory compliance can refer broking clients. Referral structure: 20% first-year revenue share.

**Fintech-focused law firms**
Saraf and Partners, Khaitan & Co (fintech practice), Trilegal, Cyril Amarchand Mangaldas — all have fintech regulatory practices. A DPO-as-a-Service partnership with a fintech regulatory lawyer from one of these firms creates a referral channel and adds the legal liability layer ConsentShield needs for BFSI clients.

**LinkedIn outreach — CCO and CTO at target companies**
The compliance officer community in Indian fintech is small and connected. A single case study from an NBFC customer becomes a reference for 20 others. The outreach sequence:

1. Share the SEBI-DPDP conflict brief as a LinkedIn article (content play)
2. DM the CCOs of target NBFCs with the specific contact list permission hook
3. Offer a free gap assessment — BFSI-specific — as the entry point

### Content Play — BFSI-Specific

Two pieces of content create the BFSI inbound pipeline:

**"The SEBI-DPDP Conflict: A Compliance Officer's Guide"**
A 2,000-word explainer on the regulatory overlap — what must be retained, what must be deleted, how to communicate this to users. This is genuinely novel and has no existing equivalent. It will be shared by fintech compliance teams organically.

**"DPDP Readiness Checklist for Digital Lenders"**
An NBFC-specific variant of the existing gap assessment tool, with the contact list permission, bureau data consent, and breach notification workflow as the three key gaps. Gate with email to generate NBFC-specific leads.

---

## 11. Competitive Position in BFSI {#11-competitive}

| Competitor | Approach | Why ConsentShield Wins in BFSI |
|---|---|---|
| **OneTrust** | Enterprise GRC, $50,000+/year | No RBI/SEBI overlay. Built for GDPR. No NBFC-specific data categories. Not priced for growth-stage fintech. |
| **Signzy / IDfy** | KYC/identity platforms, not consent | They solve KYC onboarding. They do not solve DPDP consent, rights management, or breach workflows. Different product entirely. |
| **Razorpay Compliance (rumoured)** | Internal compliance tooling for Razorpay's merchants | Limited to payment data. Does not cover credit, investment, or insurance data. No rights management. |
| **Big 4 advisory** | One-time gap assessment, ₹8–20 lakh | One-time document. No operational tooling. No ongoing monitoring. No audit trail. |
| **In-house build** | Engineering team builds consent flows internally | 3–6 month build, no DPDP legal expertise in engineering team, no ongoing updates when DPB issues guidance. |

The specific BFSI moat: **no existing tool has mapped the SEBI-DPDP and RBI-DPDP intersections into operational software.** The regulatory exemption engine, the third-party data consent flow for nominees and guarantors, and the dual breach timeline (72 hours DPB + 6 hours SEBI) are genuinely novel in the market. This moat is time-limited — 6–9 months before a well-funded competitor enters — but it is real.

---

## 12. Risks & Mitigations {#12-risks}

| Risk | Severity | Mitigation |
|---|---|---|
| **Product guidance on RBI/SEBI conflicts is incorrect, creating liability** | HIGH | The regulatory exemption engine must be validated by a fintech lawyer before shipping. Do not position ConsentShield as regulatory advice. Every BFSI template carries a prominent disclaimer. The fintech DPO-as-a-Service partner carries legal liability. |
| **Procurement at NBFCs slower than expected** | MEDIUM | Even Tier 2 NBFCs have compliance committees that may require a vendor security review. Build a lightweight security posture document (SOC 2 readiness summary, data residency confirmation, penetration test scope) to pre-empt this. Do not start the BFSI build until 3 NBFCs commit to a paid pilot. |
| **Mobile SDK adds significant build scope** | MEDIUM | Ship the BFSI web template first. Mobile SDK is Phase 2. NBFCs with web-based onboarding can implement immediately; app-only NBFCs wait for Phase 2 mobile SDK. Be explicit about this limitation in sales conversations. |
| **RBI or SEBI issues guidance that conflicts with ConsentShield's interpretation** | MEDIUM | Monitor RBI circulars and SEBI notifications monthly. Subscribe to the FIDC regulatory update newsletter. The regulatory exemption engine must be updatable within 48 hours of new guidance. |
| **Large NBFC requires on-premise deployment** | LOW-MEDIUM | Position the current cloud architecture as the standard offering. On-premise is not in scope for Year 1. If a large NBFC requires it, defer to the Enterprise partnership model and introduce a system integrator. |
| **Contact list permission issue creates reputational risk for ConsentShield** | LOW | ConsentShield's product helps NBFCs become compliant — it does not enable the problematic contact list practices. The product is the solution, not the problem. Positioning must be careful: ConsentShield helps NBFCs establish DPDP-compliant consent, not enable invasive data collection. |

---

## 13. Entry Sequencing & Definition of Done {#13-sequencing}

### When to Start BFSI

BFSI is **not Phase 1 work**. The entry conditions are:

1. At least 10 paying customers on any plan (validates the self-serve motion works)
2. Healthcare ABDM: 3 pilot commitments in writing (de-risks the ABDM build)
3. The Fintech sector template is spec'd (it is in the v2 blueprint — use that as the foundation)
4. One fintech regulatory lawyer engaged as a DPO-as-a-Service partner before the first BFSI customer onboards

If these conditions are met by Month 8–10, the BFSI build can run in parallel with the healthcare ABDM build in Phase 3.

### Build Sequence

| Week | Deliverable |
|---|---|
| 1–2 | BFSI data inventory and consent purposes finalised with fintech lawyer review |
| 3–4 | Regulatory exemption engine built and tested against RBI KYC, PMLA, SEBI LODR |
| 5–6 | Third-party data consent flow (nominee/guarantor) built |
| 7 | BFSI template assembled, dual breach timeline configured |
| 8 | First NBFC pilot onboarded. First broking platform gap assessment completed. |

### Definition of Done — BFSI Phase

| Deliverable | Success Criterion |
|---|---|
| BFSI Template Live | NBFC and Broking configurations available at signup. Regulatory exemption engine operational. |
| Fintech DPO Partner Engaged | One fintech regulatory lawyer available as DPO-as-a-Service for BFSI Enterprise customers |
| BFSI Content Live | SEBI-DPDP conflict article published. NBFC gap assessment tool live with BFSI-specific questions. |
| First Revenue | 3 BFSI customers on BFSI Growth plan. ₹54,000/month from BFSI segment. |
| Pipeline | 5 active BFSI trials in progress by end of BFSI launch month |

---

*Document prepared April 2026. Addendum to ConsentShield Master Design Document v1.1.*
*Regulatory references: DPDP Act 2023, DPDP Rules 2025, RBI KYC Master Directions 2016 (updated 2023), RBI Digital Lending Guidelines 2022, RBI IT Governance Master Direction 2023, SEBI LODR Regulations, PMLA 2002, SEBI Cybersecurity Circular 2023.*
*All regulatory positions must be validated by a qualified fintech lawyer before use in customer-facing materials.*

consentshield.in · Hyderabad, India
