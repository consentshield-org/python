# ConsentShield — Why DEPA-Native Architecture Is the Only Viable Model for Banking
## The Third-Party Sharing Consent Problem and Why GDPR-Style Models Cannot Solve It

*April 2026 · Bridging document: DEPA Architecture ↔ BFSI Segment*
*Companion to: consentshield-depa-architecture.md, ConsentShield-BFSI-Segment-Brief-v2.docx*

---

## The Problem in One Paragraph

A private bank customer opens an account. At the point of account opening, the bank obtains consent for: (1) credit bureau reporting to CIBIL, (2) cross-selling insurance products via a bancassurance partner, (3) sharing data with a co-lending fintech for a loan product, (4) WhatsApp marketing, and (5) analytics on their banking app behaviour. Two years later, that customer decides they no longer want insurance cross-selling. Under DPDP Section 6, they have the right to withdraw that specific consent without it affecting any other purpose. The bank must stop the insurance data flow, continue the bureau reporting, continue the fintech co-lending data share, and continue the analytics. They must do this surgically — stopping exactly the right flow, leaving the others intact.

No GDPR-adapted consent tool in the market can execute this. ConsentShield's DEPA-native artefact model is the only architecture that can — and this document explains precisely why.

---

## 1. The GDPR Event Model and Why It Fails Banks

Every competitor in the Indian DPDP compliance market — OneTrust, CookieYes, Privy by IDfy, GoTrust — stores consent using a GDPR-adapted model: a single consent event row with an array of accepted purpose labels.

```
// GDPR-style event model — what every competitor stores
{
  user_id: "user_xyz",
  timestamp: "2024-01-15T09:23:00Z",
  purposes_accepted: [
    "bureau_reporting",
    "insurance_marketing",
    "co_lending_partner",
    "whatsapp_marketing",
    "analytics"
  ]
}
```

This is a single record. Consent is monolithic.

When the user withdraws insurance marketing consent, the system has two options:

**Option A — Update the array in place:**
```
purposes_accepted: [
  "bureau_reporting",
  // "insurance_marketing" ← removed
  "co_lending_partner",
  "whatsapp_marketing",
  "analytics"
]
```

This mutates the original consent record. The audit trail is corrupted — there is no longer a record of what the user consented to originally, only what the current state of the array is. Under DPDP, the bank must be able to prove what was consented to, when, and under what notice. Mutating the record destroys that evidence.

**Option B — Write a new withdrawal event:**
```
{
  user_id: "user_xyz",
  timestamp: "2026-03-10T14:05:00Z",
  event_type: "consent_withdrawn",
  purposes_withdrawn: ["insurance_marketing"]
}
```

Better for audit trail — the original event is preserved. But now the deletion orchestration has a precision problem. The system knows `insurance_marketing` consent was withdrawn. But what does that mean for the data flows? Which systems hold the user's data under the `insurance_marketing` purpose? The event model has no structured answer — it has a purpose label, not a data scope declaration. The deletion connector has to guess which systems to call, or call all of them, or require manual configuration per purpose.

More fundamentally: **the event model has no concept of which data flows the `insurance_marketing` purpose authorised**. It knows the user withdrew something called "insurance_marketing." It does not know that "insurance_marketing" covered `email_address`, `name`, `date_of_birth`, and `account_type` — and that those specific fields are what the bancassurance partner holds, and not what CIBIL holds, and not what the co-lending fintech holds.

When the deletion cascade fires, it cannot be surgical. It has no data scope. It has no connector mapping. It either does too little (sends an alert but cannot automate deletion) or too much (blanket-deletes the user from systems that are still authorised to hold their data, violating the bank's own data retention obligations for those purposes).

This is not a minor gap. For a bank with five active third-party sharing relationships, a single imprecise deletion event could:
- Accidentally delete bureau reporting data that CIBIL is required to retain
- Remove a customer from the co-lending fintech's system mid-loan
- Trigger a PMLA compliance failure by deleting records during the mandatory retention window

A tool that cannot execute surgical, purpose-scoped consent withdrawal is not a DPDP compliance tool. It is a liability.

---

## 2. The DEPA Artefact Model — How It Solves This

Under ConsentShield's DEPA-native model, the bank account opening interaction does not produce one consent event. It produces five consent artefacts — one per purpose:

```
Account opening interaction → consent_events row (the interaction log)
                            ↓
                    Five artefact rows created:

cs_art_01HXX1  bureau_reporting
  data_scope: ['pan', 'aadhaar_ref', 'account_type', 'repayment_history']
  authorises: CIBIL_connector, Experian_connector, CRIF_connector
  expires_at: 2025-01-15  (1 year)
  status: active

cs_art_01HXX2  insurance_marketing
  data_scope: ['email_address', 'name', 'dob', 'account_type', 'nominee_name']
  authorises: bancassurance_partner_connector
  expires_at: 2025-01-15  (1 year)
  status: active

cs_art_01HXX3  co_lending_fintech
  data_scope: ['pan', 'account_balance', 'transaction_count_6m', 'income_estimate']
  authorises: fintech_partner_api_connector
  expires_at: 2025-01-15  (1 year)
  status: active

cs_art_01HXX4  whatsapp_marketing
  data_scope: ['mobile_number']
  authorises: whatsapp_business_connector
  expires_at: 2025-01-15  (1 year)
  status: active

cs_art_01HXX5  analytics
  data_scope: ['device_id', 'session_data', 'feature_usage']
  authorises: analytics_platform_connector
  expires_at: 2025-01-15  (1 year)
  status: active
```

Each artefact is:
- **Independently addressable** — stable `cs_art_` ID, permanently referenceable in any audit
- **Data-scoped** — declares exactly which data fields it covers
- **Connector-mapped** — knows which downstream systems it authorises
- **Time-bounded** — has an explicit `expires_at`, not open-ended consent
- **Lifecycle-managed** — can move from `active` to `revoked`, `expired`, or `replaced` independently

### 2.1 The Surgical Withdrawal

When the customer withdraws insurance marketing consent:

```
User action → POST /v1/consent/withdraw { artefact_id: "cs_art_01HXX2" }
                    │
                    ▼
artefact_revocations INSERT
  artefact_id: cs_art_01HXX2
  revoked_at: 2026-03-10T14:05:00Z
  reason: user_request
  immutable: true
                    │
                    ▼
cs_art_01HXX2 status → 'revoked'
  Removed from consent_artefact_index (validity cache)
                    │
                    ▼
Deletion orchestration — artefact-scoped:
  data_scope from cs_art_01HXX2: ['email_address', 'name', 'dob', 'account_type', 'nominee_name']
  connector from purpose_connector_mappings: bancassurance_partner_connector
                    │
                    ▼
DELETE from bancassurance_partner:
  fields: email_address, name, dob, account_type, nominee_name
  for user: user_xyz
  triggered_by_artefact: cs_art_01HXX2
  receipt_id: del_rcpt_01HXX9  (immutable confirmation)

cs_art_01HXX1 (bureau_reporting) → UNTOUCHED. Still active.
cs_art_01HXX3 (co_lending_fintech) → UNTOUCHED. Still active.
cs_art_01HXX4 (whatsapp_marketing) → UNTOUCHED. Still active.
cs_art_01HXX5 (analytics) → UNTOUCHED. Still active.
```

**The bureau is still reporting. The fintech partner still has its data. The analytics platform still tracks app behaviour. Only the bancassurance partner's data is deleted — because only cs_art_01HXX2 was revoked.**

The audit trail is complete and unbroken: the original five artefacts still exist as immutable records of what was consented to. The revocation is a new immutable record on top. Nothing was mutated. The chain of custody — consent grant → data use → withdrawal → deletion receipt — is fully navigable in a single query.

---

## 3. Banking-Specific Scenarios Where DEPA Architecture Is Decisive

### 3.1 Bureau Reporting — The Data That Cannot Be Revoked

Credit bureau reporting is a legitimate business purpose that banks are obligated to continue even when a customer withdraws other consents. CIBIL and other bureaus receive repayment data to maintain credit scores — this is a regulatory necessity, not a marketing preference.

Under a GDPR event model: if a bank customer withdraws all marketing consent and the system triggers a blanket deletion, it risks deleting data from CIBIL's connector. This would be a Credit Information Companies Act violation, not a DPDP compliance win.

Under the DEPA artefact model: the bureau reporting artefact (`cs_art_01HXX1`) has its own lifecycle, independent of the marketing artefact. It also benefits from the Regulatory Exemption Engine — when a full account erasure request is received, the system checks whether `bureau_reporting` data is under a statutory retention obligation (it is — Credit Information Companies Regulation Act, RBI KYC Directions) before triggering deletion. The erasure request is processed for eligible artefacts only; bureau data is flagged as statutorily retained with the specific regulation cited.

**The DEPA model is the only architecture that can handle this distinction automatically. A GDPR event model requires manual case-by-case adjudication by a compliance officer.**

### 3.2 Bancassurance — High-Volume, High-Value Third-Party Sharing

Most large private banks have bancassurance partnerships — they cross-sell life insurance, health insurance, and term insurance to their customer base. This requires sharing customer data (contact details, demographics, account type, product holdings) with an insurance partner.

This is explicitly regulated under DPDP. The consent for bancassurance data sharing must be:
- Separate from the account opening consent (it is a distinct purpose)
- Independently revocable (the customer can stop insurance cross-selling without closing their account)
- Purpose-limited (only the data needed for insurance cross-selling, not the full banking profile)

The `data_scope` field in cs_art_01HXX2 (`insurance_marketing`) captures exactly which fields the bancassurance partner receives. When that artefact expires or is revoked, the deletion connector knows to remove `email_address`, `name`, `dob`, `account_type`, and `nominee_name` from the partner's systems — and only those fields.

The bank cannot fulfil this obligation with a GDPR event model. There is no mechanism in the event model to specify which fields the insurance partner holds, map them to the purpose category, and cascade a field-level deletion when consent is withdrawn. The connector would have to delete the entire customer record from the insurance partner's system — which may violate the partner contract — or do nothing except send an email notification.

### 3.3 Co-Lending Fintech Partners — Mid-Transaction Complexity

Banks increasingly co-lend with NBFCs and fintechs. Data sharing in co-lending is bidirectional: the bank shares the customer's financial profile with the fintech; the fintech originates and services the loan; repayment data flows back to the bank and the bureau.

If a customer withdraws their co-lending consent mid-loan, the situation is complex:

- The **prospecting phase** data (shared before loan origination) can potentially be erased
- The **loan agreement data** (shared after origination) is likely exempt under PMLA and the Banking Regulation Act
- The **repayment data** flowing back to the bureau is exempt under Credit Information Companies regulation

The DEPA artefact model handles this through the Regulatory Exemption Engine: when the `co_lending_fintech` artefact is revoked, each data element in `data_scope` is checked against the statutory retention lookup before deletion is triggered. The customer receives a compliant response explaining which data was deleted (prospecting data) and which is retained under which law (loan agreement data under Banking Regulation Act, repayment history under Credit Information Companies Act).

A GDPR event model cannot make this determination. It does not know the data scope of the co-lending purpose, does not have a statutory retention lookup, and cannot generate the legally required response to the data principal.

### 3.4 WhatsApp Marketing — The Consent Refresh Problem

Indian banks are among the most active WhatsApp Business API users — account alerts, loan offers, insurance cross-sells, and credit card marketing all flow through WhatsApp. WhatsApp marketing consent was historically obtained through account opening T&Cs, not as a standalone purpose.

Under DPDP Section 6, this bundled consent is non-compliant. The bank must run a consent refresh — re-obtaining WhatsApp marketing consent as a standalone, independently revocable purpose.

The DEPA model makes the consent refresh audit-verifiable:

1. The bank runs a WhatsApp message campaign: "Click here to confirm you're happy to receive offers from us via WhatsApp"
2. Each customer who confirms generates a new `cs_art_whatsapp_marketing` artefact
3. Each artefact records: what the customer was told (the purpose definition), when they consented, which banner version they saw, and when the consent expires
4. The compliance dashboard shows what percentage of WhatsApp marketing recipients have a valid DPDP-compliant artefact
5. Customers without a valid artefact are automatically suppressed from WhatsApp campaigns by the artefact validity check

A GDPR event model can record that a re-consent happened. It cannot generate artefacts with defined expiry windows, cannot suppress non-consenting customers at the API layer based on artefact validity, and cannot show a compliance dashboard that distinguishes between customers with valid DEPA-compliant consent and those with legacy bundled T&C consent.

### 3.5 App Analytics — Purpose Limitation in Practice

Banking apps collect significant behavioural data — which features are used, how long sessions last, what products are viewed, where drop-offs occur. Under DPDP, this analytics data collection requires separate consent and is subject to purpose limitation.

The `analytics` artefact (`cs_art_01HXX5`) scopes the data to `['device_id', 'session_data', 'feature_usage']`. The analytics platform connector is authorised only for these fields.

If a bank's analytics platform later requests additional data fields — say, location data for branch recommendation features — that is a new purpose requiring a new consent interaction and a new artefact. The existing analytics artefact cannot be stretched to cover it; its `data_scope` is immutable at creation time.

This immutability is precisely what DEPA requires and what the GDPR event model cannot enforce. In the event model, expanding data collection to a new field under an existing purpose label is invisible — the `analytics` label in the `purposes_accepted` array does not declare what data it covers.

---

## 4. The Account Opening Consent Refresh — The Immediate Banking Problem

Every private bank in India currently has bundled account opening consent — a single T&C form that covers:
- KYC data processing
- Bureau reporting
- Marketing (email, SMS, WhatsApp)
- Insurance cross-selling
- App analytics
- Third-party partner sharing
- International transfer (for certain account types)

This is not DPDP Section 6 compliant. Section 6 requires consent to be obtained for each processing purpose separately. Bundled T&C consent does not meet the "free, specific, informed, unconditional and unambiguous" standard for each distinct purpose.

Before May 2027, every bank must run a consent refresh campaign for their existing customer base — obtaining DPDP-compliant consent for each purpose, separately, from potentially tens of millions of customers.

**The scale of this problem makes the architectural choice decisive.**

A GDPR event model stores the result of the refresh as another consent event with a `purposes_accepted` array. This creates the same structural problem as before — monolithic, imprecise, non-independently-revocable.

The DEPA model stores the refresh result as N new artefacts per customer — one per purpose consented to. For a bank with 10M customers and 6 consent purposes, this is 60M artefacts. Each independently addressable. Each with its own expiry. Each with its own deletion cascade path.

The compliance dashboard for a bank running a consent refresh shows:

| Purpose | Customers Refreshed | Valid DPDP Artefacts | Coverage % | Next Expiry Batch |
|---|---|---|---|---|
| Bureau reporting | 10,000,000 | 9,847,231 | 98.5% | Jan 2027 |
| Insurance marketing | 10,000,000 | 6,234,891 | 62.3% | Jan 2027 |
| WhatsApp marketing | 10,000,000 | 7,891,234 | 78.9% | Jan 2027 |
| Co-lending partner | 2,400,000 | 2,389,100 | 99.5% | Jan 2027 |
| Analytics | 10,000,000 | 8,234,567 | 82.3% | Jan 2027 |

A bank's compliance officer can see, per purpose, the exact coverage percentage and the date when the next re-consent campaign must be run. The DEPA compliance dimension in the scoring model turns red for any purpose below a configurable threshold.

No GDPR event model produces this view. It cannot separate coverage by purpose. It cannot calculate expiry per purpose. It cannot drive artefact-level suppression for the 37.7% of customers who did not consent to insurance marketing.

---

## 5. Why the GDPR Model Cannot Be Retrofitted

Banks evaluating DPDP compliance tools will encounter vendors who claim their existing GDPR-adapted consent management platform can be extended for Indian banking requirements. This is architecturally false, for a specific technical reason.

The GDPR event model is schema-defined at its foundation. The unit of consent is the event row. Adding per-purpose revocation, data scope, connector mapping, and expiry management requires fundamentally changing what the unit of consent *is* — from a single event to an artefact per purpose. You cannot add this as a column. You cannot add this as a JSONB field. The relational structure of the existing tables must be replaced.

The specific tables that do not exist in any GDPR-adapted tool and cannot be added without replacing the consent data model:

| Table | Why It Is Required for Banking | Cannot Be Added As |
|---|---|---|
| `purpose_definitions` | Canonical library defining data_scope per purpose — the source of truth the deletion orchestration uses | A JSONB column on consent_events |
| `consent_artefacts` | One row per purpose per interaction — the independently revocable record | A JSONB array in the event model |
| `artefact_revocations` | Immutable revocation record per artefact — the audit trail for DPDP Section 6 | An update flag on the event row |
| `purpose_connector_mappings` | Maps purpose → data_scope → downstream connector — the precision deletion map | A configuration file |
| `consent_expiry_queue` | Scheduled expiry per artefact — drives re-consent campaigns | A cron job on the event timestamp |

ConsentShield's schema was designed with these tables as foundational, before any product was built. The DEPA-native model is not a feature layered onto a GDPR tool. It is the schema.

---

## 6. The Regulatory Examiner's Question

When the Data Protection Board examines a bank's DPDP compliance during enforcement (beginning May 2027), the examiner will ask a specific question about any consent withdrawal that occurred:

*"When customer X withdrew their insurance marketing consent on 10 March 2026, what data was deleted from which systems, on what date, with what confirmation?"*

Under a GDPR event model, the bank's answer is: "We recorded the withdrawal event. We sent a deletion request to our bancassurance partner. We do not have a confirmed receipt."

Under ConsentShield's DEPA model, the answer is: "Artefact cs_art_01HXX2 was revoked at 14:05:33 on 10 March 2026 via artefact_revocations record rev_01HXX7. The deletion request del_req_01HXX8 was sent to bancassurance_partner_connector at 14:05:35. Deletion receipt del_rcpt_01HXX9 was received from the partner at 14:07:12, confirming deletion of email_address, name, dob, account_type, and nominee_name. The full chain is exportable as a signed PDF from the audit package."

The chain of custody — consent grant (artefact) → revocation (artefact_revocations) → deletion request (deletion_requests) → deletion receipt (deletion_receipts) — is directly supported by four linked rows in the schema, navigable by a single artefact ID.

This is not a reporting feature. It is the schema. The evidence exists because the data model was designed to create it, not because someone manually assembled it after the fact.

---

## 7. Implications for the BFSI Product Template

The DEPA architecture translates into specific pre-configured settings in the BFSI sector template that no GDPR-adapted tool can replicate:

### 7.1 Purpose Definition Registry — Banking Standard Codes

The BFSI template pre-populates the Purpose Definition Registry with standard banking purposes, each with its data scope and default expiry:

| Purpose Code | Display Name | Data Scope | Default Expiry | Auto-Delete on Expiry |
|---|---|---|---|---|
| `bureau_reporting` | Credit Bureau Reporting | pan, aadhaar_ref, account_type, repayment_history, dpd_history | 12 months (renewal) | No — statutory retention |
| `insurance_marketing` | Insurance Product Cross-Sell | email_address, name, dob, account_type, nominee_name | 12 months | Yes |
| `co_lending_partner` | Co-Lending Partner Data Share | pan, account_balance, transaction_count_6m, income_estimate | Loan tenure | Partial — see Reg. Exemption Engine |
| `whatsapp_marketing` | WhatsApp Marketing | mobile_number | 12 months | Yes |
| `analytics` | Banking App Analytics | device_id, session_data, feature_usage | 12 months | Yes |
| `trade_finance_partner` | Trade Finance Partner Share | business_name, turnover, gst_number, account_type | Transaction duration | Partial |
| `wealth_management_referral` | Wealth Management Cross-Sell | name, email_address, account_balance_band | 12 months | Yes |

### 7.2 Purpose Connector Mappings — Pre-Built for Banking

The BFSI template pre-configures connector mappings for common banking integrations:

| Purpose Code | Default Connectors Mapped |
|---|---|
| `bureau_reporting` | CIBIL API connector, Experian API connector, CRIF API connector |
| `insurance_marketing` | Generic bancassurance webhook (customer configures partner-specific endpoint) |
| `co_lending_partner` | Generic fintech partner API connector (customer configures) |
| `whatsapp_marketing` | WhatsApp Business API connector |
| `analytics` | Firebase connector, Mixpanel connector, CleverTap connector |

### 7.3 Regulatory Exemption Engine — Pre-Loaded Statutory Lookup

The BFSI template pre-loads the statutory retention rules that determine which data cannot be deleted even when an artefact is revoked or an erasure request is received:

| Data Scope Category | Statutory Obligation | Retention Period | Source |
|---|---|---|---|
| `pan` | KYC record | 8 years post-closure | RBI KYC Master Directions |
| `aadhaar_ref` | KYC record | 8 years post-closure | RBI KYC Master Directions |
| `repayment_history` | Loan record | 8 years post-closure | RBI Master Direction on Loans |
| `bureau_reporting` | Credit information | Duration of credit relationship + 5 years | Credit Information Companies Act |
| `transaction_records` | PMLA | 5 years post-transaction | PMLA 2002, Rule 10 |
| `co_lending_agreement` | Loan agreement | Duration + 8 years | Banking Regulation Act |
| `whatsapp_marketing` | Marketing data | Until withdrawal (no statutory obligation) | None |
| `insurance_marketing` | Marketing data | Until withdrawal (no statutory obligation) | None |

When an erasure request is received for a bank customer, the Regulatory Exemption Engine walks each data scope category across every active artefact associated with that customer, applies the statutory lookup, and generates a response that separately addresses each category.

---

## 8. Why This Is a Sales Document, Not Just a Technical One

The insight in this document is deployable in bank sales conversations. The question that opens a bank's compliance officer is:

**"When your customer withdraws their insurance marketing consent, does your system know which specific data fields to delete from your bancassurance partner's systems — and does it generate a confirmed deletion receipt that can be shown to a DPB examiner?"**

Every bank compliance officer who has thought about DPDP will pause at this question. They know they need to do this. They do not have a tool that does it. The ones who have looked at GDPR tools understand that those tools track consent withdrawal at the purpose-label level, not at the data-field level. The ones who have not yet looked will learn this immediately.

The follow-up: "ConsentShield's DEPA-native artefact model does this automatically. Each consent purpose at account opening creates a separate artefact that declares exactly which data fields it covers and which downstream systems it authorises. When insurance marketing consent is withdrawn, the deletion is scoped precisely to those fields in that specific system — bureau reporting continues uninterrupted, co-lending data is untouched, analytics keeps running. And the deletion receipt is immutably recorded and exportable for DPB."

This is not a feature. It is the architecture. And no competitor has it.

---

## Document Status and Next Actions

This document bridges the gap between the DEPA architecture specification (`consentshield-depa-architecture.md`) and the BFSI segment strategy (`ConsentShield-BFSI-Segment-Brief-v2.docx`). Specific actions it enables:

1. **BFSI Segment Brief v2 addendum** — Section 2 (Banking Blockers) should reference this document when making the "Zero-Storage + DEPA" combined argument. The DEPA architecture is what makes ConsentShield not just compliant with RBI guidelines but *the only tool that can execute the DPDP obligations banks actually face*.

2. **Partnership Overview sales narrative** — The Regulatory Exemption Engine + DEPA artefact combination is the answer to "why can't we just use OneTrust?" OneTrust can manage GDPR consent events. It cannot generate a chain of custody from a DEPA artefact to a field-level deletion receipt with statutory retention exemption annotations. That capability does not exist in the market outside ConsentShield.

3. **Banking DPA template** — The Data Processing Agreement with bank customers should specify that ConsentShield operates in Zero-Storage mode, delivers artefacts to the bank's own storage, and that the bank is the system of record for all DEPA consent artefacts. This document provides the technical basis for that contractual claim.

4. **Finacle/FLEXCUBE partnership pitch** — The argument to Infosys Finacle is that their bank clients need DEPA-native consent for their DPDP compliance and Finacle does not natively produce DEPA artefacts. ConsentShield inserts between the bank's customer-facing systems and their compliance storage layer, generating DEPA artefacts for each consent interaction. Finacle does not need to change. ConsentShield wraps it.

---

*April 2026 · Internal document · Companion to consentshield-depa-architecture.md and ConsentShield-BFSI-Segment-Brief-v2.docx*
*Regulatory references: DPDP Act 2023 S.6 (consent requirements) · Credit Information Companies (Regulation) Act 2005 · RBI KYC Master Directions 2016 · PMLA 2002 Rule 10 · Banking Regulation Act 1949 · RBI Master Direction on Loans and Advances*
