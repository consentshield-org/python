CONSENTSHIELD  ·  Partnership Overview  ·  Confidential  ·  April 2026

**CONSENTSHIELD**

*India**'**s Compliance Enforcement Engine*

**Partnership Overview**

Confidential  ·  April 2026  ·  Updated with DEPA Alignment

Hyderabad, India

# **The Opportunity**

India's Digital Personal Data Protection Act was enacted in 2023. The DPDP Rules were notified on 13 November 2025. Full enforcement — including penalties of up to ₹250 crore per violation — begins on 13 May 2027.

Every company processing personal data of Indian residents now needs a compliant consent system, a data inventory, a rights-management workflow, and an audit trail. Over 400,000 businesses are affected. An EY survey found that nearly 70% of professionals across sectors are not fully familiar with their obligations under the Act.

No India-native product currently owns this space as a compliance enforcement platform. The existing alternatives are either expensive international GRC tools built for GDPR, generic Indian compliance consultancies offering one-time legal engagements, or early-stage consent management tools that document compliance without verifying it.

| *The window to establish a market-defining position is approximately 12 months before large incumbents — Zoho, Tata Consultancy, or well-funded GDPR tools — enter the Indian market with DPDP modules.* |
| --- |

# **What ConsentShield Is**

ConsentShield is a B2B SaaS platform that transforms DPDP compliance from a legal burden into an automated, continuously monitored operational system.

Most compliance tools ask: “Have you configured your consent banner?” and check a box. ConsentShield asks: “Is your consent banner actually being respected by the third-party scripts on your website right now?” — and shows you the answer in real time.

## **The Difference: Documentation vs Enforcement**

| **Capability** | **Documentation Tools vs ConsentShield** |
| --- | --- |
| Consent model | GDPR-style checkbox array — one event, multiple purposes bundled  vs  DEPA-native artefacts — one independently addressable record per purpose, with defined scope, expiry, and revocation chain |
| Data inventory | Self-reported form vs auto-discovered from live tracker detection, supplemented by manual input |
| Consent verification | "Banner is live" checkbox vs active monitoring: are third-party trackers respecting consent decisions? |
| Consent withdrawal | Fire a webhook, hope for the best vs fire webhook, verify enforcement via automated re-scans, cascade deletion to exactly the systems the revoked artefact authorised |
| Consent expiry | Not tracked — consent is indefinitely open-ended vs purpose-scoped artefacts expire automatically; expiry alerts sent 30 days ahead; deletion triggered on expiry if configured |
| Data deletion | Reminder that retention expired vs orchestrate deletion across connected systems scoped to the specific artefact's data scope, collect confirmation receipts |
| Security posture | Not addressed vs nightly external scans: SSL, headers, vulnerable libraries |
| Compliance score | Based on self-reported configuration vs based on observed reality — what the system actually detects, including a DEPA artefact quality dimension |

# **DEPA Alignment — India’s Consent Architecture Standard**

ConsentShield is built on the Data Empowerment and Protection Architecture (DEPA) — the iSPIRT-designed consent infrastructure that underpins India Stack. DEPA is not a marketing claim; it is the structural model that ABDM’s health data consent artefacts already implement, and the model that DPDP’s consent framework is converging toward.

Every India-focused competitor uses a GDPR-adapted consent model: a single event row with an array of accepted purpose labels. This works for cookie banners. It does not satisfy DEPA’s core requirement — that each data flow is authorised by a discrete, independently revocable, time-bounded, machine-readable artefact.

ConsentShield is the only India-native compliance platform with a DEPA-native consent artefact model baked into its foundation.

## **What DEPA-Native Means in Practice**

| **ARTEFACT SCOPED** | Each user consent generates one artefact per purpose — not one event with an array. Analytics, marketing, and personalisation each have a discrete, independently addressable record with their own lifecycle. |
| --- | --- |

| **DATA SCOPED** | Each artefact declares exactly which data fields it covers, drawn from the organisation’s Purpose Definition Registry. Revocation of the marketing artefact stops exactly the data flows that artefact authorised — nothing more, nothing less. |
| --- | --- |

| **TIME BOUNDED** | Every artefact has an explicit expiry date. Consent is not indefinitely open-ended. ConsentShield alerts businesses 30 days before artefacts lapse and enforces expiry automatically. |
| --- | --- |

| **UNIFIED FRAMEWORK** | The same artefact model works across DPDP, ABDM, and GDPR. A patient’s ABDM consent artefact and a website visitor’s DPDP consent artefact are the same data structure — different framework labels, one audit trail. |
| --- | --- |

| **CHAIN OF CUSTODY** | Every revocation links to the artefact that was revoked, the deletion requests it triggered, and the deletion receipts that confirmed completion. An auditor can trace from consent grant to data deletion in a single query. |
| --- | --- |

| *DEPA-native artefacts are not a feature — they are a foundational architectural choice that cannot be retrofitted onto GDPR-style data models. ConsentShield’s schema was designed with DEPA at the core before the first customer row was written.* |
| --- |

# **Platform Capabilities**

The platform is organised into four capability layers, each building on the previous. Together they cover the full compliance lifecycle from initial consent collection through ongoing enforcement, multi-framework coverage, and healthcare.

## **Compliance Foundation**

The core infrastructure that every customer deploys on day one.

**DEPA-Native Consent System**

A no-code banner builder that generates a CDN-hosted JavaScript snippet. Customers add one script tag to their website. Unlike any other India-focused tool, consent is not captured as a single checkbox event — it is structured as a DEPA-native artefact per purpose.

The Purpose Definition Registry is the foundation. Before deploying a banner, customers define each consent purpose in their canonical library: what to call it, which data fields it covers (mapped to their data inventory), how long consent lasts (the artefact expiry window), and whether expired consent should trigger automatic deletion. This registry is the machine-readable source of truth that makes DEPA compliance auditable.

When a user accepts consent, the system generates one consent artefact per purpose accepted — each with a unique stable ID (cs_art_…), defined data scope, explicit expiry timestamp, and independent revocation capability. Each artefact is written to the customer’s own storage, not held by ConsentShield. The same banner script also monitors what happens after the consent decision — observing which third-party trackers fire and whether they respect the user’s choices.

**Tracker Detection Engine**

An embedded intelligence layer that classifies third-party scripts against a curated database of services common on Indian websites: Google Analytics, Meta Pixel, Hotjar, CleverTap, MoEngage, WebEngage, Razorpay, and others. Each detected tracker is mapped to a consent purpose and — under the DEPA model — to the specific artefact that authorises it. Violations are flagged in real time: which tracker fired, against which artefact state, at which timestamp.

**Privacy Notice Generator**

A guided wizard that produces a plain-language, legally structured privacy notice. Under the DEPA-native model, each processing purpose in the notice links to the corresponding Purpose Definition in the registry — ensuring that what the notice says ConsentShield does, and what the artefact records, are the same thing. Outputs a hosted page and downloadable PDF with all DPDP-required disclosures.

**Data Inventory**

A guided form pre-populated with services detected by tracker monitoring. Customers supplement with non-web data flows. The inventory maps data categories — which are the same categories referenced in Purpose Definitions and consent artefact data scopes. This creates a closed loop: the inventory defines the data, the purpose library maps it to uses, and the artefact records which user authorised which use of which data.

**72-Hour Breach Notification Workflow**

A guided end-to-end workflow covering every step from breach detection to regulatory notification. When a breach involves data categories covered by active consent artefacts, ConsentShield surfaces exactly which artefacts are affected — which users, which purposes, which data — directly from the artefact records. Every step timestamped and attributed to a named user.

**Compliance Dashboard**

A single-screen view of the organisation’s compliance posture. The compliance score is a weighted composite of observed reality. The scoring model now includes a DEPA Artefact Quality dimension (20 points) alongside existing components: consent infrastructure (15%), consent enforcement (25%), rights management (15%), data lifecycle (10%), security posture (10%), audit readiness (5%). The DEPA dimension measures artefact coverage, expiry definition, artefact freshness, and revocation chain completeness. A company cannot achieve a green score with a well-configured banner alone — the artefact quality dimension requires genuine DEPA-native consent practice.

**Consent Expiry Management**

A new product surface with no equivalent in any India-focused tool. The Consent Expiry panel shows which artefacts are approaching expiry (by purpose and count), which have lapsed in the last 30 days, and whether deletion was triggered. 30 days before any artefact batch expires, ConsentShield alerts the compliance contact and surfaces an export of the expiring session fingerprints for re-consent campaign targeting. Expired artefacts are enforced automatically — removed from the validity cache and, if configured, deleted from connected systems.

**Audit Export Package**

One-click generation of a comprehensive evidence package formatted for DPB inspection. Under the DEPA model, the audit package now includes the full artefact register — every consent artefact ever issued, with its purpose, data scope, expiry, and revocation status — alongside the existing consent logs, tracker observations, violation history, processing records, rights request history, breach notifications, and data inventory snapshot. The chain of custody from consent grant to deletion receipt is fully navigable.

## **Enforcement Depth**

Capabilities that deepen enforcement and create ongoing operational value beyond initial setup.

**Data Principal Rights Management**

Full lifecycle management for erasure, access, correction, and nomination requests under the DPDP Act. Under the DEPA model, when a data principal submits an erasure request, the system surfaces all active artefacts associated with their session fingerprints — giving the compliance manager a precise picture of which purposes were consented to and which data categories are in scope for erasure. Each rights request carries a 30-day SLA timer with automatic reminders and a fully exportable audit trail.

**Consent Withdrawal Verification**

When a user withdraws consent for a specific purpose, ConsentShield revokes the corresponding artefact, removes it from the validity cache, and schedules automated verification scans to confirm the relevant trackers stopped. Critically, the revocation is artefact-scoped: only the trackers authorised by the revoked artefact are checked, not a blanket scan of all marketing scripts. Trackers that persist after withdrawal generate a red alert with specific artefact reference, tracker name, and timestamp.

**Artefact-Scoped Deletion Orchestration**

When a deletion is required — from an erasure request, expired retention period, or consent revocation — ConsentShield issues deletion commands scoped to exactly the data categories the relevant artefact covered. The Purpose Connector Mapping tells the system which connected services handle which data categories for which purpose. Mailchimp handles email_address for the marketing artefact; HubSpot handles email_address and name; analytics connectors handle usage_data. Deletion is precise, not a blanket account delete across all connected systems.

Pre-built connectors: Mailchimp, HubSpot, Zoho CRM, Freshdesk, Intercom, CleverTap, WebEngage, MoEngage, Shopify, Razorpay, and others. Generic webhook protocol for custom systems. Every deletion produces an immutable receipt referencing the artefact that triggered it — completing the chain of custody.

**Security Posture Monitoring**

Nightly external scans of each customer’s web properties: SSL certificate validity, security headers (HSTS, CSP, X-Frame-Options), vulnerable JavaScript libraries, mixed content, and cookie security flags. Findings surfaced on the dashboard with severity levels and remediation guidance.

**Retention Rules and Automation**

Customers define retention periods per data category, linked to the same data categories referenced in Purpose Definitions and artefacts. When a retention period expires, ConsentShield can automatically trigger artefact-scoped deletion or alert the compliance manager. Data retention is now enforced operationally, not merely documented.

**Processing Log**

A continuous, append-only log of all data processing activities. Queryable by purpose, data category, or date range. Under the DEPA model, each processing log entry references the artefact that authorised the processing — providing the complete audit trail: consent granted (artefact), data processed (processing log), data deleted (deletion receipt). The DPDP Rules require minimum one-year retention; this record lives in the customer’s own storage.

## **Multi-Framework and Ecosystem**

Capabilities that expand ConsentShield beyond DPDP into GDPR, create an ecosystem of partners, and enable platform-level integrations.

**GDPR Module**

Dual-framework coverage for Indian companies with European customers or operations. The DEPA-native artefact model applies to GDPR consent as well — GDPR artefacts share the same schema as DPDP artefacts, distinguished by a framework field. The consent banner detects visitor location and applies the appropriate framework. GDPR adds legal basis documentation, DPIA templates, SCC tracking for cross-border transfers, and EU representative designation.

**Consent Probe Testing**

Automated synthetic compliance testing. ConsentShield simulates users with specific consent states and verifies that the customer’s website behaves correctly. Under the DEPA model, probes test not just whether a banner appears, but whether specific artefact states are respected by the trackers that each artefact governs.

**Compliance API**

A RESTful API that enables enterprise customers and partners to embed ConsentShield’s compliance data into their own systems. Under the DEPA model, new endpoints expose the artefact register, expiry queue, and revocation history — giving enterprise integrators full programmatic access to the consent chain of custody.

**DPO-as-a-Service Matchmaking**

A curated marketplace of empanelled Data Protection Officers. The DPO receives auditor-level access to the customer’s ConsentShield dashboard, including the DEPA artefact register and compliance score. ConsentShield earns a referral fee. The DPO carries legal liability; ConsentShield carries software liability.

**Sector Templates**

Pre-configured compliance kits for five verticals: SaaS, edtech, fintech, e-commerce, and healthcare. Each template pre-populates the data inventory, configures recommended Purpose Definitions with appropriate data scopes and expiry windows for that sector, provides sector-appropriate privacy notice language, and identifies the highest-risk data categories. Reduces onboarding from hours to minutes.

**Cross-Border Data Transfer Module**

Formal tracking and documentation of all data transfers outside India under DPDP Section 16. Auto-detected flows from tracker monitoring are merged with manual declarations. For GDPR customers, SCC status is tracked per transfer. A visual transfer map shows where data flows, what safeguards are in place, and where documentation gaps exist.

## **Healthcare and Enterprise**

**ABDM Healthcare Bundle**

A unified DPDP and ABDM compliance platform for Indian clinics. ConsentShield is the only product that owns the intersection of full ABDM integration and full DPDP compliance for single-doctor and small group practices.

The DEPA alignment matters here more than anywhere else. ABDM’s consent artefacts ARE DEPA artefacts applied to health data — they have the same structure as ConsentShield’s DPDP artefacts (principal, fiduciary, purpose, scope, expiry). The ABDM module stores ABDM artefacts in the same consent_artefacts table as DPDP artefacts, distinguished only by framework type and additional NHA-specific fields. The “unified dashboard” claim is architecturally real: one artefact register, one audit trail, one compliance score — covering both frameworks.

The product covers ABHA ID lookup (including QR scan via mobile), ABDM consent artefact generation and management, consent-gated health record retrieval, a prescription writer that auto-populates from pulled medication history, AI-powered drug interaction checking, digital prescription upload back to ABDM, patient queue management, and WhatsApp follow-up scheduling. Health data never touches ConsentShield’s storage.

**Enterprise White-Label Platform**

Full white-labelling for enterprise customers and CA firm partners: custom branding, custom domains, SSO, multi-team roles, dedicated export storage with customer-held encryption keys, and custom SLAs. CA firms manage multiple clients from a single branded dashboard via the Compliance API, with each client seeing only the CA firm’s branding.

**Mobile Application**

A companion app (iOS and Android) designed primarily for clinic use: push notifications, native camera for ABHA QR scanning, touch-optimised bedside consent flows, compliance score at a glance, quick rights request approval, and emergency breach notification trigger.

# **Data Architecture**

ConsentShield operates as a stateless compliance oracle. It processes consent events, generates DEPA-native consent artefacts, and delivers the canonical record to the customer’s own storage. ConsentShield does not hold the compliance record — the customer does.

This is analogous to how a payment gateway works: Razorpay processes transactions and hands the merchant the record. ConsentShield processes consent interactions, generates artefacts, and hands the customer the record.

| **Data Category** | **Where It Lives** |
| --- | --- |
| Operational state | Organisation config, banner settings, Purpose Definitions, billing — lives in ConsentShield permanently. Standard SaaS business data. |
| Consent artefacts | Generated by ConsentShield, buffered briefly, then delivered to customer-owned storage and deleted from ConsentShield. The customer holds the canonical artefact register. |
| Compliance records | Audit logs, processing logs, rights request history, artefact revocations — buffered briefly, then delivered to customer storage and deleted. One-year minimum retention (DPDP Rules) sits with the customer, not ConsentShield. |
| Health data (ABDM) | FHIR records flow through ConsentShield in memory only. Never persisted. ABDM artefact IDs and metadata are stored — no clinical content. |

If ConsentShield shuts down tomorrow, every customer’s complete artefact register and audit trail is already in their storage, readable without ConsentShield. This removes the largest liability the platform could carry — being the entity a breach attacker or a Data Protection Board auditor comes to first.

# **Target Market**

| **Priority** | **Segment and Why They Buy** |
| --- | --- |
| 1 | Indian SaaS founders, 5–50 employees, seed to Series B — especially with EU customer exposure. DPDP is now a due diligence item for fundraising. VCs ask about it. EU exposure adds GDPR urgency. DEPA-native artefacts answer the "show me your consent model" question in investor calls with a specific, auditable answer. |
| 2 | Edtech CTOs, 50K–2M users, K–12 or upskilling products. Children’s data provisions are the harshest under DPDP. Purpose-scoped artefacts with defined expiry windows and data scope are the defensible evidence trail if a DPB case is opened. |
| 3 | D2C e-commerce founders, ₹5–50 crore GMV, email and WhatsApp marketing-heavy. Email lists and WhatsApp groups are explicitly regulated. Artefact-scoped deletion means consent withdrawal actually stops marketing across all connected platforms — not just fires a webhook. |
| 4 | Single-doctor clinics and small group practices in Telangana and Karnataka. ABDM registration plus health data means immediate DPDP obligation. The unified DEPA artefact model across ABDM and DPDP is the headline differentiator for this segment. |

# **Competitive Position**

| **Competitor** | **Type** | **Why ConsentShield Wins** |
| --- | --- | --- |
| OneTrust | US GRC platform | ₹50,000+/year. Built for GDPR-style checkbox consent. No DEPA-native artefact model, no India-specific templates, no enforcement monitoring. |
| Scrut / Sprinto | Indian GRC | Focused on SOC 2 and ISO 27001. No DPDP module. Different buyer (security team vs compliance team). No consent artefact model. |
| Privy by IDfy | Indian CMP | Consent management only. GDPR-adapted model. No DEPA artefacts, no enforcement monitoring, no tracker detection, no deletion orchestration, no healthcare bundle. |
| CookieYes / GoTrust | Consent tools | Cookie-focused tools adapted from GDPR. GDPR-style consent events, not DEPA artefacts. No purpose-scoped expiry, no artefact-aware deletion, no Indian healthcare integration. |
| Zoho (rumoured) | Suite add-on | Not shipped. Even if shipped, a generic add-on in a 50-product suite cannot position as a DEPA-native enforcement specialist. No artefact model. |
| Law firms | Manual advisory | ₹5–25 lakh per engagement. One-time document, not a living system. No artefact register, no operational tooling, no enforcement monitoring, no ongoing workflow. |

| *ConsentShield’s structural advantage is that it is the only India-focused platform with a DEPA-native consent artefact model. Every other tool in the market uses a GDPR-adapted checkbox event model. ConsentShield does not just document compliance — it enforces it and proves it with a chain of custody from consent grant to deletion receipt.* |
| --- |

# **Pricing and Packaging**

Pricing is anchored to compliance urgency and operational value. The comparison for customers is not against other SaaS tools — it is against a law firm retainer at ₹5–25 lakh per engagement. Every ConsentShield price point represents a fraction of that cost for a continuous, living compliance system rather than a one-time document.

| **Feature** | **Starter ₹2,999/mo** | **Growth ₹5,999/mo** | **Pro ₹9,999/mo** | **Enterprise ₹24,999+/mo** |
| --- | --- | --- | --- | --- |
| Consent banner + DEPA artefacts | **✓** | **✓** | **✓** | **✓** |
| Purpose Definition Registry | **✓** | **✓** | **✓** | **✓** |
| Tracker enforcement | **✓** | **✓** | **✓** | **✓** |
| Privacy notice + data inventory | **✓** | **✓** | **✓** | **✓** |
| Breach notification workflow | **✓** | **✓** | **✓** | **✓** |
| Rights management + SLA | — | **✓** | **✓** | **✓** |
| Consent expiry management | — | **✓** | **✓** | **✓** |
| Withdrawal verification | — | **✓** | **✓** | **✓** |
| Security posture scanning | — | **✓** | **✓** | **✓** |
| Artefact-scoped deletion | — | 3 connectors | 13 connectors | Unlimited |
| GDPR module | — | — | **✓** | **✓** |
| Consent probe testing | — | — | **✓** | **✓** |
| Compliance API | — | — | **✓** | **✓** |
| White-label + custom domains | — | — | — | **✓** |
| DPO matchmaking | — | — | — | **✓** |
| ABDM healthcare bundle | — | — | — | Add-on ₹4,999/mo |

Annual prepayment: 20% discount (two months free). CA and legal firm partners: 30% revenue share on referred and managed accounts. Startup accelerator partnerships (NASSCOM, T-Hub, iSPIRT): 40% off Growth tier for cohort members.

# **The Partnership**

ConsentShield requires a partner to reach its full market potential. A software developer building the platform cannot simultaneously operate the customer-facing business, manage regulatory relationships, and fulfil the compliance officer function that enterprise customers require. The right partner transforms ConsentShield from a product into a market-defining business.

| *Note on Consent Manager registration: The DPDP Rules define a registered Consent Manager as an entity that acts on behalf of Data Principals — users — to manage their consents across multiple Data Fiduciaries. This is a user-side trust intermediary role, not a business compliance tool role. ConsentShield’s primary function is helping Data Fiduciaries comply with their DPDP obligations — a different function that likely does not require Consent Manager registration. A definitive legal opinion on this question should be obtained before committing to the registration route. The ₹2 crore net worth requirement for Consent Manager registration under Rule 3 may be a partner requirement for offering the user-side consent management feature, not for the core compliance platform.* |
| --- |

## **What the Platform Brings**

| **Asset** | **Detail** |
| --- | --- |
| Complete product | Fully designed, architected, and built platform covering DPDP, GDPR, and ABDM healthcare compliance with enforcement capabilities no competitor in India offers. |
| DEPA-native artefact model | The only India-native compliance platform with a DEPA-native consent artefact model — purpose-scoped, time-bounded, independently revocable, with full chain of custody from consent to deletion. This is the architectural moat. |
| Enforcement differentiator | Real-time tracker monitoring, consent withdrawal verification, artefact-scoped deletion orchestration with receipts, consent probe testing, and security posture scanning. |
| Stateless architecture | Customer owns their consent artefact register and compliance record. ConsentShield never holds it. This reduces liability, simplifies the Data Processing Agreement, and is a verifiable selling point. |
| AI-accelerated development | Code production at 5–10× the rate of a traditional developer. New features, connectors, and integrations can be shipped in days, not months. |
| Multi-vertical coverage | SaaS, edtech, fintech, e-commerce, and healthcare from a single platform. Sector templates with pre-configured Purpose Definitions enable rapid onboarding per vertical. |

## **What the Partner Brings**

| **Requirement** | **Why It Is Needed** |
| --- | --- |
| Indian incorporation (Pvt Ltd) | Required to enter Data Processing Agreements with customers and ABDM facility registration with NHA. Also required if Consent Manager registration is pursued following legal opinion. |
| Customer-facing operations | Support team, onboarding, account management. The developer builds the platform; the partner runs the business. Minimum one dedicated person before Month 6. |
| Sales and marketing | Content distribution, community presence (SaaSBoomi, NASSCOM, T-Hub, iSPIRT), CA firm partnerships, healthcare channel development (IMA-Telangana). |
| Legal entity for contracts | Data Processing Agreements, customer contracts, DPO partner agreements, and ABDM facility registration all require a legal entity. Also needed to obtain legal opinion on Consent Manager registration requirements. |
| Regulatory liaison | Interaction with the Data Protection Board, NHA for ABDM production approval, and any future compliance certifications. Critical relationship for staying ahead of regulatory changes. |
| Net worth (if Consent Manager registration is pursued) | DPDP Rule 3 requires ₹2 crore net worth for registered Consent Manager status. Subject to legal opinion on whether this applies to ConsentShield’s deployment model. |

## **Revenue Model**

The partnership is a revenue-sharing arrangement. The developer builds and maintains the platform. The partner company operates customer-facing functions, manages regulatory relationships, and owns the customer relationship. Revenue split and IP ownership are negotiable.

The partner’s investment is operational — team, incorporation, and regulatory engagement — not research and development. The R&D is complete. The product is designed, architected, and ready to build at speed.

| *ConsentShield is not looking for funding. It is looking for a partner who can carry the go-to-market operations, manage regulatory relationships, and take a DEPA-native, market-defining compliance platform to India’s 400,000+ businesses before the enforcement deadline arrives.* |
| --- |

# **The Enforcement Timeline**

All commercial conversations in 2026 should be anchored to three dates.

| **Date and Event** | **Impact** |
| --- | --- |
| 13 Nov 2025 — DPDP Rules notified. Data Protection Board established. | Legal obligation confirmed. Planning mode begins across all sectors. ✓ Done. |
| 13 Nov 2026 — Consent Manager framework becomes operational. Registration opens. | The registered Consent Manager requirement takes effect. Businesses must either appoint a registered CM or use one. Legal opinion on ConsentShield’s CM status required before this date. |
| 13 May 2027 — Full enforcement: processing obligations, rights architecture, and penalties. | ₹250 crore per violation. Cumulative exposure up to ₹650 crore. Every company must be compliant. The DEPA artefact register is the audit evidence that proves it. |

| *The window to establish a market-defining position is real and finite. Full enforcement begins May 2027. A partnership formed today has 13 months to launch, acquire customers, and be the platform businesses turn to when the enforcement clock hits zero.* |
| --- |

**ConsentShield**

Hyderabad, India  ·  April 2026

*Confidential — For prospective partner review only*

	consentshield.in  ·  Hyderabad, India