# ConsentShield — Definitive Architecture Reference

*Source of truth for all development · April 2026*
*Supersedes: consentshield-technical-architecture.md, consentshield-stateless-oracle-architecture.md*

---

## Document Purpose

This is the single authoritative technical document for ConsentShield. Every architectural decision, every data flow, every security rule, every integration contract is specified here. If something contradicts this document, this document wins.

---

## 1. Architectural Identity

ConsentShield is a **stateless compliance oracle**. It processes consent events, generates compliance evidence, and delivers the canonical record to the customer's own storage. It does not hold the compliance record — the customer does.

Three design principles flow from this identity:

**Principle 1 — Process, deliver, delete.** Every piece of user data that enters ConsentShield exits to customer storage within minutes. ConsentShield's buffer tables are write-ahead logs, not databases. A row that has been delivered and confirmed has zero reason to exist. It is deleted immediately, not on a schedule.

**Principle 2 — The customer is the system of record.** Dashboard views may read from buffer tables for real-time display. Compliance exports, audit packages, and any DPB-facing artefact must read from — or direct users to — customer-owned storage. Any code path that treats ConsentShield's buffer as the canonical record is architecturally wrong.

**Principle 3 — ConsentShield is a Data Processor, not a Data Fiduciary.** This is not a legal nicety. Under DPDP, a Fiduciary faces ₹250 crore per violation. A Processor that accumulates a centralised record of everything it processes starts looking like a Fiduciary. The stateless oracle architecture ensures ConsentShield never crosses that line.

---

## 2. Stack Overview

| Layer | Technology | Purpose | Access Level |
|---|---|---|---|
| Frontend | Next.js 14 + TypeScript + Tailwind + shadcn/ui | Web application | User-facing |
| Auth | Supabase Auth | Email, magic link, Google OAuth | Integrated with DB RLS |
| Database | Supabase Postgres | Operational state store | RLS-enforced multi-tenancy |
| Edge Functions | Supabase Edge Functions (Deno) | Async: delivery, SLA reminders, scans, deletion orchestration | Service role only |
| Banner + Monitoring | Cloudflare Worker + KV | cdn.consentshield.in — banner.js delivery, consent event ingestion, tracker observation ingestion | Public endpoints |
| Scan Engine | Vercel Cron + HTTP checks | Withdrawal verification, security posture scans | Service role only |
| Notification Channels | Resend (email) + Slack/Teams/Discord webhooks | Compliance alerts | Service role only |
| Tracker Signature DB | Versioned JSON, embedded in banner script | Tracker classification intelligence | Read-only, shipped in banner |
| Billing | Razorpay Subscriptions | INR plans, auto-renewal | Server-side only |
| Customer Storage | Cloudflare R2 (default) or AWS S3 (BYOS) | Canonical compliance record | Write-only from ConsentShield |
| Monitoring | Sentry + Vercel Analytics | Error tracking, performance | Server-side only |

### The fundamental architectural decision

Supabase Auth and Supabase Postgres are the same system. The `auth.uid()` and `auth.jwt()` functions are available inside every RLS policy. Multi-tenant isolation is enforced at the database level, not in application code. Every query runs the policy — there is no way to forget it.

---

## 3. Data Classification

Every table in ConsentShield's database belongs to exactly one of two categories. This distinction is the single most important thing to understand before touching any code.

### Category A — Operational State (permanent)

Data that ConsentShield needs to function. Organisation configs, banner settings, billing records, team membership, tracker signature definitions. This is standard SaaS business data — no different from what any B2B tool holds about its paying users. It stays in ConsentShield's database permanently.

**Tables:** organisations, organisation_members, web_properties, consent_banners, data_inventory, tracker_signatures, tracker_overrides, integration_connectors, retention_rules, export_configurations, consent_artefact_index, api_keys, sector_templates, dpo_partners, dpo_engagements, gdpr_configurations, white_label_configs, notification_channels

### Category B — User Data Buffer (transient)

Personal data of data principals that flows through ConsentShield on its way to customer-owned storage. Consent events, audit log entries, tracker observations, deletion receipts, processing log entries, security scan results, withdrawal verification results. This data is buffered only to guarantee delivery. Once customer storage confirms the write, ConsentShield's copy is deleted.

**Tables:** consent_events, tracker_observations, audit_log, processing_log, delivery_buffer, rights_request_events, deletion_receipts, security_scans, withdrawal_verifications, consent_probe_runs

### Category C — Health Data (zero persistence)

FHIR records from ABDM. Never written to any table, any log, any file. Flows through ConsentShield's server in memory only. Processed (drug interaction check, prescription template), then released. Any code that attempts to persist FHIR content is rejected in review without exception.

---

## 4. Processing Modes

The storage_mode on the organisations table determines the data handling path. This check runs at the API gateway level before any data write.

| Mode | What ConsentShield Holds | Customer Storage | Who Manages Storage |
|---|---|---|---|
| **Standard** | Operational config + encrypted buffer | ConsentShield-provisioned R2 bucket, per-customer encryption key (delivered once, discarded) | ConsentShield provisions; customer holds key |
| **Insulated** | Operational config only | Customer's own R2 or S3 bucket. Write-only credential from ConsentShield. Cannot read, list, or delete. | Customer manages |
| **Zero-Storage** | Consent artefact index (TTL) + delivery buffer (seconds) | Customer's own bucket. Data flows through memory only. | Customer manages |

Zero-Storage is mandatory for health data. Insulated is the default for Growth tier and above. Standard is for Starter tier customers who cannot provision their own bucket.

---

## 5. Multi-Tenant Isolation

### 5.1 JWT Custom Claims

After signup and org creation, `org_id` and `org_role` are injected into every JWT via Supabase's custom access token hook:

```sql
create or replace function public.custom_access_token_hook(event jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  claims jsonb; org_id uuid; org_role text;
begin
  claims := event -> 'claims';
  select om.org_id, om.role into org_id, org_role
  from organisation_members om where om.user_id = (event ->> 'user_id')::uuid limit 1;
  if org_id is not null then
    claims := jsonb_set(claims, '{org_id}', to_jsonb(org_id::text));
    claims := jsonb_set(claims, '{org_role}', to_jsonb(org_role));
  end if;
  return jsonb_set(event, '{claims}', claims);
end; $$;

grant execute on function public.custom_access_token_hook to supabase_auth_admin;
```

### 5.2 RLS Helper Functions

```sql
create or replace function current_org_id() returns uuid language sql stable as $$
  select (auth.jwt() ->> 'org_id')::uuid;
$$;

create or replace function is_org_admin() returns boolean language sql stable as $$
  select (auth.jwt() ->> 'org_role') = 'admin';
$$;
```

### 5.3 Isolation Enforcement Pattern

Every table follows one of three RLS patterns:

**Pattern 1 — Org-scoped read/write (operational tables):**
```sql
create policy "org select" on [table] for select using (org_id = current_org_id());
create policy "org insert" on [table] for insert with check (org_id = current_org_id());
create policy "org update" on [table] for update using (org_id = current_org_id());
```

**Pattern 2 — Org-scoped read-only (buffer tables written by service role):**
```sql
create policy "org select" on [table] for select using (org_id = current_org_id());
-- NO insert, update, or delete policy for authenticated users
-- Writes come exclusively from service role (bypasses RLS)
```

**Pattern 3 — Public insert, org-scoped read (rights requests):**
```sql
create policy "org select" on rights_requests for select using (org_id = current_org_id());
create policy "org update" on rights_requests for update using (org_id = current_org_id());
create policy "public insert" on rights_requests for insert with check (true);
-- Rate-limited at API layer: 5 requests/IP/hour
```

### 5.4 The Service Role Key

Stored only in server-side environment variables (Vercel) and the Cloudflare Worker. Bypasses RLS entirely. Used for:

- Cloudflare Worker writing consent events and tracker observations
- Edge Functions writing to audit_log, processing_log, delivery_buffer
- Edge Functions executing buffer purge and delivery confirmation
- Razorpay webhook handler updating organisation plan

**Never in `NEXT_PUBLIC_` variables. Never in client-side code. Never in any log.**

---

## 6. The Consent Banner — Edge Architecture

### 6.1 Cloudflare Worker (cdn.consentshield.in)

The Worker handles three routes:

```
GET  /v1/banner.js          → Serve compiled banner script (with monitoring)
POST /v1/events             → Ingest consent event
POST /v1/observations       → Ingest tracker observation report
GET  /v1/health             → Health check
```

### 6.2 KV Store

```
banner:config:{propertyId}           → JSON banner config, TTL 300s
banner:script:{propertyId}:{version} → Compiled banner.js string, TTL 3600s
snippet:verified:{propertyId}        → '1' on each successful load, TTL 600s
```

### 6.3 Banner Script v2

The compiled script is a self-contained vanilla JS file (~26KB gzipped). It performs two functions:

**Consent capture:** Render banner → capture user decision → POST consent event → store in localStorage → dismiss banner.

**Tracker monitoring:** After consent resolves, start MutationObserver (DOM script injection) + PerformanceObserver (resource timing). 5-second initial observation window, 60-second extended window. Classify detected trackers against embedded signature database. Compare against consent state. POST observation report with any violations.

### 6.4 Consent Event Ingestion

The Worker validates the payload, truncates the IP (removes last octet), hashes the user agent, and writes to the consent_events buffer table via service role. Returns 202 immediately — a failed write must never break the user's browsing session. Delivery to customer storage is dispatched asynchronously.

### 6.5 Observation Report Ingestion

Same pattern as consent events: validate, write to tracker_observations buffer, dispatch delivery, return 202.

---

## 7. The Stateless Oracle Pipeline

This is the core data flow for all user data.

```
Event source (Worker, Edge Function, API route)
    │
    ▼
Buffer table (consent_events, audit_log, tracker_observations, etc.)
    │  Row created with delivered_at = null
    │
    ▼
Delivery Edge Function
    │  Reads undelivered rows
    │  Writes to customer storage (R2/S3)
    │  On confirmed write:
    │    → SET delivered_at = now() on the buffer row
    │    → Hard-delete the row immediately
    │  On failed write:
    │    → Increment attempt_count
    │    → Log delivery_error
    │    → Retry per backoff schedule
    │    → After 10 failures: alert, hold for manual review
    │
    ▼
Customer-owned storage (R2/S3)
    │  Canonical compliance record
    │  Encrypted with customer-held key
    │  Survives ConsentShield shutdown
    │
    ▼
DPB audit export (read from customer storage, not from ConsentShield)
```

### 7.1 Buffer Lifecycle — Zero Tolerance for Stale Data

The buffer tables are write-ahead logs. A row's lifecycle is measured in seconds to minutes, not hours or days.

**Immediate deletion path (preferred):**

```sql
-- Inside the delivery Edge Function, after confirmed write to customer storage:
-- Step 1: Mark delivered
UPDATE consent_events SET delivered_at = now() WHERE id = $1 AND delivered_at IS NULL;
-- Step 2: Delete immediately
DELETE FROM consent_events WHERE id = $1 AND delivered_at IS NOT NULL;
-- These two statements run in the same transaction.
```

The previous architecture used a "nightly purge" approach. That is wrong. A consent event that was successfully delivered at 14:32 has no reason to exist in ConsentShield's database at 14:33. The deletion is immediate, not scheduled.

**Fallback sweep (safety net):**

Even with immediate deletion, edge cases can leave orphaned rows (process crash between mark and delete, delivery confirmation received but delete failed). A pg_cron job runs every 15 minutes to catch these:

```sql
-- Every 15 minutes: delete any rows delivered more than 5 minutes ago
-- This should find 0 rows in normal operation. If it finds rows, something went wrong.
DELETE FROM consent_events WHERE delivered_at IS NOT NULL AND delivered_at < now() - interval '5 minutes';
DELETE FROM tracker_observations WHERE delivered_at IS NOT NULL AND delivered_at < now() - interval '5 minutes';
DELETE FROM audit_log WHERE delivered_at IS NOT NULL AND delivered_at < now() - interval '5 minutes';
DELETE FROM processing_log WHERE delivered_at IS NOT NULL AND delivered_at < now() - interval '5 minutes';
DELETE FROM delivery_buffer WHERE delivered_at IS NOT NULL AND delivered_at < now() - interval '5 minutes';
```

**Stuck row detection (alert, don't silently lose data):**

```sql
-- Every hour: alert on rows that have been undelivered for > 1 hour
-- These represent delivery failures that need investigation
SELECT count(*) FROM consent_events WHERE delivered_at IS NULL AND created_at < now() - interval '1 hour';
-- If count > 0: fire alert via notification channels
```

**Hard limit (compliance emergency):**

```sql
-- Any row in a buffer table older than 24 hours is a compliance emergency.
-- It means the delivery pipeline has been broken for a full day.
-- This should NEVER fire in normal operation.
SELECT count(*) FROM consent_events WHERE created_at < now() - interval '24 hours';
-- If count > 0: page the developer. This is a P0.
```

### 7.2 Export Storage Configuration

Stored in `export_configurations` per organisation. Credentials are encrypted at rest using pgcrypto with a server-side encryption key.

**Write-only access pattern:** The IAM credential stored permits `PutObject` only. Cannot read, list, or delete. If compromised, the attacker gains write access to an encrypted bucket they cannot decrypt.

**Default (Standard mode):** ConsentShield provisions a Cloudflare R2 bucket within its own account, scoped to a per-customer path prefix. A per-customer encryption key is generated, delivered to the customer once, and discarded. ConsentShield cannot read the exported data.

**BYOS (Insulated/Zero-Storage mode):** Customer provides their own bucket and a write-only credential. ConsentShield validates the credential on setup (test write + verify), stores it encrypted, and uses it for all exports.

---

## 8. Enforcement Engine

### 8.1 Tracker Detection

The banner script's monitoring module observes third-party requests after the consent decision. Each detected request is classified against the embedded tracker signature database (JSON, ~15KB, covering 40+ services common on Indian websites).

Classification produces:
```
Detected domain → Known service → Purpose category → Consent required?
    → Compare against user's actual consent state
    → Match = compliant | Mismatch = violation
```

Violations are included in the observation report POSTed to the Worker.

**False positive mitigation:**
1. Functional allowlist — payment gateways, CAPTCHA, essential chat widgets are never flagged
2. 60-second grace period after consent change (cached scripts may fire)
3. Customer-configurable overrides via tracker_overrides table

### 8.2 Consent Withdrawal Verification

On `consent_withdrawn` event, the delivery Edge Function schedules three verification scans:

| Scan | Delay | Catches |
|---|---|---|
| Scan 1 | T + 15 minutes | Immediate enforcement failures |
| Scan 2 | T + 1 hour | Cached script issues |
| Scan 3 | T + 24 hours | Persistent violations |

Each scan: HTTP GET customer's page → parse HTML for tracker scripts → compare against withdrawn consent purposes → log result.

Client-side monitoring (banner script) catches dynamic trackers in real user sessions. Server-side scans catch hardcoded scripts at any time. Together they cover the most important violation patterns.

### 8.3 Security Posture Scanning

Nightly Vercel Cron (02:00 IST) per web property:

| Check | Method | Severity |
|---|---|---|
| SSL certificate | TLS handshake | Critical if expired |
| HSTS header | HTTP response | Warning if missing |
| CSP header | HTTP response | Warning if missing/partial |
| X-Frame-Options | HTTP response | Info |
| Vulnerable JS libraries | Script version vs CVE DB | Critical |
| Mixed content | HTML parse | Warning |
| Cookie flags | Set-Cookie inspection | Warning |

### 8.4 Deletion Orchestration

Triggered by: erasure request approved, retention period expired, or consent withdrawn.

**Generic webhook protocol (universal):**
```json
POST customer's endpoint:
{
  "event": "deletion_request",
  "request_id": "uuid",
  "data_principal": { "identifier": "...", "identifier_type": "email" },
  "reason": "erasure_request",
  "callback_url": "https://api.consentshield.in/v1/deletion-receipts/{request_id}",
  "deadline": "ISO timestamp"
}

Customer callback:
{
  "request_id": "uuid",
  "status": "completed | partial | failed",
  "records_deleted": 47,
  "completed_at": "ISO timestamp"
}
```

**Pre-built connectors:** Direct API integrations (OAuth). Each follows the standard DeletionConnector interface: `getAuthUrl()`, `handleCallback()`, `deleteUser()`, `checkHealth()`.

Every deletion produces an immutable receipt in the deletion_receipts table, exported to customer storage as DPB evidence.

---

## 9. Notification Architecture

No native mobile app. All alerts delivered through configurable channels:

| Channel | Method | Delivery guarantee |
|---|---|---|
| Email (Resend) | Transactional email to compliance contact | Always on, primary channel |
| Slack | Incoming webhook to configured channel | Configurable per alert type |
| Microsoft Teams | Incoming webhook | Configurable per alert type |
| Discord | Webhook | Configurable per alert type |
| Custom webhook | POST to customer endpoint | For PagerDuty, OpsGenie, etc. |

Alert types (each independently configurable per channel):
- Tracker violations detected
- New rights request received
- SLA warning (7 days remaining)
- SLA overdue
- Consent withdrawal verification failure
- Security scan: new critical finding
- Retention period expired
- Deletion orchestration failure
- Consent probe failure
- Compliance score change (daily summary)

---

## 10. API Surface

### 10.1 Public Endpoints (no auth)

| Route | Method | Handler |
|---|---|---|
| cdn.consentshield.in/v1/banner.js | GET | Cloudflare Worker — serve banner |
| cdn.consentshield.in/v1/events | POST | Cloudflare Worker — ingest consent event |
| cdn.consentshield.in/v1/observations | POST | Cloudflare Worker — ingest tracker observation |
| /api/public/rights-request | POST | Next.js API — submit rights request (rate-limited) |
| /api/v1/deletion-receipts/{id} | POST | Next.js API — deletion callback from customer webhook |

### 10.2 Authenticated Endpoints (Supabase JWT)

| Route | Method | Purpose |
|---|---|---|
| /api/orgs/[orgId]/banners | GET, POST | List/create consent banners |
| /api/orgs/[orgId]/banners/[id]/publish | POST | Activate banner, invalidate KV |
| /api/orgs/[orgId]/inventory | GET, POST, PATCH | Data inventory CRUD |
| /api/orgs/[orgId]/rights-requests | GET | List rights requests |
| /api/orgs/[orgId]/rights-requests/[id] | PATCH | Update request (assign, verify, respond) |
| /api/orgs/[orgId]/rights-requests/[id]/events | POST | Append workflow event |
| /api/orgs/[orgId]/breaches | GET, POST | List/create breach notifications |
| /api/orgs/[orgId]/audit/export | POST | Generate audit package |
| /api/orgs/[orgId]/settings | GET, PATCH | Organisation settings |
| /api/orgs/[orgId]/integrations | GET, POST, DELETE | Manage connectors |
| /api/orgs/[orgId]/integrations/[id]/delete | POST | Trigger deletion via connector |
| /api/orgs/[orgId]/notifications | GET, PATCH | Notification channel config |

### 10.3 Compliance API (API key auth — Pro/Enterprise)

```
Authorization: Bearer cs_live_xxxxxxxxxxxxxxxx
```

| Route | Method | Scopes |
|---|---|---|
| /api/v1/consent/events | GET | read:consent |
| /api/v1/consent/score | GET | read:score |
| /api/v1/tracker/violations | GET | read:tracker |
| /api/v1/rights/requests | GET, POST | read:rights, write:rights |
| /api/v1/deletion/trigger | POST | write:deletion |
| /api/v1/deletion/receipts | GET | read:deletion |
| /api/v1/audit/export | GET | read:audit |
| /api/v1/security/scans | GET | read:security |
| /api/v1/probes/results | GET | read:probes |

---

## 11. Security Rules — Non-Negotiable

These are architectural constraints, not feature decisions. They cannot be relaxed without rebuilding significant parts of the product.

**Rule 1 — The service role key never touches the browser.** Lives in Vercel env vars (server-side only) and Cloudflare Worker env. Never in `NEXT_PUBLIC_`. Never in client-side code. Never in any log.

**Rule 2 — Buffer tables are append-only for authenticated users.** No UPDATE or DELETE RLS policy exists on consent_events, tracker_observations, audit_log, processing_log, rights_request_events for any role. Writes only via service role from Worker/Edge Functions. Delivered rows are deleted by service role immediately after confirmed delivery — this is the correct behaviour for a buffer that has completed its purpose.

**Rule 3 — Health data (ABDM) is never stored.** FHIR records flow through memory only. No schema, no table, no log ever holds clinical content. Any code that persists FHIR content is rejected in review without exception.

**Rule 4 — org_id is validated at two levels.** API routes check the session's org_id against the resource being requested. RLS policies enforce the same check at the database level. Both must pass. Belt and braces.

**Rule 5 — Razorpay webhooks are signature-verified before processing.** Rejected if `X-Razorpay-Signature` doesn't match `HMAC-SHA256(body, RAZORPAY_WEBHOOK_SECRET)`.

**Rule 6 — The public rights request endpoint is rate-limited.** 5 requests/IP/hour via Vercel edge middleware. `org_id` taken from URL, not from client payload.

**Rule 7 — ConsentShield's database is an operational state store, not a compliance record store.** Any feature that treats buffer tables as the system of record is architecturally wrong.

**Rule 8 — Export credentials are write-only and never logged.** The IAM credential permits `PutObject` only. Stored encrypted at rest. Never in any log, error message, or audit trail.

**Rule 9 — Processing modes are enforced at the API gateway.** The `storage_mode` check runs before any data write. An organisation in Zero-Storage mode must never have data written to any persistent table.

**Rule 10 — RLS policies are the first code committed.** Schema design and RLS policy definitions are written and tested before any customer data exists. Before any UI. A consent log that leaks across tenants — even briefly — is a catastrophic trust event for a compliance product.

**Rule 11 — Buffer rows do not persist after delivery.** Deletion is immediate on confirmed delivery, not scheduled. The 15-minute sweep is a safety net, not the primary mechanism. Any row older than 1 hour without delivery is a delivery failure requiring investigation. Any row older than 24 hours is a P0 incident.

**Rule 12 — Integration connector credentials are encrypted at rest.** OAuth tokens for third-party deletion connectors are stored in `integration_connectors.config` encrypted with pgcrypto. Never logged, never exported, never included in audit packages.

---

## 12. Environment Variables

### Vercel (server-side only — never NEXT_PUBLIC_)

```bash
SUPABASE_URL=https://<project>.supabase.co
SUPABASE_ANON_KEY=<anon key>                    # Client-side Supabase client
SUPABASE_SERVICE_ROLE_KEY=<service role key>    # Server-side only

RAZORPAY_KEY_ID=<key id>
RAZORPAY_KEY_SECRET=<key secret>
RAZORPAY_WEBHOOK_SECRET=<webhook secret>

RESEND_API_KEY=<resend api key>

CLOUDFLARE_ACCOUNT_ID=<cf account id>
CLOUDFLARE_API_TOKEN=<cf api token>             # KV cache invalidation
CLOUDFLARE_KV_NAMESPACE_ID=<kv namespace id>

CLOUDFLARE_R2_ACCESS_KEY_ID=<r2 access key>     # Write-only, scoped to provisioned buckets
CLOUDFLARE_R2_SECRET_ACCESS_KEY=<r2 secret>

EXPORT_CREDENTIAL_ENCRYPTION_KEY=<32-byte hex>  # Encrypts BYOS credentials at rest. Rotate annually.

SENTRY_DSN=<sentry dsn>
```

### Cloudflare Worker

```bash
SUPABASE_URL=<same as above>
SUPABASE_SERVICE_KEY=<service role key>
BANNER_KV=<kv namespace binding>
```

---

*Document prepared April 2026. This is the definitive architecture reference. All development decisions defer to this document.*
