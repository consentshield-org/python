# ConsentShield — DEPA Schema Modifications

*Schema amendment document · April 2026*
*Companion to: Complete Schema Design (consentshield-complete-schema-design.md)*
*Companion to: DEPA Alignment Architecture (consentshield-depa-architecture.md)*

---

## Document Purpose

This document contains every SQL statement required to bring the ConsentShield schema into DEPA alignment. It is structured as a migration — statements are ordered for safe execution against the existing schema defined in `consentshield-complete-schema-design.md`.

**Run order:** Execute this document in its entirety *before* any customer data enters the system. If the base schema is already on a live instance with customer data, treat this as a careful migration and refer to Section 11 (Migration Notes).

---

## Table of Contents

1. [Summary of Changes](#1-summary)
2. [New Helper Functions](#2-helper-functions)
3. [Modifications to Existing Tables](#3-existing-table-modifications)
4. [New Tables](#4-new-tables)
5. [New Indexes](#5-indexes)
6. [Row-Level Security — New Policies](#6-rls)
7. [Scoped Role Grant Additions](#7-role-grants)
8. [New Triggers](#8-triggers)
9. [New Buffer Lifecycle Functions](#9-buffer-functions)
10. [New Scheduled Jobs](#10-scheduled-jobs)
11. [Migration Notes (existing instances)](#11-migration-notes)
12. [Verification Queries](#12-verification)
13. [Guard Summary Additions](#13-guards)

---

## 1. Summary of Changes {#1-summary}

| Category | Change | Impact |
|---|---|---|
| `consent_banners.purposes` JSONB | Add `purpose_definition_id`, `data_scope`, `default_expiry_days`, `auto_delete_on_expiry` fields to purpose object schema | Banner builder must populate these fields |
| `consent_events` | Add `artefact_ids` text[] column — denormalised list of artefact IDs generated from this event | Read convenience; populated by Edge Function after artefact creation |
| `deletion_requests` | Add nullable `artefact_id` FK column | Links deletions to the specific artefact that authorised them |
| `deletion_receipts` | Add nullable `artefact_id` FK column | Completes the chain of custody |
| **NEW** `purpose_definitions` | Canonical purpose library per org | Required before banner creation in DEPA-native flow |
| **NEW** `purpose_connector_mappings` | Maps purpose data_scope categories to deletion connectors | Enables artefact-scoped deletion |
| **NEW** `consent_artefacts` | One row per purpose per consent interaction. The DEPA artefact record. | Core new table — blocking for DEPA alignment |
| **NEW** `artefact_revocations` | Immutable revocation records. Triggers revocation pipeline. | Append-only; triggers deletion cascade |
| **NEW** `consent_expiry_queue` | Scheduled expiry alerts and enforcement | Drives expiry management feature |
| **NEW** `depa_compliance_metrics` | Materialised view — DEPA score sub-metrics | Read by compliance score API |
| **NEW** pg_cron jobs | `expiry-alerts-daily`, `expiry-enforcement-daily`, `depa-score-refresh-nightly` | Expiry lifecycle management |

---

## 2. New Helper Functions {#2-helper-functions}

```sql
-- ═══════════════════════════════════════════════════════════
-- Generates a ULID-prefixed artefact ID
-- Format: 'cs_art_' + 26-char ULID (time-sortable)
-- Stored as text, not UUID. Enables time-ordered retrieval
-- without an index on created_at.
-- ═══════════════════════════════════════════════════════════
create or replace function generate_artefact_id()
returns text language plpgsql as $$
declare
  t bigint;
  r text;
  chars text := '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  i int;
begin
  t := extract(epoch from now()) * 1000;
  r := '';
  -- Encode timestamp (10 chars)
  for i in 1..10 loop
    r := substring(chars from (t % 32)::int + 1 for 1) || r;
    t := t / 32;
  end loop;
  -- Append 16 random chars
  for i in 1..16 loop
    r := r || substring(chars from (floor(random() * 32))::int + 1 for 1);
  end loop;
  return 'cs_art_' || r;
end;
$$;

-- ═══════════════════════════════════════════════════════════
-- Returns the DEPA compliance score for an org (0-20)
-- Called by the depa-score-refresh pg_cron job
-- ═══════════════════════════════════════════════════════════
create or replace function compute_depa_score(p_org_id uuid)
returns jsonb language plpgsql security definer as $$
declare
  v_coverage_score  numeric;
  v_expiry_score    numeric;
  v_freshness_score numeric;
  v_revocation_score numeric;
  v_total           numeric;
begin
  -- Sub-metric 1: Artefact coverage
  -- % of active purpose_definitions that have data_scope populated
  select
    case
      when count(*) = 0 then 0
      else round((count(*) filter (where array_length(data_scope, 1) > 0)::numeric / count(*)) * 5, 1)
    end
  into v_coverage_score
  from purpose_definitions
  where org_id = p_org_id;

  -- Sub-metric 2: Expiry definition
  -- % of active purpose_definitions with explicitly set default_expiry_days (not the system default of 365)
  select
    case
      when count(*) = 0 then 0
      else round((count(*) filter (where default_expiry_days != 365)::numeric / count(*)) * 5, 1)
    end
  into v_expiry_score
  from purpose_definitions
  where org_id = p_org_id;

  -- Sub-metric 3: Artefact freshness
  -- % of active artefacts that expire more than 90 days in the future
  select
    case
      when count(*) = 0 then 5  -- No artefacts = no stale ones = full score
      else round((count(*) filter (where expires_at > now() + interval '90 days')::numeric / count(*)) * 5, 1)
    end
  into v_freshness_score
  from consent_artefacts
  where org_id = p_org_id
    and status = 'active';

  -- Sub-metric 4: Revocation chain completeness
  -- % of revocation events with a deletion receipt within 30 days
  select
    case
      when count(*) = 0 then 5  -- No revocations = no incomplete chains = full score
      else round(
        (count(dr.id)::numeric /
         count(ar.id)) * 5, 1)
    end
  into v_revocation_score
  from artefact_revocations ar
  left join deletion_receipts dr
    on dr.artefact_id = ar.artefact_id
    and dr.status = 'completed'
    and dr.created_at < ar.revoked_at + interval '30 days'
  where ar.org_id = p_org_id
    and ar.revoked_at > now() - interval '90 days';

  v_total := coalesce(v_coverage_score, 0)
           + coalesce(v_expiry_score, 0)
           + coalesce(v_freshness_score, 0)
           + coalesce(v_revocation_score, 0);

  return jsonb_build_object(
    'total',             v_total,
    'coverage_score',    v_coverage_score,
    'expiry_score',      v_expiry_score,
    'freshness_score',   v_freshness_score,
    'revocation_score',  v_revocation_score,
    'computed_at',       now()
  );
end;
$$;

-- ═══════════════════════════════════════════════════════════
-- Artefact expiry enforcement — run by pg_cron nightly
-- Sets expired artefacts to 'expired', removes from index,
-- triggers deletion if auto_delete_on_expiry = true
-- ═══════════════════════════════════════════════════════════
create or replace function enforce_artefact_expiry()
returns void language plpgsql security definer as $$
declare
  v_artefact record;
  v_auto_delete boolean;
begin
  for v_artefact in
    select ca.id, ca.org_id, ca.artefact_id, ca.purpose_definition_id, ca.data_scope
    from consent_artefacts ca
    where ca.status = 'active'
      and ca.expires_at <= now()
  loop
    -- Mark expired
    update consent_artefacts
    set status = 'expired'
    where id = v_artefact.id;

    -- Remove from validity index
    delete from consent_artefact_index
    where artefact_id = v_artefact.artefact_id
      and org_id = v_artefact.org_id;

    -- Write audit entry
    insert into audit_log (org_id, event_type, entity_type, entity_id, payload)
    values (
      v_artefact.org_id,
      'consent_artefact_expired',
      'consent_artefacts',
      v_artefact.id,
      jsonb_build_object('artefact_id', v_artefact.artefact_id, 'reason', 'ttl_exceeded')
    );

    -- Check if auto_delete_on_expiry is set on the purpose definition
    select auto_delete_on_expiry
    into v_auto_delete
    from purpose_definitions
    where id = v_artefact.purpose_definition_id;

    -- If yes, stage deletion requests via delivery_buffer
    -- (actual deletion connector calls happen via the existing deletion pipeline)
    if v_auto_delete then
      insert into delivery_buffer (org_id, event_type, payload)
      values (
        v_artefact.org_id,
        'artefact_expiry_deletion',
        jsonb_build_object(
          'artefact_id',    v_artefact.artefact_id,
          'data_scope',     v_artefact.data_scope,
          'reason',         'consent_expired'
        )
      );
    end if;

    -- Mark expiry queue entry as processed
    update consent_expiry_queue
    set processed_at = now()
    where artefact_id = v_artefact.artefact_id
      and processed_at is null;

  end loop;
end;
$$;

-- ═══════════════════════════════════════════════════════════
-- Expiry alert notifications — run by pg_cron daily
-- Notifies orgs of artefacts approaching expiry
-- ═══════════════════════════════════════════════════════════
create or replace function send_expiry_alerts()
returns void language plpgsql security definer as $$
declare
  v_entry record;
begin
  for v_entry in
    select
      ceq.id,
      ceq.org_id,
      ceq.artefact_id,
      ceq.purpose_code,
      ceq.expires_at,
      o.compliance_contact_email
    from consent_expiry_queue ceq
    join organisations o on o.id = ceq.org_id
    where ceq.notify_at <= now()
      and ceq.notified_at is null
      and ceq.processed_at is null
      and ceq.superseded = false
  loop
    -- Mark as notified (Edge Function picks this up and sends email)
    update consent_expiry_queue
    set notified_at = now()
    where id = v_entry.id;

    -- Write to delivery_buffer for Edge Function to process (email dispatch)
    insert into delivery_buffer (org_id, event_type, payload)
    values (
      v_entry.org_id,
      'consent_expiry_alert',
      jsonb_build_object(
        'artefact_id',           v_entry.artefact_id,
        'purpose_code',          v_entry.purpose_code,
        'expires_at',            v_entry.expires_at,
        'compliance_contact',    v_entry.compliance_contact_email
      )
    );
  end loop;
end;
$$;
```

---

## 3. Modifications to Existing Tables {#3-existing-table-modifications}

### 3.1 `consent_banners.purposes` JSONB — updated object schema

No ALTER TABLE is required. The `purposes` column is JSONB and the object schema is a documentation contract enforced by the application, not the database. The updated schema for each object in the array is:

```sql
-- Updated purpose object schema (stored in consent_banners.purposes jsonb array):
-- {
--   id: string,                    -- 'analytics' | 'marketing' | 'personalisation' | custom
--   purpose_definition_id: uuid,   -- NEW: FK to purpose_definitions.id (null for legacy banners)
--   name: string,                  -- display name shown to user
--   description: string,           -- plain language description
--   data_scope: string[],          -- NEW: data_inventory categories (copied from purpose_definition)
--   default_expiry_days: integer,  -- NEW: copied from purpose_definition at banner creation time
--   auto_delete_on_expiry: boolean,-- NEW: copied from purpose_definition
--   required: boolean,             -- if true, always accepted, cannot be rejected
--   default: boolean               -- pre-checked state for optional purposes
-- }
```

**Migration note for existing banners:** Existing banner purpose objects without `purpose_definition_id` are treated as legacy and generate consent events but do NOT generate `consent_artefacts` rows until the admin maps them to a `purpose_definition`. The compliance score penalises unmapped purposes under the `coverage_score` sub-metric.

### 3.2 `consent_events` — add `artefact_ids` column

```sql
alter table consent_events
  add column artefact_ids text[] not null default '{}';

comment on column consent_events.artefact_ids is
  'Denormalised list of consent_artefact.artefact_id values generated from this event. '
  'Populated by process-consent-event Edge Function after artefact creation. '
  'Empty array means artefacts not yet created or purpose_definitions not mapped.';

create index idx_consent_events_artefact_ids
  on consent_events using gin (artefact_ids);
```

### 3.3 `deletion_requests` — add `artefact_id` column

```sql
alter table deletion_requests
  add column artefact_id text references consent_artefacts(artefact_id) on delete set null;

comment on column deletion_requests.artefact_id is
  'The consent artefact whose revocation or expiry triggered this deletion. '
  'Null for rights-request-triggered deletions (erasure requests from users). '
  'Populated for consent_withdrawn and consent_expired deletion triggers.';

create index idx_deletion_requests_artefact on deletion_requests (artefact_id)
  where artefact_id is not null;
```

### 3.4 `deletion_receipts` — add `artefact_id` column

```sql
alter table deletion_receipts
  add column artefact_id text;

comment on column deletion_receipts.artefact_id is
  'Denormalised from deletion_requests.artefact_id for efficient chain-of-custody queries. '
  'Null for non-artefact-triggered deletions.';

create index idx_deletion_receipts_artefact on deletion_receipts (artefact_id)
  where artefact_id is not null;
```

### 3.5 `consent_artefact_index` — extend to support multi-framework

The existing `consent_artefact_index` table only stores ABDM artefacts. It is extended to serve all frameworks.

```sql
alter table consent_artefact_index
  add column framework text not null default 'abdm',
  add column purpose_code text;

comment on column consent_artefact_index.framework is
  'dpdp | abdm | gdpr — which framework this artefact belongs to.';

comment on column consent_artefact_index.purpose_code is
  'Machine-readable purpose code. Used for fast lookup during tracker enforcement.';

-- Re-create unique constraint to include org_id only (artefact_id is globally unique by ULID prefix)
-- Existing unique (org_id, artefact_id) is fine for the new model since
-- DPDP artefacts use cs_art_ prefix and ABDM artefacts use their NHA-assigned ID.
```

---

## 4. New Tables {#4-new-tables}

Execute in this order. Foreign key dependencies require `purpose_definitions` before `consent_artefacts`, and `consent_artefacts` before `artefact_revocations` and `consent_expiry_queue`.

```sql
-- ═══════════════════════════════════════════════════════════
-- PURPOSE DEFINITIONS — canonical purpose library per org
-- The source of truth for what each purpose means:
-- what data it covers, how long consent lasts, what to delete on revocation.
-- Must exist before banners reference them and before artefacts are created.
-- ═══════════════════════════════════════════════════════════
create table purpose_definitions (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references organisations(id) on delete cascade,
  purpose_code          text not null,
  -- Machine-readable, stable. Recommended standard codes:
  --   'analytics'       — usage data, page views, session data
  --   'marketing'       — email marketing, retargeting
  --   'personalisation' — UX customisation, recommendations
  --   'functional'      — necessary for service (required = true)
  --   'abdm_treatment'  — ABDM health data for treatment (healthcare only)
  --   'abdm_research'   — ABDM health data for research (healthcare only)
  -- Custom codes allowed. Must be lowercase, no spaces.
  display_name          text not null,
  description           text not null,         -- shown to user in banner preference centre
  data_scope            text[] not null default '{}',
  -- Array of data_inventory.data_category values this purpose covers.
  -- Examples: ['email_address', 'name', 'usage_data', 'device_info']
  -- This is the scope used by the deletion orchestration when this
  -- consent is revoked or expires.
  default_expiry_days   integer not null default 365,
  -- Days until a consent artefact for this purpose expires.
  -- Default 365. Set to 0 for purposes where consent should not expire
  -- (e.g. 'functional' required purposes — though these rarely need consent).
  auto_delete_on_expiry boolean not null default false,
  -- If true, deletion orchestration fires automatically when artefact expires.
  -- If false, expiry alert is sent but deletion is not triggered automatically.
  is_required           boolean not null default false,
  -- If true, this purpose is always accepted. Banner does not show a toggle.
  -- Required purposes do not generate consent_artefacts (no consent needed = no artefact).
  framework             text not null default 'dpdp',
  -- 'dpdp' | 'abdm' | 'gdpr'
  -- A purpose is tied to a framework. ABDM purposes have additional fields.
  abdm_hi_types         text[] default null,
  -- For framework = 'abdm' only.
  -- FHIR health information types this ABDM purpose covers.
  -- ['MedicationRequest', 'Observation', 'DiagnosticReport', 'Immunization', ...]
  -- Null for non-ABDM purposes.
  is_active             boolean not null default true,
  created_at            timestamptz default now(),
  updated_at            timestamptz default now(),
  unique (org_id, purpose_code, framework)
);

comment on table purpose_definitions is
  'Canonical purpose library per organisation. '
  'Banners reference purpose_definition_id in their purposes JSONB. '
  'Artefacts copy data_scope and default_expiry_days from here at creation time. '
  'Mutable (admins can update descriptions and expiry days) but purpose_code is stable. '
  'Do not delete a purpose_definition that has active consent_artefacts.';


-- ═══════════════════════════════════════════════════════════
-- PURPOSE CONNECTOR MAPPINGS
-- Maps data_scope categories (from purpose_definitions) to
-- integration connectors (from integration_connectors).
-- Used by artefact-scoped deletion orchestration to determine
-- which connectors to call when a specific artefact is revoked.
-- ═══════════════════════════════════════════════════════════
create table purpose_connector_mappings (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references organisations(id) on delete cascade,
  purpose_definition_id uuid not null references purpose_definitions(id) on delete cascade,
  connector_id          uuid not null references integration_connectors(id) on delete cascade,
  data_categories       text[] not null default '{}',
  -- Which data_scope categories this connector handles for this purpose.
  -- Subset of purpose_definitions.data_scope.
  -- Example: for purpose 'marketing' with data_scope ['email_address', 'name', 'phone'],
  -- Mailchimp connector might map to ['email_address'] and HubSpot to ['email_address', 'name'].
  created_at            timestamptz default now(),
  unique (purpose_definition_id, connector_id)
);

comment on table purpose_connector_mappings is
  'Links purpose data_scope categories to deletion connectors. '
  'When an artefact is revoked, this table determines which connectors '
  'are responsible for deleting which data categories. '
  'Without a mapping, revocation alerts are sent but automated deletion cannot execute.';


-- ═══════════════════════════════════════════════════════════
-- CONSENT ARTEFACTS — the DEPA-native consent record
-- One row per purpose per consent interaction.
-- This is the authoritative consent record under DEPA.
-- The consent_events table records the interaction; this table
-- records the resulting consent grant per purpose.
--
-- APPEND-ONLY: No UPDATE or DELETE policy for authenticated role.
-- Status changes (revoked, expired, replaced) are enforced by:
--   - artefact_revocations INSERT trigger (revoked)
--   - enforce_artefact_expiry() pg_cron function (expired)
--   - process-consent-event Edge Function (replaced, on re-consent)
-- ═══════════════════════════════════════════════════════════
create table consent_artefacts (
  id                    uuid primary key default gen_random_uuid(),
  artefact_id           text not null unique default generate_artefact_id(),
  -- Stable external reference. Format: 'cs_art_' + 26-char ULID.
  -- This ID is used in audit logs, deletion receipts, and API responses.
  -- Globally unique. Time-sortable.
  org_id                uuid not null,
  -- Denormalised. No FK — avoids join for RLS check (same pattern as consent_events).
  property_id           uuid not null references web_properties(id),
  banner_id             uuid not null references consent_banners(id),
  banner_version        integer not null,
  -- Denormalised snapshot of which banner version the user saw.
  consent_event_id      uuid not null references consent_events(id),
  -- The interaction-level event that generated this artefact.
  -- Provides traceability: which user action → which artefacts.
  session_fingerprint   text not null,
  -- SHA-256 of (user_agent + truncated_ip + org_id). Not a user ID.
  -- Same value as consent_events.session_fingerprint for the parent event.
  purpose_definition_id uuid not null references purpose_definitions(id),
  purpose_code          text not null,
  -- Denormalised from purpose_definitions.purpose_code at creation time.
  -- Stable even if purpose_definition is later updated.
  data_scope            text[] not null default '{}',
  -- Copied from purpose_definitions.data_scope at creation time.
  -- Snapshot — not a live reference. Stable for audit trail integrity.
  framework             text not null default 'dpdp',
  -- 'dpdp' | 'abdm' | 'gdpr'. Copied from purpose_definitions.framework.
  expires_at            timestamptz not null,
  -- Created at: now() + purpose_definitions.default_expiry_days.
  -- For purposes where default_expiry_days = 0, set to 'infinity'::timestamptz.
  status                text not null default 'active',
  -- 'active' | 'revoked' | 'expired' | 'replaced'
  -- Transitions:
  --   active → revoked:  via artefact_revocations INSERT (trigger)
  --   active → expired:  via enforce_artefact_expiry() pg_cron job
  --   active → replaced: via process-consent-event Edge Function on re-consent
  replaced_by           text references consent_artefacts(artefact_id),
  -- If status = 'replaced', points to the successor artefact.
  -- Null for all other statuses.

  -- ABDM-specific fields (null for dpdp and gdpr artefacts)
  abdm_artefact_id      text,
  -- NHA-assigned consent artefact ID. Populated for framework = 'abdm'.
  abdm_hip_id           text,
  -- ABDM Health Information Provider ID (clinic's ABDM registration ID).
  abdm_hiu_id           text,
  -- ABDM Health Information User ID (who requested the data).
  abdm_fhir_types       text[],
  -- FHIR resource types the patient consented to share.

  created_at            timestamptz default now()
  -- NO updated_at. Status changes are enforced externally.
  -- APPEND-ONLY for authenticated role. Service role updates status only.
);

comment on table consent_artefacts is
  'DEPA-native consent artefact table. One row per purpose per consent interaction. '
  'This is the authoritative record for compliance, audit, and deletion orchestration. '
  'The consent_events table is the interaction log; this table is the derived consent grant. '
  'APPEND-ONLY for authenticated role. Status changes via triggers and pg_cron only. '
  'Exported to customer storage nightly via delivery_buffer. '
  'Do not query this table without org_id in the WHERE clause (RLS enforces this, '
  'but explicit org_id avoids sequential scans on large datasets).';


-- ═══════════════════════════════════════════════════════════
-- ARTEFACT REVOCATIONS — immutable revocation records
-- Every revocation of a consent artefact creates one row here.
-- Inserting a row triggers:
--   1. consent_artefacts.status → 'revoked'
--   2. consent_artefact_index entry removed
--   3. Deletion orchestration pipeline (via delivery_buffer)
--   4. audit_log entry
--
-- APPEND-ONLY: No UPDATE or DELETE policy for any role.
-- ═══════════════════════════════════════════════════════════
create table artefact_revocations (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null,
  -- Denormalised for RLS.
  artefact_id     text not null references consent_artefacts(artefact_id),
  -- The artefact being revoked.
  revoked_at      timestamptz not null default now(),
  reason          text not null,
  -- 'user_preference_change'  — user changed settings in preference centre
  -- 'user_withdrawal'         — user explicitly withdrew via rights centre
  -- 'business_withdrawal'     — business revoked (e.g. relationship ended)
  -- 'data_breach'             — revoked as remediation step after a breach
  -- 'regulatory_instruction'  — DPB or court order
  revoked_by_type text not null,
  -- 'data_principal' | 'organisation' | 'system' | 'regulator'
  revoked_by_ref  text,
  -- For data_principal: session_fingerprint of the revoking session
  -- For organisation: user_id of the admin who revoked
  -- For regulator: reference number of the instruction
  -- Nullable.
  notes           text,
  delivered_at    timestamptz,
  -- Delivery pipeline tracks export to customer storage.
  created_at      timestamptz default now()
  -- APPEND-ONLY. No updated_at.
);

comment on table artefact_revocations is
  'Immutable log of every consent artefact revocation. '
  'Inserting a row here is the mechanism for revoking an artefact — '
  'the trigger updates consent_artefacts.status. '
  'Do not attempt to UPDATE consent_artefacts.status directly from application code. '
  'The delivery pipeline exports these records to customer storage nightly.';


-- ═══════════════════════════════════════════════════════════
-- CONSENT EXPIRY QUEUE — scheduled expiry management
-- One row per consent_artefact. Tracks when to alert and when to enforce.
-- ═══════════════════════════════════════════════════════════
create table consent_expiry_queue (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade,
  artefact_id     text not null references consent_artefacts(artefact_id) on delete cascade,
  purpose_code    text not null,
  -- Denormalised for efficient alert batching by purpose.
  expires_at      timestamptz not null,
  -- Copied from consent_artefacts.expires_at.
  notify_at       timestamptz not null,
  -- expires_at - 30 days. When the alert fires.
  notified_at     timestamptz,
  -- Set when the expiry alert is sent. Null = alert not yet sent.
  processed_at    timestamptz,
  -- Set when the artefact is actually expired by the enforcement job. Null = pending.
  superseded      boolean not null default false,
  -- True if the artefact was re-consented before expiry.
  -- Superseded entries are skipped by both alert and enforcement jobs.
  created_at      timestamptz default now()
);

comment on table consent_expiry_queue is
  'Scheduled expiry management for consent artefacts. '
  'One row created per artefact at artefact creation time. '
  'notify_at = expires_at - 30 days. '
  'send_expiry_alerts() pg_cron job reads this for pending notifications. '
  'enforce_artefact_expiry() pg_cron job reads consent_artefacts directly '
  'and updates this table as a side effect. '
  'Rows are not deleted after processing — they form a historical expiry audit trail.';


-- ═══════════════════════════════════════════════════════════
-- DEPA COMPLIANCE METRICS — materialised view
-- Stores the computed DEPA compliance score per org.
-- Refreshed nightly by pg_cron.
-- Read by the compliance score API without recomputing.
-- ═══════════════════════════════════════════════════════════
create table depa_compliance_metrics (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references organisations(id) on delete cascade unique,
  total_score     numeric(4,1) not null default 0,
  coverage_score  numeric(4,1) not null default 0,
  expiry_score    numeric(4,1) not null default 0,
  freshness_score numeric(4,1) not null default 0,
  revocation_score numeric(4,1) not null default 0,
  computed_at     timestamptz not null default now(),
  created_at      timestamptz default now(),
  updated_at      timestamptz default now()
);

comment on table depa_compliance_metrics is
  'Cached DEPA compliance score per organisation. '
  'Updated nightly by the depa-score-refresh-nightly pg_cron job. '
  'Do not read consent_artefacts directly in the score API — use this table. '
  'Stale by at most 24 hours. Staleness is surfaced in the dashboard '
  'if computed_at is older than 25 hours (allows 1-hour job delay tolerance).';
```

---

## 5. New Indexes {#5-indexes}

```sql
-- ═══════════════════════════════════════════════════════════
-- purpose_definitions indexes
-- ═══════════════════════════════════════════════════════════
create index idx_purpose_defs_org on purpose_definitions (org_id);
create index idx_purpose_defs_org_framework on purpose_definitions (org_id, framework);
create index idx_purpose_defs_code on purpose_definitions (org_id, purpose_code);

-- ═══════════════════════════════════════════════════════════
-- purpose_connector_mappings indexes
-- ═══════════════════════════════════════════════════════════
create index idx_pcm_purpose_def on purpose_connector_mappings (purpose_definition_id);
create index idx_pcm_connector on purpose_connector_mappings (connector_id);

-- ═══════════════════════════════════════════════════════════
-- consent_artefacts indexes
-- Primary access patterns:
--   1. By org_id + status (dashboard, score computation)
--   2. By session_fingerprint (rights request lookup)
--   3. By artefact_id (audit trail, deletion chain)
--   4. By expires_at + status (expiry enforcement job)
--   5. By purpose_definition_id (purpose analytics)
--   6. By consent_event_id (event → artefact traceability)
-- ═══════════════════════════════════════════════════════════
create index idx_artefacts_org_status
  on consent_artefacts (org_id, status);

create index idx_artefacts_org_status_expires
  on consent_artefacts (org_id, status, expires_at)
  where status = 'active';

create index idx_artefacts_fingerprint
  on consent_artefacts (org_id, session_fingerprint)
  where status = 'active';

create index idx_artefacts_artefact_id
  on consent_artefacts (artefact_id);
  -- Already unique, but explicit index for join performance.

create index idx_artefacts_event_id
  on consent_artefacts (consent_event_id);

create index idx_artefacts_purpose_def
  on consent_artefacts (purpose_definition_id);

create index idx_artefacts_framework
  on consent_artefacts (org_id, framework, status)
  where status = 'active';

create index idx_artefacts_abdm
  on consent_artefacts (abdm_artefact_id)
  where abdm_artefact_id is not null;

-- ═══════════════════════════════════════════════════════════
-- artefact_revocations indexes
-- ═══════════════════════════════════════════════════════════
create index idx_revocations_artefact on artefact_revocations (artefact_id);
create index idx_revocations_org_time on artefact_revocations (org_id, revoked_at desc);
create index idx_revocations_undelivered on artefact_revocations (delivered_at)
  where delivered_at is null;

-- ═══════════════════════════════════════════════════════════
-- consent_expiry_queue indexes
-- Primary access patterns:
--   1. Pending alert notification (daily job)
--   2. Pending enforcement (enforcement job uses consent_artefacts directly)
--   3. By artefact_id (housekeeping, supersession)
-- ═══════════════════════════════════════════════════════════
create index idx_expiry_queue_alert_pending
  on consent_expiry_queue (notify_at)
  where notified_at is null and superseded = false;

create index idx_expiry_queue_org_upcoming
  on consent_expiry_queue (org_id, expires_at)
  where processed_at is null and superseded = false;

create index idx_expiry_queue_artefact
  on consent_expiry_queue (artefact_id);
```

---

## 6. Row-Level Security — New Policies {#6-rls}

```sql
-- Enable RLS on all new tables
alter table purpose_definitions         enable row level security;
alter table purpose_connector_mappings  enable row level security;
alter table consent_artefacts           enable row level security;
alter table artefact_revocations        enable row level security;
alter table consent_expiry_queue        enable row level security;
alter table depa_compliance_metrics     enable row level security;

-- ═══════════════════════════════════════════════════════════
-- purpose_definitions — mutable, admin-managed
-- ═══════════════════════════════════════════════════════════
create policy "purpose_defs_select_own"
  on purpose_definitions for select
  using (org_id = current_org_id());

create policy "purpose_defs_insert_admin"
  on purpose_definitions for insert
  with check (org_id = current_org_id() and is_org_admin());

create policy "purpose_defs_update_admin"
  on purpose_definitions for update
  using (org_id = current_org_id() and is_org_admin());
  -- No DELETE policy. Deactivate with is_active = false instead.

-- ═══════════════════════════════════════════════════════════
-- purpose_connector_mappings — admin-managed
-- ═══════════════════════════════════════════════════════════
create policy "pcm_select_own"
  on purpose_connector_mappings for select
  using (org_id = current_org_id());

create policy "pcm_insert_admin"
  on purpose_connector_mappings for insert
  with check (org_id = current_org_id() and is_org_admin());

create policy "pcm_delete_admin"
  on purpose_connector_mappings for delete
  using (org_id = current_org_id() and is_org_admin());

-- ═══════════════════════════════════════════════════════════
-- consent_artefacts — append-only for authenticated
-- Status updates handled by service role (triggers, Edge Functions)
-- ═══════════════════════════════════════════════════════════
create policy "artefacts_select_own"
  on consent_artefacts for select
  using (org_id = current_org_id());

-- No INSERT policy for authenticated role.
-- Artefacts are created by the process-consent-event Edge Function
-- running as service role. Authenticated users cannot create artefacts directly.

-- No UPDATE or DELETE policy for authenticated role.
-- Status transitions are service-role only.

-- ═══════════════════════════════════════════════════════════
-- artefact_revocations — append-only, members can create
-- ═══════════════════════════════════════════════════════════
create policy "revocations_select_own"
  on artefact_revocations for select
  using (org_id = current_org_id());

create policy "revocations_insert_own"
  on artefact_revocations for insert
  with check (org_id = current_org_id());
  -- Any org member can create a revocation (e.g. from the rights centre).
  -- The revocation trigger validates that the artefact belongs to the org.

-- No UPDATE or DELETE policy.

-- ═══════════════════════════════════════════════════════════
-- consent_expiry_queue — read-only for authenticated
-- ═══════════════════════════════════════════════════════════
create policy "expiry_queue_select_own"
  on consent_expiry_queue for select
  using (org_id = current_org_id());

-- No INSERT, UPDATE, or DELETE for authenticated.
-- Managed entirely by triggers and pg_cron (service role).

-- ═══════════════════════════════════════════════════════════
-- depa_compliance_metrics — read-only for authenticated
-- ═══════════════════════════════════════════════════════════
create policy "depa_metrics_select_own"
  on depa_compliance_metrics for select
  using (org_id = current_org_id());

-- No INSERT, UPDATE, or DELETE for authenticated.
-- Managed entirely by pg_cron refresh job (service role).
```

---

## 7. Scoped Role Grant Additions {#7-role-grants}

```sql
-- ═══════════════════════════════════════════════════════════
-- cs_worker role additions
-- The Worker creates consent_events. The Edge Function (running as service role)
-- creates artefacts. cs_worker does not need artefact access.
-- No changes to cs_worker.
-- ═══════════════════════════════════════════════════════════

-- ═══════════════════════════════════════════════════════════
-- cs_delivery role additions
-- Delivery pipeline reads and hard-deletes delivered buffer rows.
-- New buffer-pattern tables: artefact_revocations (delivered_at column).
-- ═══════════════════════════════════════════════════════════
grant select, delete on artefact_revocations to cs_delivery;
-- Note: cs_delivery can only delete rows where delivered_at is not null
-- (enforced by the delivery function's WHERE clause, not a DB constraint).

-- ═══════════════════════════════════════════════════════════
-- cs_orchestrator role additions
-- Orchestrator manages workflow tasks: SLA checks, expiry alerts, score refresh.
-- Needs read/insert access to new tables for orchestration functions.
-- ═══════════════════════════════════════════════════════════
grant select on consent_artefacts to cs_orchestrator;
grant select, update on consent_expiry_queue to cs_orchestrator;
grant insert, select, update on depa_compliance_metrics to cs_orchestrator;

-- Service role (used by Edge Functions) has full access to all tables.
-- No explicit grants needed — Supabase service role bypasses RLS.
```

---

## 8. New Triggers {#8-triggers}

```sql
-- ═══════════════════════════════════════════════════════════
-- TRIGGER: Create expiry queue entry on artefact INSERT
-- Fires after every new artefact is created.
-- Creates the corresponding consent_expiry_queue row.
-- Uses service role context (trigger fires in Edge Function transaction).
-- ═══════════════════════════════════════════════════════════
create or replace function trg_artefact_create_expiry_entry()
returns trigger language plpgsql security definer as $$
begin
  -- Only create expiry entry for finite expiry artefacts
  -- (expires_at = 'infinity' means no expiry — no queue entry needed)
  if new.expires_at < 'infinity'::timestamptz then
    insert into consent_expiry_queue (
      org_id, artefact_id, purpose_code,
      expires_at, notify_at
    ) values (
      new.org_id,
      new.artefact_id,
      new.purpose_code,
      new.expires_at,
      new.expires_at - interval '30 days'  -- Alert 30 days before expiry
    );
  end if;
  return new;
end;
$$;

create trigger trg_consent_artefact_expiry_queue
  after insert on consent_artefacts
  for each row execute function trg_artefact_create_expiry_entry();

-- ═══════════════════════════════════════════════════════════
-- TRIGGER: Cascade revocation on artefact_revocations INSERT
-- Fires after a revocation row is inserted.
-- Updates the artefact status and removes it from the validity index.
-- ═══════════════════════════════════════════════════════════
create or replace function trg_artefact_revocation_cascade()
returns trigger language plpgsql security definer as $$
begin
  -- Update artefact status
  update consent_artefacts
  set status = 'revoked'
  where artefact_id = new.artefact_id
    and status = 'active';

  if not found then
    raise exception 'Cannot revoke artefact %: not found or not active', new.artefact_id;
  end if;

  -- Remove from validity index
  delete from consent_artefact_index
  where artefact_id = new.artefact_id;

  -- Mark expiry queue entry as superseded
  update consent_expiry_queue
  set superseded = true
  where artefact_id = new.artefact_id
    and processed_at is null;

  -- Write audit log entry
  insert into audit_log (org_id, event_type, entity_type, entity_id, payload)
  values (
    new.org_id,
    'consent_artefact_revoked',
    'consent_artefacts',
    (select id from consent_artefacts where artefact_id = new.artefact_id),
    jsonb_build_object(
      'artefact_id',    new.artefact_id,
      'reason',         new.reason,
      'revoked_by',     new.revoked_by_type
    )
  );

  return new;
end;
$$;

create trigger trg_artefact_revocation
  after insert on artefact_revocations
  for each row execute function trg_artefact_revocation_cascade();

-- ═══════════════════════════════════════════════════════════
-- TRIGGER: Validate org ownership on artefact_revocations INSERT
-- Prevents an org from revoking another org's artefact.
-- ═══════════════════════════════════════════════════════════
create or replace function trg_revocation_org_check()
returns trigger language plpgsql as $$
declare
  v_artefact_org_id uuid;
begin
  select org_id into v_artefact_org_id
  from consent_artefacts
  where artefact_id = new.artefact_id;

  if v_artefact_org_id is null then
    raise exception 'Artefact % does not exist', new.artefact_id;
  end if;

  if v_artefact_org_id != new.org_id then
    raise exception 'Artefact % does not belong to org %', new.artefact_id, new.org_id;
  end if;

  return new;
end;
$$;

create trigger trg_revocation_org_validation
  before insert on artefact_revocations
  for each row execute function trg_revocation_org_check();

-- ═══════════════════════════════════════════════════════════
-- TRIGGER: updated_at on mutable DEPA tables
-- ═══════════════════════════════════════════════════════════
create trigger trg_purpose_defs_updated_at
  before update on purpose_definitions
  for each row execute function set_updated_at();

create trigger trg_depa_metrics_updated_at
  before update on depa_compliance_metrics
  for each row execute function set_updated_at();
```

---

## 9. New Buffer Lifecycle Functions {#9-buffer-functions}

```sql
-- ═══════════════════════════════════════════════════════════
-- Confirm delivery and delete for artefact_revocations
-- Called by the delivery pipeline after confirmed export to customer storage.
-- Same pattern as the existing confirm_delivery_and_delete() functions.
-- ═══════════════════════════════════════════════════════════
create or replace function confirm_revocation_delivery(p_revocation_id uuid)
returns void language plpgsql security definer as $$
begin
  delete from artefact_revocations
  where id = p_revocation_id
    and delivered_at is not null;

  if not found then
    raise exception 'Revocation % not found or not marked delivered', p_revocation_id;
  end if;
end;
$$;

-- ═══════════════════════════════════════════════════════════
-- Extended detect_stuck_buffers to include artefact_revocations
-- ═══════════════════════════════════════════════════════════
create or replace function detect_stuck_buffers()
returns table(table_name text, stuck_count bigint, oldest_stuck_at timestamptz)
language sql security definer as $$
  -- existing tables...
  select 'consent_events'::text, count(*), min(created_at)
  from consent_events where delivered_at is null and created_at < now() - interval '1 hour'

  union all

  select 'tracker_observations', count(*), min(created_at)
  from tracker_observations where delivered_at is null and created_at < now() - interval '1 hour'

  union all

  select 'audit_log', count(*), min(created_at)
  from audit_log where delivered_at is null and created_at < now() - interval '1 hour'

  union all

  select 'processing_log', count(*), min(created_at)
  from processing_log where delivered_at is null and created_at < now() - interval '1 hour'

  union all

  select 'rights_request_events', count(*), min(created_at)
  from rights_request_events where delivered_at is null and created_at < now() - interval '1 hour'

  -- NEW: artefact_revocations buffer
  union all

  select 'artefact_revocations', count(*), min(created_at)
  from artefact_revocations where delivered_at is null and created_at < now() - interval '1 hour'
$$;
```

---

## 10. New Scheduled Jobs {#10-scheduled-jobs}

```sql
-- ═══════════════════════════════════════════════════════════
-- Expiry alert notifications — daily at 08:00 IST (02:30 UTC)
-- ═══════════════════════════════════════════════════════════
select cron.schedule(
  'expiry-alerts-daily',
  '30 2 * * *',  -- 02:30 UTC = 08:00 IST
  $$select send_expiry_alerts()$$
);

-- ═══════════════════════════════════════════════════════════
-- Expiry enforcement — daily at 00:30 IST (19:00 UTC prev day)
-- Runs slightly before alert job so expired artefacts are cleaned
-- before the day's alert batch goes out.
-- ═══════════════════════════════════════════════════════════
select cron.schedule(
  'expiry-enforcement-daily',
  '0 19 * * *',  -- 19:00 UTC = 00:30 IST
  $$select enforce_artefact_expiry()$$
);

-- ═══════════════════════════════════════════════════════════
-- DEPA score refresh — nightly at 01:00 IST (19:30 UTC prev day)
-- Computes and caches DEPA scores for all orgs.
-- ═══════════════════════════════════════════════════════════
select cron.schedule(
  'depa-score-refresh-nightly',
  '30 19 * * *',  -- 19:30 UTC = 01:00 IST
  $$
    insert into depa_compliance_metrics (org_id, total_score, coverage_score, expiry_score, freshness_score, revocation_score, computed_at)
    select
      id as org_id,
      (compute_depa_score(id) ->> 'total')::numeric,
      (compute_depa_score(id) ->> 'coverage_score')::numeric,
      (compute_depa_score(id) ->> 'expiry_score')::numeric,
      (compute_depa_score(id) ->> 'freshness_score')::numeric,
      (compute_depa_score(id) ->> 'revocation_score')::numeric,
      now()
    from organisations
    on conflict (org_id) do update set
      total_score      = excluded.total_score,
      coverage_score   = excluded.coverage_score,
      expiry_score     = excluded.expiry_score,
      freshness_score  = excluded.freshness_score,
      revocation_score = excluded.revocation_score,
      computed_at      = excluded.computed_at,
      updated_at       = now()
  $$
);
```

---

## 11. Migration Notes (Existing Instances) {#11-migration-notes}

If the base schema is already deployed with customer data, execute in this exact sequence to avoid constraint violations and downtime.

**Step 1 — Add nullable columns first (no data migration needed):**
```sql
alter table consent_events add column artefact_ids text[] not null default '{}';
alter table deletion_requests add column artefact_id text;
alter table deletion_receipts add column artefact_id text;
alter table consent_artefact_index add column framework text not null default 'abdm';
alter table consent_artefact_index add column purpose_code text;
```

**Step 2 — Create new tables (no data yet):**

Run Sections 4 (new tables) in order: `purpose_definitions` → `purpose_connector_mappings` → `consent_artefacts` → `artefact_revocations` → `consent_expiry_queue` → `depa_compliance_metrics`.

**Step 3 — Add FK on deletion_requests (after consent_artefacts exists):**
```sql
alter table deletion_requests
  add constraint fk_deletion_requests_artefact
  foreign key (artefact_id)
  references consent_artefacts(artefact_id)
  on delete set null;
```

**Step 4 — Run RLS, triggers, grants, cron jobs** (Sections 6–10).

**Step 5 — Prompt existing customers to create purpose definitions.**

Existing consent_events rows without corresponding artefacts are legacy records. They remain valid for historical audit purposes. The compliance score's `coverage_score` sub-metric will show 0 until purpose definitions are created and mapped. This is intentional — it surfaces the gap.

**Do not back-fill artefacts from existing consent_events rows.** Back-filling would create artefacts without valid purpose_definition_ids and with inaccurate data_scope values. It is better to show the gap honestly and have customers build their purpose library going forward. Historical consent records remain in the export, labelled as `framework: 'legacy_pre_depa'` in the delivery buffer payload.

---

## 12. Verification Queries {#12-verification}

Run after full migration to confirm all guards are active.

```sql
-- ═══════════════════════════════════════════════════════════
-- VERIFY 1: All new tables have RLS enabled
-- ═══════════════════════════════════════════════════════════
select tablename, rowsecurity
from pg_tables
where schemaname = 'public'
  and tablename in (
    'purpose_definitions', 'purpose_connector_mappings',
    'consent_artefacts', 'artefact_revocations',
    'consent_expiry_queue', 'depa_compliance_metrics'
  )
order by tablename;
-- EXPECTED: rowsecurity = true for ALL 6 rows

-- ═══════════════════════════════════════════════════════════
-- VERIFY 2: authenticated role cannot UPDATE or DELETE consent_artefacts
-- ═══════════════════════════════════════════════════════════
select grantee, table_name, privilege_type
from information_schema.table_privileges
where table_schema = 'public'
  and grantee = 'authenticated'
  and table_name = 'consent_artefacts'
  and privilege_type in ('UPDATE', 'DELETE', 'INSERT');
-- EXPECTED: 0 rows

-- ═══════════════════════════════════════════════════════════
-- VERIFY 3: authenticated role cannot UPDATE or DELETE artefact_revocations
-- ═══════════════════════════════════════════════════════════
select grantee, table_name, privilege_type
from information_schema.table_privileges
where table_schema = 'public'
  and grantee = 'authenticated'
  and table_name = 'artefact_revocations'
  and privilege_type in ('UPDATE', 'DELETE');
-- EXPECTED: 0 rows

-- ═══════════════════════════════════════════════════════════
-- VERIFY 4: Revocation cascade trigger is active
-- ═══════════════════════════════════════════════════════════
select trigger_name, event_manipulation, action_timing
from information_schema.triggers
where event_object_table = 'artefact_revocations'
  and trigger_name = 'trg_artefact_revocation';
-- EXPECTED: 1 row, INSERT, AFTER

-- ═══════════════════════════════════════════════════════════
-- VERIFY 5: Org validation trigger is active
-- ═══════════════════════════════════════════════════════════
select trigger_name, event_manipulation, action_timing
from information_schema.triggers
where event_object_table = 'artefact_revocations'
  and trigger_name = 'trg_revocation_org_validation';
-- EXPECTED: 1 row, INSERT, BEFORE

-- ═══════════════════════════════════════════════════════════
-- VERIFY 6: Expiry queue trigger is active
-- ═══════════════════════════════════════════════════════════
select trigger_name, event_manipulation, action_timing
from information_schema.triggers
where event_object_table = 'consent_artefacts'
  and trigger_name = 'trg_consent_artefact_expiry_queue';
-- EXPECTED: 1 row, INSERT, AFTER

-- ═══════════════════════════════════════════════════════════
-- VERIFY 7: New pg_cron jobs are scheduled and active
-- ═══════════════════════════════════════════════════════════
select jobname, schedule, active
from cron.job
where jobname in (
  'expiry-alerts-daily',
  'expiry-enforcement-daily',
  'depa-score-refresh-nightly'
);
-- EXPECTED: 3 rows, all active = true

-- ═══════════════════════════════════════════════════════════
-- VERIFY 8: generate_artefact_id() produces correct prefix
-- ═══════════════════════════════════════════════════════════
select generate_artefact_id() like 'cs_art_%' as has_prefix,
       length(generate_artefact_id()) as id_length;
-- EXPECTED: has_prefix = true, id_length = 33 (7 prefix + 26 ULID)

-- ═══════════════════════════════════════════════════════════
-- VERIFY 9: Purpose definitions unique constraint active
-- ═══════════════════════════════════════════════════════════
select count(*) from information_schema.table_constraints
where table_name = 'purpose_definitions'
  and constraint_type = 'UNIQUE';
-- EXPECTED: at least 1 (the org_id, purpose_code, framework constraint)

-- ═══════════════════════════════════════════════════════════
-- VERIFY 10: Revocation cascade correctly blocks invalid artefact_id
-- Test: attempt to revoke a non-existent artefact
-- ═══════════════════════════════════════════════════════════
-- DO $$
-- BEGIN
--   INSERT INTO artefact_revocations
--     (org_id, artefact_id, reason, revoked_by_type)
--   VALUES
--     (gen_random_uuid(), 'cs_art_DOESNOTEXIST', 'test', 'system');
--   RAISE EXCEPTION 'Should have failed FK check';
-- EXCEPTION
--   WHEN foreign_key_violation THEN
--     RAISE NOTICE 'PASS: FK violation correctly raised';
--   WHEN OTHERS THEN
--     RAISE NOTICE 'PASS: Exception raised: %', SQLERRM;
-- END;
-- $$;
-- EXPECTED: FK violation or trigger exception

-- ═══════════════════════════════════════════════════════════
-- VERIFY 11: Cross-tenant revocation blocked by trigger
-- (Run with a valid org_A artefact_id and a different org_B id)
-- ═══════════════════════════════════════════════════════════
-- INSERT INTO artefact_revocations
--   (org_id, artefact_id, reason, revoked_by_type)
-- VALUES
--   ('<org_B_id>', '<org_A_artefact_id>', 'test', 'system');
-- EXPECTED: Exception 'Artefact does not belong to org'

-- ═══════════════════════════════════════════════════════════
-- VERIFY 12: compute_depa_score returns correct structure
-- ═══════════════════════════════════════════════════════════
select compute_depa_score((select id from organisations limit 1));
-- EXPECTED: jsonb with keys: total, coverage_score, expiry_score,
--           freshness_score, revocation_score, computed_at
```

---

## 13. Guard Summary Additions {#13-guards}

Additions to the existing guard table in `consentshield-complete-schema-design.md` Section 10.

| Guard | What it protects | How it's enforced | Failure mode |
|---|---|---|---|
| No INSERT/UPDATE/DELETE on `consent_artefacts` for authenticated | Artefact integrity — only service role can create and update artefacts | No RLS policy for INSERT/UPDATE/DELETE | Permission denied for any authenticated attempt |
| No UPDATE/DELETE on `artefact_revocations` | Revocation immutability — revocations cannot be undone or edited | No RLS policy for UPDATE/DELETE | Permission denied |
| `trg_revocation_org_validation` (BEFORE trigger) | Cross-tenant revocation attempt | Trigger validates artefact.org_id = revocation.org_id before INSERT | Exception raised, INSERT rolled back |
| `trg_artefact_revocation` (AFTER trigger) | Status consistency — artefact status must match revocation record | Trigger updates consent_artefacts.status immediately on revocation INSERT | If trigger fails, status update fails; transaction rolled back |
| `trg_consent_artefact_expiry_queue` (AFTER trigger) | Every finite artefact has an expiry queue entry | Trigger inserts queue entry on every artefact INSERT where expires_at < infinity | If trigger fails, artefact exists without expiry tracking; caught by audit |
| `generate_artefact_id()` prefix | Artefact IDs are distinguishable from UUIDs in logs and APIs | Function always prepends 'cs_art_' | Cannot fail silently — ID is always prefixed |
| Unique `(org_id, purpose_code, framework)` on `purpose_definitions` | Duplicate purpose codes per org per framework | Unique constraint | Unique violation on INSERT |
| `depa_compliance_metrics` staleness detection | Stale score surfaced to user | `computed_at` timestamp surfaced in API response; UI warns if > 25h old | User sees warning, not a wrong score |
| `consent_artefact_index` extended with `framework` | Multi-framework artefact validation without table joins | Denormalised `framework` field on index entry | Wrong framework = wrong cache behaviour; caught in integration test |

---

*Document prepared April 2026.*
*Run this migration before any customer consent data enters the system.*
*When conflicts exist between this document and the base schema design, this document takes precedence on all DEPA-related tables and columns.*
*All other tables, RLS policies, scoped roles, and guards in the base schema remain unchanged and continue to apply.*
