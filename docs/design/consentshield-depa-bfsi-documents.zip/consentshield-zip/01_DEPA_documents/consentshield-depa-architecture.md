# ConsentShield — DEPA Alignment Architecture

*Supplementary architecture document · April 2026*
*Companion to: Technical Architecture, Definitive Architecture Reference, ABDM Scope & Data Architecture*
*Supersedes: consent_events data model description in Technical Architecture Section 2.5*

---

## Purpose of This Document

The existing architecture documents acknowledge alignment with DEPA (Data Empowerment and Protection Architecture) at the principle level — particularly the stateless oracle model and zero-storage for health data. What they do not do is translate DEPA's structural requirements into concrete product design decisions.

This document closes that gap. It identifies the specific architectural changes required to make ConsentShield genuinely DEPA-native rather than DEPA-adjacent, explains the reasoning behind each change, and defines the integration points with existing components.

This document does not replace the existing architecture documents. It amends them in the specific sections listed at the top of each change below.

---

## Table of Contents

1. [DEPA Principles and Their Product Implications](#1-depa-principles)
2. [The Consent Artefact as a First-Class Object](#2-consent-artefact)
3. [Unified Artefact Model Across Frameworks](#3-unified-framework)
4. [Consent Expiry as a Product Feature](#4-consent-expiry)
5. [Artefact-Aware Deletion Orchestration](#5-artefact-deletion)
6. [Purpose Definition Registry](#6-purpose-registry)
7. [DEPA Compliance Dimension in Scoring](#7-compliance-scoring)
8. [Cloudflare Worker Flow Changes](#8-worker-changes)
9. [API Surface Changes](#9-api-changes)
10. [Data Flow Diagrams](#10-data-flows)
11. [What Does Not Change](#11-unchanged)
12. [Implementation Sequencing](#12-sequencing)
13. [Guard Summary Additions](#13-guards)

---

## 1. DEPA Principles and Their Product Implications {#1-depa-principles}

DEPA defines five structural requirements for any compliant consent system. Each has a specific product implication for ConsentShield.

### 1.1 Principle: Consent is purpose-scoped and machine-readable

**What DEPA requires:** A consent artefact is not a checkbox event. It is a structured, machine-readable object that binds a specific data principal, a specific data fiduciary, a specific purpose, a defined data scope (which fields), and a defined time window (explicit expiry). Each artefact is independently referenceable.

**Current ConsentShield gap:** The `consent_events` table stores a `purposes_accepted` array as a JSONB field on a single row. This means consent for marketing, analytics, and personalisation is captured as one event. There is no independently addressable artefact per purpose. You cannot revoke "analytics" without touching the entire consent record.

**Product implication:** The consent data model must shift to produce one `consent_artefact` row per purpose per consent interaction. The `consent_events` table is retained as the interaction log (the user acted) but each event now spawns N artefact records for N purposes accepted.

### 1.2 Principle: Each purpose's consent is independently revocable

**What DEPA requires:** Revocation of consent for one purpose must not affect other purposes. The revocation is a discrete, timestamped, immutable event on the specific artefact — not an update to the original consent record.

**Current ConsentShield gap:** When a user withdraws consent via the preference centre, a `consent_withdrawn` event is written to `consent_events` with a `purposes_accepted: []` array. This updates the logical state but does not create a per-artefact revocation record. The withdrawal cannot be traced back to the specific artefact that was revoked.

**Product implication:** A new `artefact_revocations` table is required. Every revocation creates an immutable row referencing the specific `consent_artefact_id` being revoked. The deletion orchestration system uses `artefact_revocations` as its trigger, not the generic `consent_withdrawn` event.

### 1.3 Principle: Consent has defined scope — which data fields it covers

**What DEPA requires:** The consent artefact declares not just a purpose category but the specific data fields the consent covers. In the AA framework, the scope field specifies which financial data types the FIU can access. For DPDP and ABDM, the scope field specifies which personal data categories are included in the consent.

**Current ConsentShield gap:** The `purposes` JSONB in `consent_banners` has `{ id, name, description, required, default }`. There is no `data_scope` field. The banner captures what the user consented to in natural language but does not create a machine-readable data scope.

**Product implication:** The purpose configuration in `consent_banners.purposes` must include a `data_scope` array referencing categories from the `data_inventory`. The artefact records this scope. The deletion orchestration knows which data categories to cascade deletion into when that artefact is revoked.

### 1.4 Principle: Consent has explicit expiry

**What DEPA requires:** A consent artefact has an `expires_at` timestamp. After that timestamp, the data flow the artefact authorised is no longer permitted, even without explicit withdrawal. The party that holds the data must seek fresh consent before continuing to process.

**Current ConsentShield gap:** Consent is currently treated as open-ended. The retention rules module handles when data is deleted, but there is no mechanism that treats consent itself as time-bounded. A user who consented in January 2026 has an indefinitely valid consent record unless they actively withdraw.

**Product implication:** Two additions are required. First, every `consent_artefact` row must have an `expires_at` field, derived from the purpose configuration's `default_expiry_days`. Second, a consent expiry management system must alert businesses when artefacts are approaching expiry, trigger re-consent campaigns, and record lapsed consent as a compliance gap.

### 1.5 Principle: Data flows stop when the purpose is fulfilled

**What DEPA requires:** The consent artefact has a lifecycle. When the purpose is fulfilled — or when the artefact expires or is revoked — the data flow it authorised stops. This is enforced, not merely logged.

**Current ConsentShield gap:** Withdrawal verification scans the page to confirm trackers stopped firing, but this verification is not artefact-aware. It checks whether trackers associated with a purpose category stopped — it does not verify which specific artefact authorised which tracker, and whether the artefact's expiry cascaded to stop the right data flows.

**Product implication:** The withdrawal verification and tracker enforcement systems must be linked to the artefact model. When an artefact expires or is revoked, the system must know exactly which trackers and integrations that artefact authorised, and verify that those specific flows stopped.

---

## 2. The Consent Artefact as a First-Class Object {#2-consent-artefact}

*Amends: Technical Architecture Section 2.5, Complete Schema Design Section 3.2*

### 2.1 The new data model

The consent interaction model changes from a single-row event to a two-level structure:

```
consent_events (interaction log)
    │
    │  1 event → N artefacts (one per purpose accepted)
    ▼
consent_artefacts (DEPA-native records, one per purpose)
    │
    ├──► artefact_revocations (when any artefact is revoked)
    └──► consent_expiry_queue (expiry scheduling)
```

**The `consent_events` table is retained unchanged** as the interaction-level log — it records that a user made a consent decision at a point in time, which banner version they saw, and what their session fingerprint was. Its role changes from "the consent record" to "the evidence that the artefacts were generated from a real user interaction."

**The `consent_artefacts` table is new** and becomes the authoritative consent record for DEPA purposes. One row per purpose per user interaction.

### 2.2 Artefact lifecycle states

```
                    ┌──────────┐
                    │  active  │◄── created on consent_given
                    └─────┬────┘
              ┌───────────┼─────────────┐
              ▼           ▼             ▼
         ┌─────────┐  ┌─────────┐  ┌─────────┐
         │ revoked │  │ expired │  │ replaced│
         └─────────┘  └─────────┘  └─────────┘
         (user action) (expires_at  (new consent
                        passed)      supersedes)
```

State transitions are enforced by the database — no application code can set a status that violates the allowed transitions. An `active` artefact becomes `revoked` only via an `artefact_revocations` INSERT. It becomes `expired` only via the pg_cron expiry job. It becomes `replaced` only when a new `consent_given` event creates a successor artefact for the same session fingerprint and purpose.

### 2.3 Artefact identity and referencing

Each artefact receives a stable, externally referenceable ID prefixed with `cs_art_` — for example `cs_art_01HXXXX`. This ID appears in:

- The audit log (`entity_id`)
- The deletion receipts (`artefact_id`)
- The artefact revocations (`artefact_id`)
- The processing log entries that reference which artefact authorised the processing
- The ABDM consent artefact link field (when the ABDM module is built)

The ID format is a ULID (lexicographically sortable) stored as text, not a UUID. This enables time-ordered sorting without a `created_at` index on the artefacts table in high-volume scenarios.

### 2.4 How the Cloudflare Worker creates artefacts

The existing flow writes one row to `consent_events` per user interaction. Under the DEPA model, the Worker still writes one `consent_events` row, but the Edge Function triggered by that insert creates N `consent_artefacts` rows — one for each purpose the user accepted.

```
Banner JS: user accepts [analytics, marketing]
    │
    ▼
POST /v1/events (Cloudflare Worker)
    │  Validate HMAC
    │  Write consent_events row
    │  Fire process-consent-event Edge Function
    ▼
Edge Function: process-consent-event
    │
    ├──► Create consent_artefacts row for 'analytics'
    │       artefact_id: cs_art_01HXX1
    │       purpose_code: 'analytics'
    │       data_scope: ['usage_data', 'page_views']
    │       expires_at: now() + 365 days
    │       status: active
    │
    ├──► Create consent_artefacts row for 'marketing'
    │       artefact_id: cs_art_01HXX2
    │       purpose_code: 'marketing'
    │       data_scope: ['email_address', 'name']
    │       expires_at: now() + 365 days
    │       status: active
    │
    ├──► Add both artefacts to consent_artefact_index (validity cache)
    │
    ├──► Add expiry entries to consent_expiry_queue
    │
    └──► Stage both artefacts in delivery_buffer for export
```

---

## 3. Unified Artefact Model Across Frameworks {#3-unified-framework}

*Amends: ABDM Scope & Data Architecture, Technical Architecture Section 7 (health schema note)*

### 3.1 The current fragmentation problem

The existing documents describe two separate consent record systems:

- **DPDP consent:** `consent_events` table with `purposes_accepted` array
- **ABDM consent:** NHA-format consent artefacts processed in memory, with only the artefact ID and metadata stored in `consent_artefact_index`

These are architecturally separate, even though they represent the same underlying concept — a user authorising a specific data flow for a specific purpose. The "unified dashboard" claim in marketing requires both to read from the same data model.

### 3.2 The unified artefact model

The `consent_artefacts` table uses a `framework` field to denote which regulatory framework the artefact belongs to:

| `framework` | Description | Artefact source |
|---|---|---|
| `dpdp` | Standard DPDP consent from banner interaction | Created by Worker → Edge Function on `consent_given` event |
| `abdm` | ABDM consent artefact for health record access | Created by ABDM module when NHA returns consent artefact ID |
| `gdpr` | GDPR consent (Phase 3) | Created by banner system when EU visitor detected |

The ABDM artefact row links back to the NHA-assigned artefact ID via the `external_artefact_id` field. The `data_scope` for ABDM artefacts is populated from the FHIR resource types the patient consented to share (e.g., `['MedicationRequest', 'Observation', 'DiagnosticReport']`).

### 3.3 What the unified model enables

**Audit export:** A single query on `consent_artefacts` with framework filtering produces the complete consent record for either a DPDP audit (all `framework = 'dpdp'` artefacts) or an ABDM audit (all `framework = 'abdm'` artefacts) — or both together.

**Compliance score:** The DEPA compliance dimension (Section 7) can query the same table to calculate metrics across all frameworks simultaneously.

**Rights requests:** A Data Principal's erasure request can be processed against all artefacts for their session fingerprint, across all frameworks, in a single lookup. The deletion orchestration cascades to the data categories listed in `data_scope` for every active artefact found.

### 3.4 ABDM-specific fields

The `consent_artefacts` table includes nullable ABDM-specific columns that are `null` for `dpdp` and `gdpr` artefacts:

```sql
abdm_artefact_id      text,   -- NHA-assigned consent artefact ID
abdm_hip_id           text,   -- Health Information Provider (clinic's ABDM ID)
abdm_hiu_id           text,   -- Health Information User (the entity requesting data)
abdm_fhir_types       text[], -- ['MedicationRequest', 'Observation', ...]
```

These fields are populated by the ABDM module when the NHA gateway returns the consent artefact. They are never populated for non-ABDM artefacts.

---

## 4. Consent Expiry as a Product Feature {#4-consent-expiry}

*New feature — not present in any existing document*

### 4.1 The expiry pipeline

Consent expiry is not a passive event — it requires active product surfaces to be meaningful. The pipeline has three stages:

**Stage 1 — Expiry scheduling (at artefact creation)**

When an artefact is created, an entry is written to `consent_expiry_queue` with `notify_at` set to 30 days before `expires_at`. The purpose configuration's `default_expiry_days` determines the expiry window. If no `default_expiry_days` is set on the purpose, a system default of 365 days applies.

**Stage 2 — Expiry alerts (daily pg_cron job)**

A daily pg_cron job queries `consent_expiry_queue` for entries where `notify_at <= now()` and `notified_at IS NULL`. For each matching entry, it fires a notification to the business: "X user consents for purpose Y are expiring in 30 days. Consider running a re-consent campaign." The notification is written to `audit_log` and delivered via Resend.

**Stage 3 — Expiry enforcement (daily pg_cron job)**

A separate daily pg_cron job queries `consent_artefacts` where `expires_at <= now()` and `status = 'active'`. For each matching row, it:

1. Sets `status = 'expired'`
2. Removes the artefact from `consent_artefact_index` (the validity cache)
3. Writes a `consent_expired` entry to `audit_log`
4. Triggers the deletion orchestration pipeline for the data categories in `data_scope` (if `auto_delete_on_expiry = true` is set on the purpose configuration)
5. Updates `consent_expiry_queue.processed_at`

### 4.2 Re-consent flow

When a business receives an expiry alert and chooses to run a re-consent campaign, the flow is:

1. Business exports a list of expiring session fingerprints from the dashboard
2. Business sends re-consent emails to matched users (via their own email system — ConsentShield does not hold the mapping between session fingerprint and email address)
3. Users who consent again generate new `consent_artefacts` rows for the same purposes
4. The new artefacts set the previous artefacts' `status = 'replaced'` and `replaced_by = new_artefact_id`
5. The expiry queue entry for the old artefact is marked `superseded = true`

The compliance score tracks what percentage of active artefacts have been re-consented within the last `default_expiry_days` window. This is the DEPA compliance dimension's expiry metric.

### 4.3 Consent expiry management UI

A new dashboard panel — **Consent Expiry** — is required. It does not exist in the current screen designs. It shows:

- Artefacts expiring in the next 30 days (count by purpose)
- Artefacts expired in the last 30 days (count, and whether deletion was triggered)
- Re-consent campaign status (if the business has exported the list)
- Historical expiry rate by purpose

This panel is not a Phase 1 feature. It requires the `consent_artefacts` table to exist first, and meaningful expiry data accumulates over time. Target: Phase 2 alongside the Rights Request Tracker.

---

## 5. Artefact-Aware Deletion Orchestration {#5-artefact-deletion}

*Amends: Definitive Architecture Section 11 (Deletion Orchestration)*

### 5.1 The current gap

The existing deletion orchestration model triggers on two events: a rights request (erasure) and a generic `consent_withdrawn` event. The deletion connectors receive a `data_principal` identifier and delete that user from connected systems.

This model has a precision problem: it deletes the user from all connected systems, regardless of which systems the specific withdrawn consent actually authorised. If a user withdraws their analytics consent but not their marketing consent, the system should stop analytics data flows for that user — it should not delete them from the marketing CRM.

### 5.2 Artefact-scoped deletion

Under the DEPA model, every `deletion_request` references an `artefact_id`. The deletion orchestration knows which `data_scope` categories that artefact covered, and maps those categories to the connectors responsible for them.

The mapping is defined in a new `purpose_connector_mappings` table: for each purpose definition, which connectors handle which data scope categories. When an artefact is revoked for purpose `marketing` with `data_scope: ['email_address', 'name']`, the orchestration queries `purpose_connector_mappings` to find that Mailchimp and HubSpot handle `email_address`, and triggers deletion only in those systems.

```
artefact_revocations INSERT
    │
    ├── Look up artefact.data_scope
    │       data_scope: ['email_address', 'name']
    │
    ├── Look up purpose_connector_mappings
    │       email_address → [mailchimp_connector, hubspot_connector]
    │       name → [hubspot_connector]
    │
    ├── Deduplicate: [mailchimp_connector, hubspot_connector]
    │
    └── Create deletion_requests for each connector
            artefact_id: cs_art_01HXX2
            connector_id: mailchimp_connector_id
            data_categories: ['email_address']
            reason: 'consent_revoked'
```

### 5.3 Deletion receipt changes

The `deletion_receipts` table gains an `artefact_id` column. Every deletion receipt now references the specific artefact whose revocation triggered it. This creates a complete chain of custody:

```
consent_artefacts.id  →  artefact_revocations.artefact_id
                      →  deletion_requests.artefact_id
                      →  deletion_receipts.artefact_id
```

An auditor can trace: which user consented (artefact), when they withdrew (revocation), which systems were instructed to delete their data (deletion requests), and which systems confirmed deletion (deletion receipts). This chain is the DPDP Section 12 evidence trail.

---

## 6. Purpose Definition Registry {#6-purpose-registry}

*New table — not present in any existing schema*

### 6.1 Why a purpose registry is needed

Currently, purposes are defined inline in the `consent_banners.purposes` JSONB array. Each banner defines its own purposes. This creates two problems under DEPA:

First, there is no canonical reference for what a purpose means across banners. If a business has three web properties, each with its own banner, the "analytics" purpose is defined three times, potentially with different data scopes on each. When an artefact is created for "analytics" on property 1, it is not the same "analytics" as property 2.

Second, the deletion orchestration cannot link purposes to connectors without a canonical purpose definition. The `purpose_connector_mappings` table needs a stable `purpose_definition_id` to join against.

### 6.2 The `purpose_definitions` table

A new `purpose_definitions` table holds the organisation's canonical purpose library:

```sql
create table purpose_definitions (
  id                    uuid primary key default gen_random_uuid(),
  org_id                uuid not null references organisations(id) on delete cascade,
  purpose_code          text not null,              -- machine-readable: 'analytics' | 'marketing' | custom
  display_name          text not null,              -- shown to user in banner
  description           text not null,              -- plain language
  data_scope            text[] not null default '{}', -- data_inventory categories covered
  default_expiry_days   integer not null default 365,
  auto_delete_on_expiry boolean not null default false,
  is_required           boolean not null default false,
  framework             text not null default 'dpdp', -- 'dpdp' | 'abdm' | 'gdpr'
  created_at            timestamptz default now(),
  updated_at            timestamptz default now(),
  unique (org_id, purpose_code, framework)
);
```

### 6.3 How banners reference purpose definitions

The `consent_banners.purposes` JSONB array continues to exist as a denormalised snapshot (for banner rendering performance and version integrity — the banner must always render with exactly the data the user saw, even if the purpose definition changes later). But each entry in the array now includes a `purpose_definition_id` field referencing the canonical definition.

When an artefact is created, `data_scope` and `default_expiry_days` are copied from the `purpose_definitions` row at the time of creation — not derived dynamically. This means artefact metadata is stable even if the purpose definition is later updated.

---

## 7. DEPA Compliance Dimension in Scoring {#7-compliance-scoring}

*Amends: all compliance score documentation*

### 7.1 The current score model

The compliance score currently measures configuration completeness: banner live, privacy notice published, data inventory complete, rights requests within SLA. These are valid operational metrics but they do not measure DEPA structural compliance.

### 7.2 The new DEPA dimension

A new scoring dimension — **Consent Artefact Quality** — is added alongside the existing categories. It contributes 20 points to the overall compliance score (existing categories are rescaled to accommodate). It is calculated from four sub-metrics:

| Sub-metric | Points | Calculation |
|---|---|---|
| Artefact coverage | 5 | % of active purposes that have a purpose_definition with data_scope populated |
| Expiry definition | 5 | % of active purpose_definitions that have a non-default `default_expiry_days` (i.e. explicitly set, not inherited) |
| Artefact freshness | 5 | % of active artefacts that expire more than 90 days in the future (not imminently lapsing) |
| Revocation chain completeness | 5 | % of revocation events that have a corresponding deletion receipt within 30 days |

A score of 20/20 means: every purpose has a defined data scope, every purpose has an explicitly set expiry, no consents are imminently lapsing, and every revocation has been followed by confirmed deletion.

### 7.3 The DEPA score surface in the dashboard

The compliance dashboard's score card panel adds a DEPA breakdown tab alongside the existing DPDP breakdown. It shows each sub-metric with its current value, a trend line (last 30 days), and the recommended action to improve it.

The action queue prioritises DEPA gaps at **Medium** severity by default. If `artefact_freshness` falls below 50% (more than half of active consents are within 90 days of expiry), the priority escalates to **High** and the action queue item reads: "X% of your user consents expire within 90 days. Export the expiry list and run a re-consent campaign."

---

## 8. Cloudflare Worker Flow Changes {#8-worker-changes}

*Amends: Technical Architecture Section 4 and Flow 1 in Section 6*

### 8.1 What changes in the Worker

The Cloudflare Worker itself does not change. Its job remains: validate the HMAC, hash the fingerprint, write to `consent_events` via the service role. The Worker is a high-performance edge component with no business logic. Business logic lives in Edge Functions.

What changes is the Edge Function triggered by the `consent_events` INSERT.

### 8.2 The `process-consent-event` Edge Function

This Edge Function is new. It is triggered via a Supabase database webhook on `consent_events` INSERT where `event_type = 'consent_given'` or `event_type = 'purpose_updated'`.

```
trigger: consent_events INSERT
input:   new row from consent_events

1. Load banner configuration for banner_id
2. Load purpose_definitions for each purpose in purposes_accepted
3. For each purpose_definition found:
   a. Generate artefact_id (ULID prefixed with 'cs_art_')
   b. INSERT into consent_artefacts:
        artefact_id, org_id, property_id, banner_id, banner_version,
        consent_event_id (FK to consent_events.id),
        session_fingerprint, purpose_definition_id, purpose_code,
        data_scope (copied from purpose_definition),
        framework (from purpose_definition),
        expires_at (now() + default_expiry_days),
        status: 'active'
   c. UPSERT into consent_artefact_index:
        artefact_id, validity_state: 'active', expires_at
   d. INSERT into consent_expiry_queue:
        artefact_id, notify_at (expires_at - 30 days)
   e. Stage in delivery_buffer for export

4. For event_type = 'purpose_updated':
   Find existing active artefacts for this session_fingerprint
   where purpose_code is in purposes_rejected (newly rejected)
   → Insert into artefact_revocations (reason: 'user_preference_change')
   → Trigger artefact-scoped deletion orchestration

5. Write to audit_log:
   event_type: 'artefacts_created',
   entity_type: 'consent_artefacts',
   payload: { artefact_ids: [...], count: N, session_fingerprint }
```

### 8.3 Revocation Edge Function

A new `process-artefact-revocation` Edge Function handles the revocation pipeline:

```
trigger: artefact_revocations INSERT

1. Set consent_artefacts.status = 'revoked' for artefact_id
2. Remove from consent_artefact_index
3. Load artefact.data_scope
4. Query purpose_connector_mappings for relevant connectors
5. Create deletion_requests (one per connector, artefact-scoped)
6. Write to audit_log: artefact_revoked
7. Stage revocation record in delivery_buffer
```

---

## 9. API Surface Changes {#9-api-changes}

*Amends: Technical Architecture Section 5*

### 9.1 New endpoints

| Route | Method | Purpose |
|---|---|---|
| `/api/orgs/[orgId]/purpose-definitions` | GET, POST | List/create purpose definitions |
| `/api/orgs/[orgId]/purpose-definitions/[id]` | GET, PATCH | Get/update a purpose definition |
| `/api/orgs/[orgId]/purpose-definitions/[id]/connectors` | GET, POST, DELETE | Manage purpose→connector mappings |
| `/api/orgs/[orgId]/artefacts` | GET | List consent artefacts (with filter: status, framework, purpose_code, expiring_before) |
| `/api/orgs/[orgId]/artefacts/[id]` | GET | Get single artefact with full audit trail |
| `/api/orgs/[orgId]/artefacts/[id]/revoke` | POST | Revoke an artefact (creates artefact_revocations row) |
| `/api/orgs/[orgId]/expiry-queue` | GET | List upcoming expiry notifications |
| `/api/orgs/[orgId]/expiry-queue/export` | POST | Export expiring session fingerprints for re-consent campaign |
| `/api/orgs/[orgId]/depa-score` | GET | Get DEPA compliance dimension score and sub-metrics |

### 9.2 Compliance API additions (Pro/Enterprise)

| Route | Method | Scopes |
|---|---|---|
| `/api/v1/artefacts` | GET | `read:artefacts` |
| `/api/v1/artefacts/[id]` | GET | `read:artefacts` |
| `/api/v1/artefacts/[id]/revoke` | POST | `write:artefacts` |
| `/api/v1/expiry/upcoming` | GET | `read:artefacts` |
| `/api/v1/purpose-definitions` | GET | `read:consent` |

### 9.3 Existing endpoints affected

**`POST /api/orgs/[orgId]/banners`** — now requires each purpose in the `purposes` array to have a `purpose_definition_id` if the org has purpose definitions defined. If no definitions exist, the banner builder prompts the admin to create them first.

**`GET /api/orgs/[orgId]/consent-events`** — returns events with an embedded `artefact_ids` array showing which artefacts were generated from each event.

**`POST /api/orgs/[orgId]/rights-requests/[id]/events`** — when `event_type = 'erasure_initiated'`, the payload must include `artefact_ids: []` listing which artefacts the erasure covers. If `artefact_ids` is empty, the system uses all active artefacts for the requestor's session fingerprints as the scope.

---

## 10. Data Flow Diagrams {#10-data-flows}

### 10.1 Complete consent lifecycle (DEPA-native)

```
Site visitor arrives
        │
        ▼
Banner renders (cdn.consentshield.in/v1/banner.js)
        │  shows per-purpose toggles with data_scope descriptions
        │
        ▼
User accepts [analytics, marketing]
        │
        ▼
POST /v1/events → Cloudflare Worker
        │  HMAC validated
        │  Session fingerprint hashed
        │
        ▼
consent_events INSERT (1 row)
        │
        ▼
process-consent-event Edge Function
        │
        ├──► consent_artefacts INSERT ×2
        │         cs_art_01HXX1 (analytics, expires 365d)
        │         cs_art_01HXX2 (marketing, expires 365d)
        │
        ├──► consent_artefact_index UPSERT ×2
        │
        ├──► consent_expiry_queue INSERT ×2
        │         notify_at: 335d from now
        │
        └──► delivery_buffer INSERT ×2
                  staged for nightly export to customer storage


[335 days later — pg_cron expiry-alerts job]
        │
        ▼
Email to compliance_contact:
"200 marketing consents expire in 30 days"
        │
        ▼
Business exports expiring fingerprint list
Business runs re-consent email campaign
        │
[30 days later — pg_cron expiry-enforcement job]
        │
        ▼
consent_artefacts: cs_art_01HXX2 status → 'expired'
        │
        ├──► consent_artefact_index: entry removed
        │
        ├──► audit_log: consent_expired event
        │
        └──► deletion_requests (if auto_delete_on_expiry = true):
                  Mailchimp → DELETE user
                  HubSpot → DELETE contact


[Users who re-consented generate new artefacts]
        │
        ▼
cs_art_01HXX2 status → 'replaced'
replaced_by → cs_art_01HYY2
```

### 10.2 Revocation flow

```
User opens preference centre
User withdraws analytics consent
        │
        ▼
POST /v1/events { event_type: 'purpose_updated',
                  purposes_accepted: ['marketing'],
                  purposes_rejected: ['analytics'] }
        │
        ▼
process-consent-event Edge Function
        │  Detects analytics is now in purposes_rejected
        │  Finds active artefact: cs_art_01HXX1 (analytics)
        │
        ▼
artefact_revocations INSERT
        artefact_id: cs_art_01HXX1
        reason: 'user_preference_change'
        revoked_at: now()
        │
        ▼
process-artefact-revocation Edge Function
        │
        ├──► consent_artefacts: cs_art_01HXX1 status → 'revoked'
        │
        ├──► consent_artefact_index: cs_art_01HXX1 removed
        │
        ├──► purpose_connector_mappings lookup:
        │         analytics → [google_analytics_connector, hotjar_connector]
        │
        ├──► deletion_requests INSERT ×2
        │         artefact_id: cs_art_01HXX1
        │         data_categories: ['usage_data', 'page_views']
        │
        └──► withdrawal_verifications scheduled:
                  T+15m: re-scan page for analytics trackers
                  T+1h:  re-scan
                  T+24h: re-scan
```

---

## 11. What Does Not Change {#11-unchanged}

The following components are unaffected by DEPA alignment and continue to operate exactly as documented in the existing architecture documents.

**The Cloudflare Worker** — still receives events, validates HMAC, writes to `consent_events`. No changes to the worker code.

**The banner JS** — still renders purposes, captures the user decision, POSTs the event. The user-facing experience does not change unless the business adds scope descriptions to their purpose definitions (which is optional in Phase 1).

**The stateless oracle model** — the zero-storage architecture for health data is DEPA-native by design and requires no changes.

**Multi-tenant isolation** — all new tables follow the same `org_id` + RLS pattern.

**The delivery buffer pipeline** — `artefact_revocations`, `consent_artefacts`, and new tables are buffer-pattern tables. They follow the same append-only, deliver-then-delete lifecycle as existing buffer tables.

**The scoped role model** — `cs_worker`, `cs_delivery`, `cs_orchestrator` roles are extended with minimum necessary grants on new tables. The role model design principle does not change.

**Razorpay billing**, **Resend email**, **Supabase Auth**, **Vercel hosting** — unchanged.

---

## 12. Implementation Sequencing {#12-sequencing}

DEPA alignment must be implemented before the first customer data enters the system. The schema changes are blocking — retrofitting the artefact model onto live consent data is a data migration problem on a legally significant, append-only table.

| Phase | What to build | When | Blocking? |
|---|---|---|---|
| Pre-launch | `purpose_definitions` table, `consent_artefacts` table, `artefact_revocations` table, `consent_expiry_queue` table | Before first customer | **YES — schema must exist before any consent data** |
| Pre-launch | `process-consent-event` Edge Function (artefact creation) | Before banner goes live | **YES** |
| Pre-launch | `process-artefact-revocation` Edge Function | Before banner goes live | **YES** |
| Pre-launch | Artefact-aware RLS policies | Before first customer | **YES** |
| Pre-launch | `purpose_connector_mappings` table | Before Phase 2 deletion connectors | **YES — connector setup depends on it** |
| Phase 1 | Purpose definition builder UI (admin) | MVP | Required for meaningful artefacts |
| Phase 1 | Artefact list view (read-only, for audit) | MVP | Provides immediate visible value |
| Phase 2 | Consent Expiry dashboard panel | Months 3–5 | After 3+ months of artefact data |
| Phase 2 | Re-consent export | Months 3–5 | After expiry panel |
| Phase 2 | DEPA compliance score dimension | Months 3–5 | After artefact data exists |
| Phase 3 | ABDM artefact unification | ABDM build | Requires ABDM module |
| Phase 3 | GDPR artefact framework | GDPR module | Phase 3 |

---

## 13. Guard Summary Additions {#13-guards}

These guards supplement the Guard Summary in Section 10 of the Complete Schema Design.

| Guard | What it protects | How it's enforced | Failure mode |
|---|---|---|---|
| Artefact status immutability | Artefacts cannot be deleted or manually set to revoked | No UPDATE or DELETE policy on `consent_artefacts` for authenticated role; status changes only via `artefact_revocations` INSERT | Permission denied |
| Artefact→event integrity | Every artefact must reference a real consent event | FK: `consent_artefacts.consent_event_id → consent_events.id` | FK violation on INSERT |
| Purpose definition uniqueness | No duplicate purpose codes per org per framework | Unique constraint: `(org_id, purpose_code, framework)` | Unique violation on INSERT |
| Expiry queue orphan prevention | Every artefact has an expiry queue entry | Trigger on `consent_artefacts` INSERT → `consent_expiry_queue` INSERT | Trigger failure surfaces in audit log |
| Revocation cascade | Revoked artefact is removed from validity index | Trigger on `artefact_revocations` INSERT → `consent_artefact_index` DELETE | If trigger fails, artefact remains valid longer than it should; pg_cron expiry job catches it |
| Artefact-scoped deletion | Deletion requests reference the artefact that authorised them | FK: `deletion_requests.artefact_id → consent_artefacts.id` (nullable — non-artefact deletions from rights requests still permitted) | FK violation if artefact_id is wrong |
| DEPA score cache freshness | Score is not stale by more than 24 hours | pg_cron refreshes `depa_compliance_metrics` materialised view nightly | If job fails, score shows last computed value with staleness warning |

---

*Document prepared April 2026. This document has no standalone meaning — it must be read alongside the Technical Architecture, Definitive Architecture Reference, and ABDM Scope & Data Architecture documents. When conflicts exist between this document and earlier documents, this document takes precedence on consent data model design. On all other topics, earlier documents remain authoritative.*

*Next review: when ABDM module build begins (Phase 3). At that point, Section 3 (unified artefact model) must be validated against NHA's consent artefact specification.*
